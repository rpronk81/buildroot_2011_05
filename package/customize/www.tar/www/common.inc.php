<?php
function StyleTitle($title) {
	// FIXME: comment this out for production
	error_reporting(E_ERROR | E_WARNING | E_PARSE);
	// FIXME: set this to 0 for production
	ini_set('display_errors', 1);

	print "<html><head><title>";
	print gettext($title);
	print "</title><meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>";
	print "<link href='/func/styles_b2a.css' rel='stylesheet' type='text/css' /></head><body>";
	print "<br><br>";
	print "<center><h1>";
	print gettext($title);
	print "</h1></center>";
}

function StyleCommon($title) {
	 echo "<html>".
		 "<head><title>Template Test</title>".
		 "<link rel='stylesheet' type='text/css' href='prototype.css'>";
}

// FIXME: Ideally, this should use same template as rest of code...
function StyleNetwork($title) {
	 StyleCommon($title);
	 echo "</head><body>";
}

function HeadJquery($title) {
	 StyleCommon($title);
	 echo "<link rel='stylesheet' type='text/css' href='jquery.readonly.css'>".
	      "<script type='text/javascript' src='prototype.js'></script>".
	      "<script type='text/javascript' src='jquery-1.4.2.min.js'></script>".
	      "<script type='text/javascript' src='jquery.readonly.js'></script>";
}

function GetBoard() {
	$fp = fopen( "/etc/hostname", 'r' );
	$board = fgets($fp);
	fclose($fp);
	return $board;
}

function IsConfigAuthentified() {
	session_start();
	return ($_SESSION['DbusAuth'] == "yes");
}

function IsDB2JSAuthentified() {
	return ($_SESSION['StatusAuth'] == "yes" || 
			$_SESSION['ServiceAuth'] == "yes");
}

function VerifyConfigAuth() {
	if (!IsConfigAuthentified()) {
		echo "You have no permission to view this page, please login!";
		echo "<meta HTTP-EQUIV='REFRESH' content='1; url=/index.html'>";
		exit(1);
	}
}

function PrintError($error) {
	 if (!empty($error))
	 	echo "<p style='color: red'>Error: $error</p>";
}

function PrintErrorList($array) {
	if (!empty($array)) {		
		foreach($array as $field => $error) {
			echo "Field: <span style='color:red'>$field</span> Error: $error";
		}
		unset($_SESSION['errors']);
	}
}

function forward($site, $time) {
	echo "<meta HTTP-EQUIV='REFRESH' content='".$time."; url=".$site."'>";
}

function SaveIpv4Session($form) {
	$ipAddresses = $_SESSION['lastformvars']['ipv4ip'];
	$gateway = $_SESSION['lastformvars']['ipv4gate'];
	$subnet = $_SESSION['lastformvars']['ipv4subnet'];
	$method = $_SESSION['lastformvars']['ipv4method'];
	$dns = $_SESSION['lastformvars']['ipv4dns'];
	$dnsIgnoreAuto = $_SESSION['lastformvars']['ipv4dnsIgnoreAuto'];
	unset($_SESSION['lastformvars']);
	$form->addIpSettsFrame(4, $method, $ipAddresses, $subnet, $gateway, $dns, $dnsIgnoreAuto);
	$form->addIpSettsFrame(6);
}

function SaveIpv6Session($form) {
	$ipAddresses = $_SESSION['lastformvars']['ipv6ip'];
	$gateway = $_SESSION['lastformvars']['ipv6gate'];
	$subnet = $_SESSION['lastformvars']['ipv6subnet'];
	$method = $_SESSION['lastformvars']['ipv6method'];
	$dns = $_SESSION['lastformvars']['ipv6dns'];
	$dnsIgnoreAuto = $_SESSION['lastformvars']['ipv6dnsIgnoreAuto'];
	unset($_SESSION['lastformvars']);
	$form->addIpSettsFrame(4);
	$form->addIpSettsFrame(6, $method, $ipAddresses, $subnet, $gateway, $dns, $dnsIgnoreAuto);
}

function SavePostinSession() {
	$_SESSION['lastformvars']['ipv'] = $_POST['ipv'];
	$_SESSION['lastformvars']['ipv4method'] = $_POST['ipv4method'];
	$_SESSION['lastformvars']['ipv4ip'] = $_POST['ipv4ip'];
	$_SESSION['lastformvars']['ipv4subnet'] = $_POST['ipv4subnet'];
	$_SESSION['lastformvars']['ipv4gate'] = $_POST['ipv4gate'];
	$_SESSION['lastformvars']['ipv6method'] = $_POST['ipv6method'];
	$_SESSION['lastformvars']['ipv6ip'] = $_POST['ipv6ip'];
	$_SESSION['lastformvars']['ipv6subnet'] = $_POST['ipv6subnet'];
	$_SESSION['lastformvars']['ipv6gate'] = $_POST['ipv6gate'];
	$_SESSION['lastformvars']['ipv6dnsIgnoreAuto'] = $_POST['ipv6dnsIgnoreAuto'];
	$_SESSION['lastformvars']['ipv6dns'] = $_POST['ipv6dns'];
	$_SESSION['lastformvars']['ipv4dnsIgnoreAuto'] = $_POST['ipv4dnsIgnoreAuto'];
	$_SESSION['lastformvars']['ipv4dns'] = $_POST['ipv4dns'];
	$_SESSION['lastformvars']['ssid'] = $_POST['ssid'];
	$_SESSION['lastformvars']['channel'] = $_POST['channel'];
	$_SESSION['lastformvars']['mode'] = $_POST['mode'];
	$_SESSION['lastformvars']['network_auth'] = $_POST['network_auth'];
	$_SESSION['lastformvars']['encryption'] = $_POST['encryption'];
	$_SESSION['lastformvars']['identity'] = $_POST['identity'];
	$_SESSION['lastformvars']['eap_method'] = $_POST['eap_method'];
	$_SESSION['lastformvars']['network_key'] = $_POST['network_key'];
	$_SESSION['lastformvars']['password'] = $_POST['password'];
	$_SESSION['lastformvars']['ca_cert'] = $_POST['ca_cert'];
	$_SESSION['lastformvars']['client_cert'] = $_POST['client_cert'];
	$_SESSION['lastformvars']['anonymous_identity'] = $_POST['anonymous_identity'];
	$_SESSION['lastformvars']['private_key'] = $_POST['private_key'];
	$_SESSION['lastformvars']['ph2_auth'] = $_POST['ph2_auth'];
	$_SESSION['lastformvars']['private_key_password'] = $_POST['private_key_password'];
	$_SESSION['lastformvars']['id'] = $_POST['id'];
	$_SESSION['lastformvars']['txpower'] = $_POST['tx-power']; 
}

function SaveWlanSessionSettings($conn, $form) {
	$network_auth = $_SESSION['lastformvars']['network_auth'];
	$encryption = $_SESSION['lastformvars']['encryption'];
	$identity = $_SESSION['lastformvars']['identity'];
	$ssid = $_SESSION['lastformvars']['ssid'];
	$channel = $_SESSION['lastformvars']['channel'];
	$mode = $_SESSION['lastformvars']['mode'];
	$txpower = $_SESSION['lastformvars']['txpower'];
	$form->addWlanConnSettsFrame($conn->id, $ssid, $mode, $ipVers,
					      '', $channel, $txpower, $conn->autoconnect, 'false');
}
?>
