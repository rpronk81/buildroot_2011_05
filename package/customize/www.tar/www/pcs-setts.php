<?php
include 'common.inc.php';

VerifyConfigAuth();
StyleTitle("PCS Settings");

if (isset($_POST['btn'])) {
	exec("nohup /sbin/pcs_disconnect > /dev/null 2>/dev/null &");	
} else if (isset($_POST['druglibConfig'])) {
		if ($_POST['uploadNewDruglibsOnly'] == "Yes") {
			$val = "true";
		} else {
			$val = "false";
		}
		$output = $val; //store value for display later, because settings are applied in the background:
		exec("nohup /sbin/pcs_disconnect setUploadNewDruglibsOnly ".$val." > /dev/null 2>/dev/null &");
	}
?>
<p>PLEASE NOTE THAT ANY CHANGES ON THIS PAGE WILL CAUSE THE PCS TO RESTART, TEMPORARLY DISRUPTING THE CONNECTION TO THE SPACE ONLINE SUITE.</p>
<br>
<div id = 'pcs'>
	<fieldset style='text-align:center'><legend>Druglib Upload configuration</legend>
<?php
echo "			<form method='POST' action=".$_SERVER['PHP_SELF'].">";
if (isset($_POST['druglibConfig'])) {
	echo "				<p>Settings applied.</p><br>";	
} else {
	$output=trim(exec("/sbin/pcs_disconnect getUploadNewDruglibsOnly"));
}
?>
				<p>
<?php
if( $output == "true") {
	print "					<input type=\"Checkbox\" name=\"uploadNewDruglibsOnly\" value=\"Yes\"  checked />";
} else {
	print "					<input type=\"Checkbox\" name=\"uploadNewDruglibsOnly\" value=\"Yes\" />";
}
?>
					Upload druglibraries only to infusion pumps that contain a druglibrary that was generated before the one to be uploaded.
			</p>
			<input type='submit' name='druglibConfig' value=' Apply '>
		</form>
	</fieldset>
	<hr>
	<fieldset style='text-align:center'><legend>PCS Disconnect</legend>
	<p>This will disconnect this device from the Space OnlineSuite on the device side only. Please do not use this method unless the device could not be disconnected using the Space OnlineSuite.</p>
<?php
echo "		<form method='POST' action=".$_SERVER['PHP_SELF'].">";
if (isset($_POST['btn'])) {
	echo "			<p>PCS Disconnect done.</p><br>";	
}
?>
			<input type='submit' name='btn' value=' PCS Disconnect '>
		</form>
	</fieldset>
</div>
</body>
</html>
