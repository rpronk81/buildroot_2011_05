<?php
include 'common.inc.php';
include 'dbus/dbus_classes.php';
	// Session needed for authentication against dbus php pages
	// gettext initialization
	$language = $_GET["locale"];

	if (count($_POST) > 0) {	// POST method
	}

	global $language;
	$board = GetBoard();

	StyleTitle("Maintenance and software updates");

	print "<br><br><br><br>";
	print "<center>";
	print "<br>Board Version: " . $board;
	print "<br>Current Software Version: ";
	passthru("/sbin/updaterwr --print-fw");
	if ( $board == "spacecom2") {
	// It would be good to enable boot into fallback image on sc2, too
		print "<br>";
		print "<form enctype=\"multipart/form-data\" action=\"../updater.php\" method=\"POST\">";
		print "<br>";
		print "<input type=\"checkbox\" name=\"FactoryDefault\" value=\"1\"/> ";
		print gettext("Restore Factory Defaults after Update");
		print "<br><br>";
		print "<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"67108864\" />";
		print gettext("Choose Image: ");
		print "<input name=\"uploadedfile\" type=\"file\" /><br />";
		print "<br> Please select \"";
		print gettext("Restore Factory Defaults after Update");
		print " when downgrading to a previous version of the firmware.<br>";
		print "<input type=\"submit\" name=\"updateFirmware\" value=\"Update Software\" />";
		print "</form>";
		print "<br>";
	} else if ( $board == "spacecomlite" || $board == "spacecom1" )  {
		print "<br>";
		print "<form enctype=\"multipart/form-data\" action=\"../updater.php\" method=\"POST\" target=\"_top\" style=\"margin-left: 20%; margin-right: 20%; \">";
		print "<br />" . gettext("Clicking the \"Prepare Update\" button will set the system to update state. Afterwards you will be prompted for the new image. While the update is in progress the system will be unusable. When the update is finished, the system will reboot itself.") . "<br /><br />";
		print "<input type=\"submit\" name=\"PrepareUpdate\" value=\"Prepare Update\" />";
		print "</form>";
		print "<br>";
	} else {
		print "<br>";
		print gettext("Unknown board; modify maint.php to provide suitable flashing instructions.");
		print "<br><br>";
		print "<input type=\"submit\" name=\"reboot\" value=\"Update Firmware\" />";
		print "</form>";
		print "<br>";
	}
	print "<hr>";
	print "<br>";
	print "<form action=\"../updater.php\" method=\"POST\">";
	print "<input type=\"hidden\" name=\"Reboot\" value=\"1\"/>";
	print "<input type=\"checkbox\" name=\"FactoryDefault\" value=\"1\"/> ";
	print gettext("Restore Factory Defaults after Reboot");
	print "<br><br>";
	print "<input type=\"checkbox\" name=\"BootFallBack\" value=\"1\"/> ";
	print gettext("Boot into recovery/fallback image");	
	print "<br><br>";
	print "<input type=\"submit\" value=\"";
	print gettext("Reboot SpaceCom");
	print "\"/>";
	print "</form>";
	print "</center>";
	print "</body></html>";
?>

