<?php
session_start();

include 'scom.data.x.base.php';

$DB2JS_FILES= array("scom.pumpdata.js","scom.svccoverdta.js",
    "scom.svcpumpdta.js", "scom.systemdata.js");

doAuth($DB2JS_FILES);
?>