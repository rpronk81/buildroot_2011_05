<?php

include '../common.inc.php';

$TEST_MODE_FILENAME = "/etc/spacecom/db2js_no_auth.flag";
$TEST_MODE_FILE_CONTEND = "vai1eaThahneewiicephotahngieloht";

$DB2JS_FILES=array();
$DB2JS_FOLDER = "/var/run/db2js/";

function printNoAuth()
{
    global $DB2JS_FILES;
    global $DB2JS_FOLDER;
    foreach($DB2JS_FILES as $file) {
        $handle = fopen($DB2JS_FOLDER . $file, "r");
        if ($handle) {
            while (($line = fgets($handle)) !== false) {
                if ($line == "//auth data:\n") {
                    break;
                }
                echo $line;
            }
            fclose($handle);
            echo "\n\n";
        }
    }
}

function debugMode(){
    return file_exists($TEST_MODE_FILENAME) &&
        (file_get_contents($TEST_MODE_FILENAME)!==$TEST_MODE_FILE_CONTEND);
}

function doAuth($files) {

	global $DB2JS_FILES;
	global $DB2JS_FOLDER;

	$DB2JS_FILES = $files;

	if ((! IsDB2JSAuthentified()) && (! debugMode())) {
		echo "db2jsAuthOk=\"False\";\n\n\n";
		printNoAuth();
	} else {
		echo "db2jsAuthOk=\"True\";\n\n\n";
		foreach($DB2JS_FILES as $file) {
			echo file_get_contents($DB2JS_FOLDER . $file);
			echo "\n\n";
		}
	}
}
?>