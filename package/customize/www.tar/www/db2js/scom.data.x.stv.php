<?php
session_start();

include 'scom.data.x.base.php';

$DB2JS_FILES= array("scom.pumpdata.js", "scom.systemdata.js");

doAuth($DB2JS_FILES);

?>