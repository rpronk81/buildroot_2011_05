<?php
ini_set("display_errors", 1);
ini_set("track_errors", 1);
ini_set("html_errors", 1);
error_reporting(E_ALL);
include 'common.inc.php';

VerifyConfigAuth();
StyleTitle("12-/24-Pump support");

$filename="/etc/spacecom/performanceSettings";

if (isset($_POST['btn'])) {
	switch ($_POST['action']) {
		case "12pumps":
		case "24pumpsForced":
			$handle = fopen($filename, 'w');
			fwrite($handle, $_POST['action']);
			fclose($handle);		
			exec("/sbin/updaterwr --reboot");
			break;		
	}
}
echo "<fieldset style='text-align:center'><legend>Status &amp; Settings</legend>";
echo "<form method='POST' action=".$_SERVER['PHP_SELF'].">";
if ($_POST['action'] == "force") {
	echo "Please note, that forcing the 24 pump mode might force the device into a reboot cycle. <br>";
	echo "In that case recovery will only be possible by restoring factory defaults using an usb-stick. <br>";	
	echo "<input type=\"hidden\" name=\"action\" value=\"24pumpsForced\" />";
	echo "<input type='submit' name='Abortbtn' value='Abort' />";
	echo "<input type='submit' name='btn' value='OK' />";
} else {
	if (file_exists($filename)) {
		$handle = fopen($filename, 'r');
		$testResult = trim(fread($handle, 124));
		fclose($handle);
	} else {
		$testResult="12pumps";
	}
	echo "<table border='1'><tr><td><b>Current state</b></td><td>";
	if ($testResult == "24pumpsForced")
	{	
		echo "24 pump mode was forced, system stability can not be guarantied.";	
	} else {
		echo "12 Pump mode is active.<br>";
		echo "Please note that in that mode only 12 pumps will be supported - you can use more, but that might cause reboots.";
	}
	echo "</tr><tr><td><b>Actions</b></td><td>";
	echo "<select name=\"action\" size=\"1\">";
	if ($testResult != "24pumpsForced") {
		echo "	<option value=\"12pumps\" selected>Select 12 pump mode</option>";
		echo "	<option value=\"force\">Force 24 pump mode</option>";
	} else {
		echo "	<option value=\"12pumps\">Select 12 pump mode</option>";
		echo "	<option value=\"force\" selected>Force 24 pump mode</option>";
	}
	echo "</select>";
	echo "<input type='submit' name='btn' value='OK'><br>";
	echo "Note: The device will reboot to perform these actions.";
	echo "</td></tr></table>";	 
}
echo "</form></fieldset>";
?>
<fieldset style='text-align:left'><legend>Information</legend>
<b>12 Pump mode:</b> This mode does only support up to 12 infusion pumps. Should more be used the SpaceCom might reboot ocasionaly. The infusion pumps themselves will not be affected.<br>
<b>24 Pump mode:</b> This mode does support 24 infusion pumps, but system stability can not be guarantied.
</fieldset>
</body>
</html>
