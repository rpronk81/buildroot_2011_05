<?php
include 'common.inc.php';
include 'dbus/dbus_classes.php';
include 'wlan/docs/sshexec.php';

StyleTitle("Database settings");

if (isset($_POST['save'])) {
		$bedid = $_POST['bedid'];
		$len = strlen($bedid);
		if (preg_match('/[\x00-\x2e\x3a-\x40\x7b-\xff]/', $bedid)) {
				PrintError("Bed ID contains an invalid character.");
		} elseif($len < 1 || $len > 15) {
				PrintError("Bed ID must have 1..15 characters.");
		} else {
				$xml_write = new XMLWriter();
				$xml_write->openURI('/etc/spacecom/general.xml');
				$xml_write->writeElement('BedID', $bedid);
				$xml_write->endDocument();
		}
}

if (isset($_POST['save2'])) {
		$hostname = $_POST['hostname'];
		$len = strlen($hostname);
		if (preg_match('/[\x00-\x2d\x3a-\x40\x7b-\xff]/', $hostname)) {
				PrintError("Host name contains an invalid character.");
		} elseif($len < 1 || $len > 253) {
				PrintError("Host name must have 1..253 characters.");
		} else {
				exec("/sbin/wifiBridge.sh -chkEnabled", $output, $ret);
				if ($ret == "1") {
					$cmd = "sed -i 's/OPT_SND=\\\"hostname:.*\\\"/OPT_SND=\\\"hostname:$hostname\\\"/g' /etc/dhcp/udhcpc.conf";
					exec("echo \"command = $cmd\" >> /tmp/lineA");
					ssh_exec($cmd);
					ssh_exec("ifrc wlan0 restart");
				}

				$xml_write = new XMLWriter();
				$xml_write->openURI('/etc/spacecom/hostname.xml');
				$xml_write->writeElement('HostName', $hostname);
				$xml_write->endDocument();
				exec('/sbin/generateDHCPConfig.sh');
		}
}

echo "<form action='db-setts.php' method='POST'>";

$xml_file = new XMLReader();
$xml_file->open("/etc/spacecom/general.xml");
while ($xml_file->read())
{
    if ($xml_file->name == 'BedID') {
        $xml_file->read();
        $val = $xml_file->value;
        break;
    }
}

$xml_file2 = new XMLReader();
$xml_file2->open("/etc/spacecom/hostname.xml");
while ($xml_file2->read())
{
    if ($xml_file2->name == 'HostName') {
        $xml_file2->read();
        $val2 = $xml_file2->value;
        break;
    }
}

echo "<table align='center'><tr>".
     "<td>Bed ID:</td><td><input type='text' name='bedid' maxlength='15' value='".$val."'><input type='submit' name='save' value='Change'</tr>".
     "</table><br />";

echo "<table align='center'><tr>".
     "<td>HostName:</td><td><input type='text' name='hostname' maxlength='253' value='".$val2."'><input type='submit' name='save2' value='Change'</tr>".
     "</table><br />";

$board = GetBoard();

if ($board == "spacecomlite") {
	$string = shell_exec("cat /proc/cpuinfo");
	$array = preg_split("/[\s,]+/",$string);
	$i = 0;
	$len = sizeof($array);
	do{
	  $i++;
	} while($array[$i] != "Serial" && $i < $len);
	$m = $array[$i+2];
	$m = substr($m, -6);
	$m = hexdec($m);
} else {
        $dbus = new Dbus_Connection();
	$devs = $dbus->get_eth_devices();
	$mac = $dbus->getMacAddress($devs[0]);
	$macArray = explode(":", $mac);
	$m = hexdec($macArray[3].$macArray[4].$macArray[5]);
}

$string = shell_exec("cat /proc/cpuinfo");
$array = preg_split("/[\s,]+/",$string);
$i = 0;
$len = sizeof($array);
do{
  $i++;
} while($array[$i] != "boardrevision" && $i < $len);
$hwrev = $array[$i+2];

echo "<table border='1' align='center'>";
echo "<tr><td>OS Version</td><td>".shell_exec("uname -r")."</td></tr>";
if ($board != "spacecomlite") {
	echo "<tr><td>HW Revision</td><td>".$hwrev."</td></tr>";
}
echo "<tr><td>Serial-Nr</td><td>".$m."</td></tr>";
echo "<tr><td>Firmware Version</td><td>".shell_exec("/sbin/updaterwr --print-fw")."</td></tr>";
echo "</table>";

?>
