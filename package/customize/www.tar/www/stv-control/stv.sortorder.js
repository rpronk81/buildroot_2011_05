/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * stv.sortorder.js
 * Javascript-Code: Sortiervorgabe für StatusView
 * Projekt: SpaceOnline, B. Braun Melsungen AG
 * Copyright (c) 2010 by B2A Corporate Marketing GmbH
 * All rights reserved
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Development:
 *	2010-05,06
 * by B2A Corporate Marketing GmbH, Kassel; mailto:dev-AT-b2a-DOT-de
 * Version: 1.5.0
 * Autor: B2A/koe
 * Letzte Bearbeitung: 2010-06-28 15:42
 * durch: Koe
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

statusViewSort.curr =	[ 'slotid' ];	// Sortierkriterien (Liste in eckigen Klammern)
statusViewSort.desc =	[ true ];				// Flag: Absteigende Sortierung (Liste aus true|false in eckigen Klammern)

/*
 *  Die Statusliste kann nach folgenden Kriterien jeweils
 *  auf- oder absteigend sortiert werden:
 *
 *  Sortierkriterium           Kürzel
 *  -------------------------------------------------
 *  Steckplatz (Nr. der Pumpe im System)  'slotid'
 *  Status der Pumpe                      'status'
 *  Pumpentyp                             'pump'
 *  Medikamentname                        'drugname'
 *  Infusionsrate                         'infrate'
 *  Dosisrate )*                          'doserate'
 *  Infundiertes Volumen                  'infvol'
 *  Restlaufzeit                          'remtime'
 *  -------------------------------------------------
 *  )* Eine Sortierung nach der Dosisrate ist wahrscheinlich auf Grund
 *     unterschiedlicher Maßeinheiten nicht angeraten, denn es erfolgt
 *     keine Wertkonvertierung.
 *
 *  Die Sortierkriterien müssen in einer Komma-separierte Liste der
 *  obigen Variablen ›sortCrit‹ zugewiesen werden, wobei die Priorität
 *	von links nach rechts aufsteigend ist etwa:
 *    statusViewSort.curr = [ 'slotid','pump','status' ];
 *
 *  Die Sortierungrichtung ist absteigend (descending), wenn der
 *  Variable ›statusViewSort.desc‹ der Wert ›true‹ zugewiesen ist;
 *  sie ist aufsteigend, wenn der Wert ›false‹ zugewiesen ist.
 *  Die Werte müssen exakt der Anzahl an Sortierkriterien in der
 *  Variable ›statusViewSort.curr‹ entsprechen:
 *    statusViewSort.desc = [ false,false,true  ];
 *
 */
