<?php
	include 'common.inc.php';
	
	function sendFileAndRm($file)
	{		
		header('Content-Description: File Transfer');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename='.basename($file));
		header('Content-Transfer-Encoding: binary');
		header('Expires: 0');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');
		header('Content-Length: ' . filesize($file));		
		readfile($file);
		unlink($file);
		exit;    
	}

	VerifyConfigAuth();

	if (count($_GET) > 0) {	// GET method
		if ($_GET['dump']) {
			$res = exec("/configExport/configExport -dump");
			$res = trim($res);
			if ($res == "")	{
				sendFileAndRm("/tmp/dump.tar.gz.enc");
			}
			else
			{
				echo "<span style='color:red; font-weight:bold;'>DUMP FAILED: ".$res."</span>";
			}
		} else if ($_GET['export']) {
			$cmd="/configExport/configExport ";
			if ($_GET["bcc"]) {
				$cmd .= "-bcc ";
			}
			if ($_GET["bedid"]) {
				$cmd .= "-bedid ";
			}
			if ($_GET["spaceonline"]) {
				$cmd .= "-db2js -spaceonline ";
			}
			if ($_GET["ntp"]) {
				$cmd .= "-ntp ";
			}
			if ($_GET["ftp"]) {
				$cmd .= "-ftp ";
			}
			if ($_GET["network"]) {
				$cmd .= "-network ";
			}

			exec("/sbin/wifiBridge.sh -chkEnabled", $output, $ret);
			if ($ret == "1") {
				if ($_GET["networkwifi"]) {
					$cmd .= "-networkwifi ";
				}
			}

			if ($_GET["pswd"] == $_GET["pswd2"]) {				
				if (preg_match("/^[a-zA-Z0-9._\/-]+$/", $_GET["pswd"])) {
					$cmd .= escapeshellarg($_GET["pswd"]);
					$res = exec($cmd);
					$res = trim($res);
				} else {
					$res = "Password may only consist of letters, numbers and the following signs: ._-/ and may not be empty.";
				}
				if ($res == "")	{
					sendFileAndRm("/tmp/export.tar.gz.enc");
				}
				else
				{
					echo "<span style='color:red; font-weight:bold;'>EXPORT FAILED: ".$res."</span>";
				}
			} else {
				echo "<span style='color:red; font-weight:bold;'>EXPORT FAILED: The entered passwords did not match.</span>";
			}
		}
	}

	if (count($_POST) > 0) {
		if ($_POST["import"]) {
			$res = exec("/configExport/configExport -restore ".escapeshellarg($_FILES['importFile']['tmp_name'])." ".escapeshellarg($_POST['pswd']));
			$res = trim($res);			
			if ($res == "")	
			{
				echo "<span style='color:green; font-weight:bold;'>IMPORT SUCCESSFUL - will restart now.</span>";
				exec ("nohup /bin/sh -c 'sleep 5; /sbin/updaterwr --reboot' > /dev/null 2>&1 &" );
			} else 				
			{
				echo "<span style='color:red; font-weight:bold;'>IMPORT FAILED - Invalid password or export file.</span>";
				syslog(LOG_WARNING, "Settings import failed - Errorcode: ".$res);
			}
		}
	}
	
	global $language;
	$board = GetBoard();

	StyleTitle("Export / Import settings");
	echo "<fieldset><legend>Export settings</legend>";
	echo "<form method='get' action=".$_SERVER['PHP_SELF'].">";
	echo "Export current settings in an aes256 encrypted archive.<br>";
	echo "<input type='checkbox' name='bcc' value='bcc' checked>BCC<br>";
	echo "<input type='checkbox' name='bedid' value='bedid' checked>BedID<br>";
	echo "<input type='checkbox' name='spaceonline' value='spaceonline' checked>SpaceOnline<br>";	
	echo "<input type='checkbox' name='ntp' value='ntp' checked>(S)-NTP settings<br>";
	echo "<input type='checkbox' name='ftp' value='ftp' checked>FTP settings<br>";

	exec("/sbin/wifiBridge.sh -chkEnabled", $output, $ret);
	if ($ret == "1") {
		echo "<input type='checkbox' name='network' value='network'>Network settings SpaceCom2<br>";
		echo "<input type='checkbox' name='networkwifi' value='networkwifi'>Network settings WiFi Bridge<br>";
	}
	else
	{
		echo "<input type='checkbox' name='network' value='network'>Network settings<br>";
	}
	echo "<table border='0'>";
	echo "<tr><td>Password:</td><td><input type='password' name='pswd'></td></tr>";
	echo "<tr><td>Password confirmation:</td><td><input type='password' name='pswd2'></td></tr>";
	echo "</table>";
	echo "Passwords may only consist of letters, numbers and the following signs: ._-/ <br>";
	echo "Spaces are not allowed. <br>";
	echo "<input type='submit' name='export' value='Export'><br>";
	echo "Please note that the export might take a while.";
	print "</form>";
	echo "</fieldset>";
	
	echo "<fieldset><legend>Import settings</legend>";
	echo "<form method='POST' enctype='multipart/form-data' action=".$_SERVER['PHP_SELF'].">";
	echo "<table border='0'>";
	echo "<tr><td>File to import: </td><td><input type='file' name='importFile'></td></tr>";
	echo "<tr><td>Password: </td><td><input type='password' name='pswd'></td></tr>";
	echo "</table>";
	echo "<input type='submit' name='import' value='Import'><br>";
	echo "Please note that the import might take a while and the device will reboot after the import.<br>";
	echo "Please note also that the ip of the device might change, should network settings be part of the file to be imported.";
	print "</form>";
	echo "</fieldset>";
	
	echo "<fieldset><legend>Dump settings, internal data & Log files for Debug purposes</legend>";
	echo "Creates an encrypted file containing data required to analyse potential bugs in the system. That file contains all configuration settings.";
	echo "<form method='get' action=".$_SERVER['PHP_SELF'].">";
	echo "<input type='submit' name='dump' value='DUMP'><br>";
	echo "Please note that the dump might take a while.<br>";
	print "</form>";
	echo "</fieldset>";	
	print "</body></html>";
?>

