<?php
error_reporting(0); 
include '../common.inc.php';
include "validate.php";
VerifyConfigAuth();
HeadJquery("Wireless networks");
?>
<script type="text/javascript">
$(document).ready(function() {
	  switchMode();
	  switchdns_ipv4();
	  switchdns_ipv6();
	  switchMethod_ipv4();
	  switchMethod_ipv6();
	  switchIp();
	  chooseEncrypt();
	});
</script>
</head>
<body>
<?php
/**
 * Creates the wireless form with settings
 */
include "template.php";
include "dbus_classes.php";


$dbus = new Dbus_Connection();

$nav = new NaviBanner();
$nav->render();



if (isset($_POST['chooseC']) || ($_GET['choose']==1)) {
	if(isset($_POST['chConn']) || isset($_GET['conn']))
	{		
		$array = $dbus->get_connections();
		if(isset($_GET['conn'])) {
			$conn = get_spec_conn($_GET['conn'], $array);
		} else {
			$conn = get_spec_conn($_POST['chConn'], $array);
		}

		if ($conn->ipv6Method != 'ignore' && !is_null($conn->ipv6Method)) {
			$ipVers = 6;
		} else {
			$ipVers = 4;
		}
		if($_SESSION['lastformvars']['check']=='false') {
			$ses = $_SESSION['lastformvars'];
			$form = new NetworkForm("wlanForm", "wireless.php");
			SaveWlanSessionSettings($conn, $form);
			if ($_SESSION['lastformvars']['ipv']=='IPv4') {
				SaveIpv4Session($form);
			} else {
				SaveIpv6Session($form);
			}
			if($ses['check']=='false') {
			$form->addWlanSecFrame($ses['network_auth'], array($ses['eap_method']), false, $ses['network_key'], $ses['identity'],
						$ses['password'], $ses['ca_cert'], $ses['client_cert'], $ses['anonymous_identity'],
						$ses['private_key'], $ses['ph2_auth'], $ses['private_key_password'], $ses['encryption']);
			} else {

				$form->addWlanSecFrame($keyMgmt, $eap,false, $key, $ident,
				$pwd, substr($cac, 7, -1),
				substr($uac, 7, -1), $aident, substr($pk, 7, -1),
				$phase2auth, $ppwd);
			}
			$form->addHidden("path", $conn->ConnPath);
			$form->addBr();
			
			$form->addButton("save", "Save changes");
			$form->addBr();
			$form->render();
			PrintErrorList($_SESSION['errors']->error);
		} else {
			
			$form = new NetworkForm("wlanForm", "wireless.php");
			$form->addWlanConnSettsFrame($conn->id, byteArray2Text($conn->ssid), $conn->mode, $ipVers,
					      '', $conn->channel, $conn->tx_power, $conn->autoconnect, 'false');
	
			$dnse = array();
			foreach($conn->ipv4Dns as $dns) {
				$dnse[] = long2ip(htonl($dns));
			}
	
			$compIp = dbusIp2Ip4String($conn->ipv4Addresses);
			$form->addIpSettsFrame(4, $conn->ipv4Method, $compIp['ip'],
						$compIp['subnet'], $compIp['gateway'],
						implode(",", $dnse), $conn->ipv4DnsIgnoreAuto);
	
			$dnse_ipv6 = array();
			foreach($conn->ipv6Dns as $dns) {
				$dnse_ipv6[] = bytestoipv6($dns);
			}
			$compIp = dbusIp2Ip6String($conn->ipv6Addresses);
			$form->addIpSettsFrame(6, $conn->ipv6Method, $compIp['ip'],
						$compIp['prefix'], "", implode(",", $dnse_ipv6), $conn->ipv6DnsIgnoreAuto);

			$cac = '';
			if(isset($conn->security->x8021x->caCert)) {
				
				foreach($conn->security->x8021x->caCert as $a) {
					$cac .= (chr($a));
				}
			}
			$uac = '';
			if(isset($conn->security->x8021x->client_cert)) {
				
				foreach($conn->security->x8021x->client_cert as $a) {
					$uac .= (chr($a));
				}
			}
			$pk = '';
			if(isset($conn->security->x8021x->private_key)) {
				
				foreach($conn->security->x8021x->private_key as $a) {
					$pk .= (chr($a));
				}
			}
			$eap='';
			$key='';
			$ident='';
			$pwd='';
			$keyMgmt = '';
			$ppwd = '';
			$aident = '';
			$phase2auth = '';
			
			if(isset($conn->security->x8021x->eap))
				$eap = $conn->security->x8021x->eap;
			if($conn->security->keyMgmt == 'none') {
				if(isset($conn->security->wepKey0))
					$key = $conn->security->wepKey0;
			} else {
				if(isset($conn->security->psk))
					$key = $conn->security->psk;
			}
			if(isset($conn->security->x8021x->identity))
				$ident = $conn->security->x8021x->identity;
			if(isset($conn->security->x8021x->password))
				$pwd = $conn->security->x8021x->password;
			if($conn->security->keyMgmt == 'none'){
				$keyMgmt = $conn->security->authAlg;
			} else {
				$keyMgmt = $conn->security->keyMgmt;
			}
			if(isset($conn->security->x8021x->private_key_pwd))
				$ppwd = $conn->security->x8021x->private_key_pwd;
			if(isset($conn->security->x8021x->anonymous_ident))
				$aident = $conn->security->x8021x->anonymous_ident;
			if(isset($conn->security->x8021x->phase2Auth))
				$phase2auth = $conn->security->x8021x->phase2Auth;
			$form->addWlanSecFrame($keyMgmt, $eap,false, $key, $ident,
						$pwd, substr($cac, 7, -1),
						substr($uac, 7, -1), $aident, substr($pk, 7, -1),
						$phase2auth, $ppwd);
			$form->addHidden("path", $conn->ConnPath);
			$form->addBr();
			$form->addButton("save", "Save changes");
			$form->render();
		}
	}
} else if (isset($_POST['deleteC'])) {
	echo "<p>Do you really want to delete this Connection?</p>";
	echo "<form action='wireless.php' method='POST'>".
	     "<input type='submit' name='reallyDel' value='Yes'> ".
	     "<input type='submit' name='abortDel' value='No'>".
	     "<input type='hidden' name='chConn' value='".$_POST['chConn']."'></form>";

} else if (isset($_POST['reallyDel'])) {
	$dbus->delete_connection($_POST['chConn']);
	echo "Connection deleted!";

	// If a network has been deleted, update the ssid in the driver, 
    // in case we are running on a hidden network.
	exec("touch /tmp/do_fgscan");

	forward("wireless.php",1);
} else if (isset($_POST['abortDel'])) {
	echo "Not deleted!";
	forward("wireless.php", 1);
} else if (isset($_POST['save'])) {
	$array = $dbus->get_connections();
	
	$conn = get_spec_conn($_POST['path'], $array);

	if(isset($_FILES['ca_cert'])) {
		$cac = saveUploadedFile($_FILES['ca_cert']);
		if($cac != false)
			$_POST['ca_cert'] = $cac;
	} else if (isset($conn->security->x8021x->caCert)) {
		$_POST['ca_cert'] = $conn->security->x8021x->caCert;
	}
	if(isset($_FILES['client_cert'])) {
		$clc = saveUploadedFile($_FILES['client_cert']);
		if($clc != false)
			$_POST['client_cert'] = $clc;
	} else if (isset($conn->security->x8021x->client_cert)) {
		$_POST['client_cert'] = $conn->security->x8021x->client_cert;
	}
	if(isset($_FILES['private_key'])) {
		$pk = saveUploadedFile($_FILES['private_key']);
		if($pk != false)
			$_POST['private_key'] = $pk;
	} else if (isset($conn->security->x8021x->client_cert)) {
		$_POST['private_key'] = $conn->security->x8021x->private_key;
	}
	SavePostinSession($_POST); 
	$v = new Validator();
	$check = true;
	if($_POST['ipv'] == 'IPv4' && $_POST['ipv4method'] != 'auto') {

		if(!$v->check_ipv4($_POST['ipv4ip'], "ipv4address")) {
			$check = false;
		}
			
		if(!$v->check_ipv4($_POST['ipv4subnet'], "ipv4subnetmask")) {
			$check = false;
		}
			
		if(!$v->check_ipv4_gateway($_POST['ipv4gate'], "ipv4gateway")) {
			$check = false;
		}
	} else if($_POST['ipv'] == 'IPv4' && $_POST['ipv4method'] == 'auto') {

	} else if ($_POST['ipv'] == 'IPv6' && $_POST['ipv6method'] != 'auto') {

		if(!$v->check_ipv6($_POST['ipv6ip'], "ipv6address")) {
			$check = false;
		}
			
		if(!$v->check_ipv6_subnetmask($_POST['ipv6subnet'], "ipv6subnetmask")) {
			$check = false;
		}
			
		if(!$v->check_ipv6_gateway($_POST['ipv6gate'], "ipv6gateway")) {
			$check = false;
		}
			
	} else if($_POST['ipv'] == 'IPv6' && $_POST['ipv6method'] == 'auto') {

	}
	if(($_POST['ipv'] == 'IPv4' && $_POST['ipv4dnsIgnoreAuto'] == 'true')||($_SESSION['lastformvars']['ipv'] == 'IPv4' && $_SESSION['lastformvars']['ipv4dnsIgnoreAuto'] == 'true')) {
	
		if(!$v->check_ipv4_dns($_POST['ipv4dns'], "ipv4dns")) {
			$check = false;
		}
			
	} else if($_POST['ipv'] == 'IPv6' && $_POST['ipv6dnsIgnoreAuto'] == 'true') {
		if(!$v->check_ipv6_dns($_POST['ipv6dns'], "ipv6dns")) {
			$check = false;
		}
			
	}
    
	if(!$v->check_ssid($_POST['ssid']))
		$check = false;
	if(isset($_POST['channel'])){
		if(!$v->check_channel_id($_POST['channel'], "channel"))
			$check = false;
	}
	if($_POST['network_auth'] == 'wpa-psk'){
		if(!$v->check_networkkey_wpa($_POST['network_key'], $_POST['keyFormat']))
			$check = false;
	} else if($_POST['network_auth'] == 'open' || $_POST['network_auth'] == 'shared') {
		if($_POST['encryption'] == 'wep64') {
			if(!$v->check_networkkey_wep64($_POST['network_key'], "networkkey wep64", $_POST['keyFormat']))
				$check = false;
		}
		else if ($_POST['encryption'] == 'wep128') {
			if(!$v->check_networkkey_wep128($_POST['network_key'], $_POST['keyFormat']))
				$check = false;
		}
	} else if ($_POST['network_auth'] == 'wpa-eap') {
		if ($_POST['eap_method'] != 'tls' && ($_POST['identity'] != '' && $_POST['anonymous_identity'] == '')){
			if(!$v->check_password($_POST['password']))
				$check = false;
		}
		if ($_POST['identity'] != ''){
			if(!$v->check_identity($_POST['identity']))
				$check = false;
		} else {
			if(!$v->check_identity($_POST['anonymous_identity']))
				$check = false;
		}
	}

	// Update the ssid in the driver, in case we are running on a hidden network.
	exec("touch /tmp/do_fgscan");

	if($check) {
		if(createConstructFromPost("802-11-wireless", $_POST)) {
			$construct = createConstructFromPost("802-11-wireless", $_POST);
			$dbus->update_connection($_POST['path'], $construct);

			unset($_SESSION['lastformvars']);
			unset($_SESSION['errors']);
			echo "updating";	
			forward("controller.php", 2);
		} else {
			echo "Error! Connectionlist is full!";
			$_SESSION['errors'] = $v;
			$_SESSION['lastformvars']['check'] = 'false';
			echo "updating";
			forward("controller.php", 2);
		}
	} else {
		$_SESSION['errors'] = $v;
		$_SESSION['lastformvars']['check'] = 'false';
		forward("wireless.php?choose=1&conn=".$_POST['path']."", 0);
	}
} else {
	$array = $dbus->get_connections();
	$wlans= array();
	echo "<fieldset><legend>WLANs</legend>";
	$devs = $dbus->get_wlan_devices();

	foreach($array as $ar) {
		if($ar->type == '802-11-wireless'){
				$wlans[] = array('show'=>$ar->id, 'value'=>$ar->ConnPath);

		}
	}
	asort($wlans);
	if (sizeof($wlans)>0) {
		$list = new ConnectionList("chConn", array("chooseC", "Edit"),
					    array("deleteC", "Delete"), "wireless.php");
		$list->addMore($wlans);
		$list->render();
		echo "</fieldset><br />";
	} else {
		PrintError("No connections Available");
		echo "</fieldset><br />";
	}
	if(isset($devs[0])) {
		$mac = $dbus->getMacAddress($devs[0]);
		echo "<p id='mac'>MAC-Address: ".$mac."</p>"; 
	}
}

?>
</body>
</html>
