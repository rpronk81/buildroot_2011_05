
function addOption(selectbox,text,value)
{
	var optn = document.createElement("OPTION");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
}

function switchMode() 
{
	var mode = document.getElementById('mode').value;
	var fieldset = document.getElementsByTagName("fieldset")[0];
	var trs = fieldset.getElementsByTagName("tr");
	if ( mode == 'infrastructure') 
	{
		$('#network_auth').readonly(false);
	} else {
		document.getElementById('network_auth').selectedIndex = 0;
		$('#network_auth').readonly(true);
		chooseEncrypt();
	}
}

function switchdns_ipv4() 
{
	var mode = document.getElementsByName('ipv4dnsIgnoreAuto')[0].value;
	var fieldset = document.getElementsByTagName("fieldset")[1];
	var trs = fieldset.getElementsByTagName("tr");
	if ( mode == 'false') {
			trs[5].style.display = "none";
		
	} else {
			trs[5].style.display = "";
	}
}

function switchdns_ipv6() 
{
	var mode = document.getElementsByName('ipv6dnsIgnoreAuto')[0].value;
	var fieldset = document.getElementsByTagName("fieldset")[2];
	var trs = fieldset.getElementsByTagName("tr");
	if ( mode == 'false') {
			trs[5].style.display = "none";
		
	} else {
			trs[5].style.display = "";
	}
}

function switchMethod_ipv4()
{

	var s = document.getElementById('method_ipv4').value;
	var fieldset = document.getElementsByTagName("fieldset")[1];
	var trs = fieldset.getElementsByTagName("tr");
	
	if ( s == 'auto') {
		for(i=1;i<4;i++) {
			trs[i].style.display = "none";
		}
	} else {
		for(i=1;i<4;i++) {
			trs[i].style.display = "";
		}
	}

}

function switchMethod_ipv6()
{

	var s = document.getElementById('method_ipv6').value;
	var fieldset = document.getElementsByTagName("fieldset")[2];
	var trs = fieldset.getElementsByTagName("tr");
	
	if ( s == 'auto') {
		for(i=1;i<4;i++) {
			trs[i].style.display = "none";
		}
	} else {
		for(i=1;i<4;i++) {
			trs[i].style.display = "";
		}
	}

}

function switchIp()
{
	var s = document.getElementById('ipv').selectedIndex;
	var name = 'ipv';
	if (s == 0) {
		document.getElementById(name+"4").style.display = "inline";
		document.getElementById(name+"6").style.display = "none";
	} else {
		document.getElementById(name+"4").style.display = "none";
		document.getElementById(name+"6").style.display = "inline";
	}
}

function chooseEncrypt()
{
	

	
	switch (document.getElementById("network_auth").selectedIndex) {
	case 0:	
		document.getElementById("None").style.display = "";
		document.getElementById("enc").style.display = "";
		break;
	case 1:
		document.getElementById("None").style.display = "none";
		document.getElementById("enc").style.display = "";
		document.getElementById("encryption").selectedIndex = 1;
		break;
	case 2:
	case 3:
		document.getElementById("enc").style.display = "none";
		break;
	default:		
		break;
	}

	chooseEAP();
}

function chooseEAP()
{
	if (document.getElementById("network_auth").selectedIndex == 3){		  
		document.getElementById("eapMethod").style.display = "";
		chooseEAP2();
		document.getElementById("key").style.display = "none";

	} else if (document.getElementById("network_auth").selectedIndex == 2){
		turnEAPOff();
		document.getElementById("key").style.display = "";
		document.getElementById("eapMethod").style.display = "none";
		document.getElementById("keyFormat").style.display = "";
		document.getElementById("keyFormat").selectedIndex = 0;
		
		document.getElementById("keyFormat").options[0].style.display ="none";
		document.getElementById("keyFormat").options[1].style.display ="none";
		document.getElementById("keyFormat").options[2].style.display ="none";
		document.getElementById("keyFormat").options[3].style.display ="none";
		document.getElementById("keyFormat").options[4].style.display ="";
		document.getElementById("keyFormat").options[5].style.display ="";
		document.getElementById("keyFormat").selectedIndex = 0;			
		text = document.getElementsByName("network_key")[0].value;
		switch(text.length){
		  case 64:
			document.getElementById("keyFormat").options[5].selected = "true";
		  break;
		  default:
			document.getElementById("keyFormat").options[4].selected = "true";
		  break;
		}

		
	} else if (document.getElementById("encryption").options[document.getElementById("encryption").selectedIndex].value == "wep64" ||
		   document.getElementById("encryption").options[document.getElementById("encryption").selectedIndex].value == "wep128") {
		turnEAPOff();
		document.getElementById("key").style.display = "";
		document.getElementById("eapMethod").style.display = "none";
		document.getElementById("keyFormat").style.display = "";
		document.getElementById("keyFormat").selectedIndex = 0;
		if(document.getElementById("encryption").options[document.getElementById("encryption").selectedIndex].value == "wep64"){
			document.getElementById("keyFormat").options[0].style.display ="";
			document.getElementById("keyFormat").options[1].style.display ="";
			document.getElementById("keyFormat").options[2].style.display ="none";
			document.getElementById("keyFormat").options[3].style.display ="none";
			document.getElementById("keyFormat").options[4].style.display ="none";
			document.getElementById("keyFormat").options[5].style.display ="none";
			document.getElementById("keyFormat").selectedIndex = 0;			
			text = document.getElementsByName("network_key")[0].value;
			switch(text.length){
			  case 5:
				document.getElementById("keyFormat").options[0].selected = "true";
			  break;
			  case 10:
				document.getElementById("keyFormat").options[1].selected = "true";
			  break;
			}

		} else {
			document.getElementById("keyFormat").options[0].style.display ="none";
			document.getElementById("keyFormat").options[1].style.display ="none";
			document.getElementById("keyFormat").options[2].style.display ="";
			document.getElementById("keyFormat").options[3].style.display ="";
			document.getElementById("keyFormat").options[4].style.display ="none";
			document.getElementById("keyFormat").options[5].style.display ="none";
			document.getElementById("keyFormat").selectedIndex = 2;
			text = document.getElementsByName("network_key")[0].value;
			switch(text.length){
			  case 13:
				document.getElementById("keyFormat").options[2].selected = "true";
			  break;
			  case 26:
				document.getElementById("keyFormat").options[3].selected = "true";
			  break;
			}
		}
		
	} else {
		turnEAPOff();
		document.getElementById("key").style.display = "none";
		document.getElementById("eapMethod").style.display = "none";
	}
}

function chooseEAP2 ()
{
	turnEAPOff();
	$('#ph2_auth').readonly(false);

	switch (document.getElementById("eap_method").selectedIndex) {
	case 0:
		document.getElementById("ident").style.display = "";
		document.getElementById("ca_c").style.display = "";
		document.getElementById("u_c").style.display = "";
		document.getElementById("private_key").style.display = "";
		document.getElementById("private_key_password").style.display = "";
		document.getElementById("ca_c2").style.display = "";
		document.getElementById("ua_c2").style.display = "";
		document.getElementById("pk2").style.display = "";
		break;
	case 1:
		document.getElementById("ident").style.display = "";
		document.getElementById("ca_c").style.display = "";
		document.getElementById("ca_c2").style.display = "";
		document.getElementById("a_ident").style.display = "";
		document.getElementById("phase2_auth").style.display = "";
		document.getElementById("pwd").style.display = "";
		break;
	case 2:
	case 4:
		document.getElementById("ident").style.display = "";
		document.getElementById("pwd").style.display = "";
		break;
	case 3:
		document.getElementById("ca_c").style.display = "";
		document.getElementById("ca_c2").style.display = "";
		document.getElementById("a_ident").style.display = "";
		document.getElementById("phase2_auth").style.display = "";
		document.getElementById("ident").style.display = "";
		document.getElementById("pwd").style.display = "";
		$('#ph2_auth').readonly(true);
		document.getElementById("ph2_auth").selectedIndex = 2;
		break;
	}
}

function turnEAPOff()
{
	document.getElementById("ident").style.display = "none";
	document.getElementById("pwd").style.display = "none";
	document.getElementById("ca_c").style.display = "none";
	document.getElementById("u_c").style.display = "none";
	document.getElementById("private_key").style.display = "none";
	document.getElementById("private_key_password").style.display = "none";
	document.getElementById("a_ident").style.display = "none";
	document.getElementById("phase2_auth").style.display = "none";
	document.getElementById("ca_c2").style.display = "none";
	document.getElementById("ua_c2").style.display = "none";
	document.getElementById("pk2").style.display = "none";
	document.getElementById("keyFormat").style.display = "none";
	document.getElementById("keyFormat").options[0].style.display ="none";
	document.getElementById("keyFormat").options[1].style.display ="none";
	document.getElementById("keyFormat").options[2].style.display ="none";
	document.getElementById("keyFormat").options[3].style.display ="none";
}

function keyformat()
{
	var length = document.getElementById("keyFormat").options[document.getElementById("keyFormat").selectedIndex].value;
	document.getElementsByName("network_key")[0].maxLength = length;
	document.getElementsByName("network_key")[0].value = "";
}
