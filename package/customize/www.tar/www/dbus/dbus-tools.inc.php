<?php 
session_start();
if($_SESSION['DbusAuth'] != "yes") {
	 echo "You have no permission to view this page, please login!";
	 echo "<meta HTTP-EQUIV='REFRESH' content='1; url=../index.html'>";
	 exit(1);
}
?>
<?php
class uuid {
    /**
     * This class enables you to get real uuids using the OSSP library.
     * Note you need php-uuid installed.
     * On my system 1000 UUIDs are created in 0.0064 seconds.
     *
     * @author Marius Karthaus
     *
     */
   
    protected $uuidobject;
   
    /**
     * On long running deamons i've seen a lost resource. This checks the resource and creates it if needed.
     *
     */
    protected function create() {
        if (! is_resource ( $this->uuidobject )) {
            uuid_create ( $this->uuidobject );
        }
    }
   
    /**
     * Return a type 1 (MAC address and time based) uuid
     *
     * @return String
     */
    public function v1() {
        $this->create ();
        uuid_make ( $this->uuidobject, UUID_MAKE_V1 );
        uuid_export ( $this->uuidobject, UUID_FMT_STR, $uuidstring );
        return trim ( $uuidstring );
    }
   
    /**
     * Return a type 4 (random) uuid
     *
     * @return String
     */

    public function v4() {
/*
        $this->create ();
        uuid_make ( $this->uuidobject, UUID_MAKE_V4 );
        uuid_export ( $this->uuidobject, UUID_FMT_STR, &$uuidstring );
        return trim ( $uuidstring );
*/



/* From: http://www.php.net/manual/en/function.uniqid.php#94959 we can later reqeite the rest too */

  return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        // 32 bits for "time_low"
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

        // 16 bits for "time_mid"
        mt_rand( 0, 0xffff ),

        // 16 bits for "time_hi_and_version",
        // four most significant bits holds version number 4
        mt_rand( 0, 0x0fff ) | 0x4000,

        // 16 bits, 8 bits for "clk_seq_hi_res",
        // 8 bits for "clk_seq_low",
        // two most significant bits holds zero and one for variant DCE1.1
        mt_rand( 0, 0x3fff ) | 0x8000,

        // 48 bits for "node"
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
    );


    }
   
    /**
     * Return a type 5 (SHA-1 hash) uuid
     *
     * @return String
     */
    public function v5() {
        $this->create ();
        uuid_make ( $this->uuidobject, UUID_MAKE_V5 );
        uuid_export ( $this->uuidobject, UUID_FMT_STR, $uuidstring );
        return trim ( $uuidstring );
    }
}

/** 
 * Send a POST requst using cURL 
 * @param string $url to request 
 * @param array $post values to send 
 * @param array $options for cURL 
 * @return string 
 */ 


function curl_post($url, $post = NULL, array $options = array()) 
{ 
    $defaults = array( 
        CURLOPT_POST => 1, 
        CURLOPT_HEADER => 0, 
        CURLOPT_URL => $url, 
        CURLOPT_FRESH_CONNECT => 1, 
        CURLOPT_RETURNTRANSFER => 1, 
        CURLOPT_FORBID_REUSE => 1, 
        CURLOPT_TIMEOUT => 4, 
        CURLOPT_POSTFIELDS => $post 
    ); 

    $ch = curl_init(); 
    curl_setopt_array($ch, ($options + $defaults)); 
    //FIX for TLS Connections adding and updating:
    curl_setopt($ch,CURLOPT_HTTPHEADER,array("Expect:"));

    if( ! $result = curl_exec($ch)) 
    { 
        trigger_error(curl_error($ch)); 
    } 
    curl_close($ch); 
    return $result; 
} 

/** 
 * converts an ipv6address to byte array
 * @param string $ipv6_addr_string to convert 
 * @return array 
 */ 
function ipv6tobytes($ipv6_addr_string)
{
    $tmp_str = inet_pton($ipv6_addr_string);
    $result = array();
    for ($i = 0; $i < 16; $i++) {
        $result[] = ord($tmp_str[$i]);
    }

    return $result;
}
/** 
 * converts a bytearray to an ipv6address
 * @param array $ipv6_byte_array to convert
 * @return string 
 */ 
function bytestoipv6($ipv6_byte_array)
{
    $result = '';
    for ($i = 0; $i < 16; $i++) {
        $result .= chr($ipv6_byte_array[$i]);
    }
 
    return inet_ntop($result);
}

 
function htonl($ip)
{
    $val = unpack('Nbig', pack('L', $ip));
    return $val['big'];
}

function htonl2($ip)
{
    $val = unpack('Lbig', pack('N', $ip));
    return $val['big'];
}

/** 
 * reverses ipaddress blocks
 * @param $ipFalse to reverse
 * @return string 
 */
function revIp_shift($iplong) {
	for($i = 0; $i<32; $i=$i+8) {
		$shifted = $iplong>>$i;
		$array_shifted = unpack('C', pack('C', $shifted));
		$arrays[]=$array_shifted;
	}

	foreach($arrays as $array)
	$ergarray[]= $array[1]; 
	
	return implode('.' , $ergarray);	 
}


function revIp($ipFalse)
{
	$arrIP = explode('.', $ipFalse);
	$arrIPReverse =array_reverse($arrIP);
	$IP = implode('.', $arrIPReverse);
	return $IP;
}
/** 
 * converts a bytearray to string
 * @param $byteArray to convert
 * @return string 
 */

function byteArray2Text($byteArray)
{
	$result = array();
	foreach ($byteArray as $byte) {
		$result[] = chr($byte);
	}
	$result = implode('', $result);
	return $result;
}

/** 
 * converts a string to bytearray
 * @param $text to convert
 * @return array of bytes
 */
function text2ByteArray($text)
{
	$result = array();
	foreach (str_split($text) as $z) {
		$result[] = ord($z);
	}
	return $result;
}
/**
 * @param path
 * @param dbusdataarray
 * @return dbusdataarray for specified path
 */
function get_spec_conn($connPath, $connArray)
{
	$result = array();
	foreach ($connArray as $conn) {
		if ($conn->ConnPath == $connPath) {
			$result = $conn;
			break;
		}
	}
	return $result;
}
/** 
 * converts an ip4address to dbusipformat
 * @param array $ipString to convert
 * @param array $subnetString to convert
 * @param array $gatewayString to convert
 * @return array within addresses in dbusformat 
 */

function ip4String2DbusIp ($ipString, $subnetString='', $gatewayString='') 
{
	$result = array();
	$ipArray = explode(",", $ipString);
	$subnetArray = explode(",", $subnetString);
	if($gatewayString == '')
		$gatewayString = "0.0.0.0";
	$gatewayArray = explode(",", $gatewayString);
	
	for ($x = 0; $x < sizeof($ipArray); $x++) {
		$result[$x][0] = htonl2(ip2long($ipArray[$x]));
//		$result[$x][0] = ip2long(htonl(ip2long($ipArray[$x])));
		if(isset($subnetArray[$x])) {
			$result[$x][1] = strlen(preg_replace("/0/", "", decbin(ip2long($subnetArray[$x]))));
		} else {
			$result[$x][1] = 0;
		}
		if(isset($gatewayArray[$x])) {
			$result[$x][2] =  htonl2(ip2long($gatewayArray[$x]));
//			$result[$x][2] = ip2long(htonl(ip2long($gatewayArray[$x])));
		} else {
			$result[$x][2] = 0;
		}
	}

	return $result;
}

/** 
 * converts an ip6address to dbusipformat
 * @param array $ipString to convert
 * @param array $subnetString to convert
 * @param array $gatewayString to convert
 * @return array within addresses in dbusformat 
 */
function ip6String2DbusIp ($ipString, $subnetString, $gatewayString) 
{
	$result = array();
	$ipArray = explode(",", $ipString);
	$subnetArray = explode(",", $subnetString);
	if($gatewayString == '')
		$gatewayString = "0:0:0:0:0:0:0:0";
	$gatewayArray = explode(",", $gatewayString);
	
	for ($x = 0; $x < sizeof($ipArray); $x++) {
		$result[$x][0] = ipv6tobytes($ipArray[$x]);
		$result[$x][1] = (int) $subnetArray[$x];
		$result[$x][2] = ipv6tobytes($gatewayArray[$x]);
		
	}

	return $result;
}

/** 
 * converts a dbusiparray to normal format
 * @param array $dbusArray to convert
 * @return array within addresses in normal format 
 */

function dbusIp2Ip4String ($dbusArray)
{
	$result['ip'] = '';
	$result['subnet'] = '';
	$result['gateway'] = '';
	$i = 0;
	foreach ($dbusArray as $compIp) {
		if($i == 0) {
			$result['ip'] .= long2ip(htonl($compIp[0]));
			$result['subnet'] .= CIDRtoMask($compIp[1]);
			$result['gateway'] .= long2ip(htonl($compIp[2]));
		} else {
			$result['ip'] .= ",".long2ip(htonl($compIp[0]));
			$result['subnet'] .= ",".CIDRtoMask($compIp[1]);
			$result['gateway'] .= ",".long2ip(htonl($compIp[2]));
		}
		$i++;
	}
	
	return $result;
}

//function dbusIp2Ip4String ($dbusArray)
//{
//	$result['ip'] = '';
//	$result['subnet'] = '';
//	$result['gateway'] = '';
//	$i = 0;
//	foreach ($dbusArray as $compIp) {
//		if($i == 0) {
//			$result['ip'] .= revIp_shift(($compIp[0]));
//			$result['subnet'] .= CIDRtoMask($compIp[1]);
//			$result['gateway'] .= revIp_shift(($compIp[2]));
//		} else {
//			$result['ip'] .= ",".revIp_shift(($compIp[0]));
//			$result['subnet'] .= ",".CIDRtoMask($compIp[1]);
//			$result['gateway'] .= ",".revIp_shift(($compIp[2]));
//		}
//		$i++;
//	}
//	
//	return $result;
//}
/** 
 * converts a prefix to normal subnetmaskformat
 * @param int $int prefix to convert
 * @return string within normal subnetmaskformat
 */
function CIDRtoMask($int)
{
	return long2ip(-1 << (32 - (int)$int));
}

/** 
 * converts a dbusiparray to normal format
 * @param array $dbusArray to convert
 * @return array within addresses in normal format 
 */
function dbusIp2Ip6String ($dbusArray)
{
	$result['ip'] = '';
	$result['prefix'] = '';
	$result['gateway'] = '';
	$i = 0;
	foreach ($dbusArray as $compIp) {
		if ($i == 0) {
			$result['ip'] .= bytestoipv6($compIp[0]);
			$result['prefix'] .= $compIp[1];
			$result['gateway'] .= bytestoipv6($compIp[2]);
		} else {
			$result['ip'] .= ",".bytestoipv6($compIp[0]);
			$result['prefix'] .= ",".$compIp[1];
			$result['gateway'] .= ",".bytestoipv6($compIp[2]);
		}
		$i++;
	}

	return $result;
}
/** 
 * saves a file on hdd
 * @param $FileArray (postarray element)
 * @return path or false 
 */
function saveUploadedFile($FileArray)
{
	$target = "/etc/NetworkManager/system-connections/".basename($FileArray['name']) ;

	if(move_uploaded_file($FileArray['tmp_name'], $target)) {
		chmod($target, 0600);
		return $target;
	} else {
		return false;
	}
	
}
/**
 * @param type for example: 802-11-wireless
 * @param form postarray
 * @return dbus conform array
 */
function createConstructFromPost($type, $PostArray, $new='false')
{
	$uuid = new uuid();
	
	
	if(SetConnName($PostArray['id'], $new)) {
		//get index number for saving as uuid
		$arr = preg_split('/\./',SetConnName($PostArray['id'], $new));
		$props = array(
				'connection' => array(
					'id' => array('s', SetConnName($PostArray['id'], $new)),
					'uuid' => array('s', $arr[1]),
					'type' => array('s', $type),
					'autoconnect' => array('b', true)
				)
			);
	} else {
		return 0;
	}

	if ($PostArray['ipv'] == 'IPv4') {
		

		

		$props['ipv4']['method'] = array('s', $PostArray['ipv4method']);
		if ($PostArray['ipv4method'] != 'auto') {
			$props['ipv4']['addresses'] = array('aau', ip4String2DbusIp(
										$PostArray['ipv4ip'],
										$PostArray['ipv4subnet'],
										$PostArray['ipv4gate']));
		}

		if($PostArray['ipv4dnsIgnoreAuto'] == 'true') {

			$ds = explode(",", $PostArray['ipv4dns']);
			$dns = array();
			foreach ($ds as $d) {
				$dns[] = htonl2(ip2long($d));
// 				$dns[] = ip2long(revIp($d));
			}
			if(sizeof($dns) > 0) {
				$props['ipv4']['dns'] = array('au', $dns);
			}
			if($PostArray['ipv4dnsIgnoreAuto']) {
				$props['ipv4']['ignore-auto-dns'] = array('b', (bool)$PostArray['ipv4dnsIgnoreAuto']);
			}
		}
	}
	if ($PostArray['ipv'] == 'IPv6') {

		
		$props['ipv6']['method'] = array('s', $PostArray['ipv6method']);
		if($PostArray['ipv6method'] != 'auto') { 
			$props['ipv6']['addresses'] = array('a(ayuay)', ip6String2DbusIp(
										$PostArray['ipv6ip'],
										$PostArray['ipv6subnet'],
										$PostArray['ipv6gate']));
		}
		if($PostArray['ipv6dnsIgnoreAuto'] == 'true') {
			$ds = explode(",", $PostArray['ipv6dns']);
			$dns = array();
			foreach ($ds as $d) {
				$dns[] = ipv6tobytes($d);
			}
			if(sizeof($dns) > 0) {
				$props['ipv6']['dns'] = array('aay', $dns);
			}
			if($PostArray['ipv6dnsIgnoreAuto']) {
				$props['ipv6']['ignore-auto-dns'] = array('b', (bool)$PostArray['ipv6dnsIgnoreAuto']);
			}
		}
	}	


	if ($type == '802-11-wireless') {

		$props['802-11-wireless']['ssid'] = array('ay', text2ByteArray($PostArray['ssid']));
		$props['802-11-wireless']['mode'] = array('s', $PostArray['mode']);
		if(isset($PostArray['tx-power'])) {
			$props['802-11-wireless']['tx-power'] = array('u', (int)$PostArray['tx-power']);
		}
		
		if ($PostArray['mode'] == 'adhoc' && $PostArray['channel'] != '') {
			$props['802-11-wireless']['channel'] = array('u', (int)$PostArray['channel']);
		}

		if($PostArray['network_auth'] == 'wpa-psk'|| $PostArray['network_auth'] == 'wpa-eap') 
		{
			$props['802-11-wireless']['security'] = array('s', '802-11-wireless-security');
		}

		if(($PostArray['network_auth'] == 'open' || $PostArray['network_auth'] == 'shared')
			&& ($PostArray['encryption'] == 'none')) 
		{
		}
		if(($PostArray['network_auth'] == 'open' || $PostArray['network_auth'] == 'shared')
			&& ($PostArray['encryption'] != 'none')) 
		{
			$props['802-11-wireless']['security'] = array('s', '802-11-wireless-security');
			$props['802-11-wireless-security']['key-mgmt'] = array('s', 'none');
			$props['802-11-wireless-security']['auth-alg'] = array('s', $PostArray['network_auth']);
			$props['802-11-wireless-security']['wep-key0'] = array('s', $PostArray['network_key']);
		}
		
		if($PostArray['network_auth'] == 'wpa-psk' || $PostArray['network_auth'] == 'wpa-none') {
			$props['802-11-wireless-security']['key-mgmt'] = array('s', $PostArray['network_auth']);
			$props['802-11-wireless-security']['psk'] = array('s', $PostArray['network_key']);
		}
		

		if ($PostArray['network_auth'] == 'wpa-eap') {
			$props['802-11-wireless-security']['key-mgmt'] = array('s', $PostArray['network_auth']);
			$props['802-1x']['eap'] = array('as', array($PostArray['eap_method']));
			
			if ($PostArray['eap_method'] == 'tls') {
				if(isset($PostArray['client_cert'])) {
					$clCert = "file://".$PostArray['client_cert'];
					$certArray = str_split($clCert);
					$clc = array();
					foreach ($certArray as $char) {
						$clc[] = ord($char);
					}
					$clc[] = 0;
					$props['802-1x']['client-cert'] = array('ay', $clc);
				} else if ($PostArray['client_cert_h'] != ''){
					$clCert = "file://".$PostArray['client_cert_h'];
					$certArray = str_split($clCert);
					$clc = array();
					foreach ($certArray as $char) {
						$clc[] = ord($char);
					}
					$clc[] = 0;
					$props['802-1x']['client-cert'] = array('ay', $clc);
				}
				if(isset($PostArray['private_key'])) {
					$pKey = "file://".$PostArray['private_key'];
					$Array = str_split($pKey);
					$pk = array();
					foreach ($Array as $char) {
						$pk[] = ord($char);
					}
					$pk[] = 0;
					$props['802-1x']['private-key'] = array('ay', $pk);
				} else if($PostArray['private_key_h'] != '') {
					$pKey = "file://".$PostArray['private_key_h'];
					$Array = str_split($pKey);
					$pk = array();
					foreach ($Array as $char) {
						$pk[] = ord($char);
					}
					$pk[] = 0;
					$props['802-1x']['private-key'] = array('ay', $pk);
				}
				if($PostArray['private_key_password'] != '') {
					$props['802-1x']['private-key-password'] = array('s', $PostArray['private_key_password']);
				}
			}
			if ($PostArray['eap_method'] =='ttls' || $PostArray['eap_method'] =='peap') {
				if($PostArray['anonymous_identity'] != '') {
					$props['802-1x']['anonymous-identity'] = array('s', $PostArray['anonymous_identity']);
				}
				if($PostArray['ph2_auth'] != '') {
					$props['802-1x']['phase2-auth'] = array('s', $PostArray['ph2_auth']);
				}
			}
			if ($PostArray['eap_method'] != 'leap' && $PostArray['eap_method'] != 'fast') {
				if(isset($PostArray['ca_cert'])) {
					$caCert = "file://".$PostArray['ca_cert'];
					$certArray = str_split($caCert);
					$cac = array();
					foreach ($certArray as $char) {
						$cac[] = ord($char);
					}
					$cac[] = 0;
					$props['802-1x']['ca-cert'] = array('ay', $cac);
				} else if($PostArray['ca_cert_h']  != '') {
					$caCert = "file://".$PostArray['ca_cert_h'];
					$certArray = str_split($caCert);
					$cac = array();
					foreach ($certArray as $char) {
						$cac[] = ord($char);
					}
					$cac[] = 0;
					$props['802-1x']['ca-cert'] = array('ay', $cac);
				}
			}
			if($PostArray['identity'] != '') {
				$props['802-1x']['identity'] = array('s', $PostArray['identity']);
			}
			if($PostArray['password'] != '') {
				$props['802-1x']['password'] = array('s', $PostArray['password']);
			}
		}
		
	} else {
		$props['802-3-ethernet']['auto-negotiate'] = array('b', true);
	}
 		
	return $props;
}

function SetConnName($name, $new='true') 
{

	if(preg_match("/(\d)\#\s[\w]*/i", $name) && $new!='true'){
		$z = preg_split("/\#\s[\w]*/i", $name);
		$n = preg_split("/(\d)\#\s/i", $name);		
		$name = $n[1].".".$z[0].".nm";
		return $name;

	} else {
		$numbers = array(0,1,2,3,4,5,6,7,8,9);
		$eNumbers = array();
		if ($handle = opendir('/etc/spacecom/protected/system-connections')) {
		    while (false !== ($file = readdir($handle))) {
			if(preg_match("/\.(\d)\.nm$/i", $file, $matches)) {
				$eNumbers[] = $matches[1];
			}
		}

		for($i=0;$i<10;$i++) {
			if(!in_array($numbers[$i], $eNumbers)) {
				$name .= ".$i.nm";
				return $name;		
			}
		}
		}
		closedir($handle);
		return 0;
	}
	
}


function set_FallbackEth($connname, $type, $autoconnect) 
{
	$uuid = new uuid();
	$method = 'manual';
	$ip = '192.168.100.41';
	$subnet = '255.255.255.0';
	$gateway = '0.0.0.0';

 
				// TAMAR 'uuid' => array('s', $uuid->v4()),
	$props = array(
			'connection' => array(
				'id' => array('s', SetConnName(Filename2Formname($connname, 'DefaultEth'), 'false')),
				'uuid' => array('s', $uuid->v4()),
				'type' => array('s', $type),
				'autoconnect' => array('b', $autoconnect)
			)
		);
	
	$props['ipv4']['method'] = array('s', $method);
		
	$props['ipv4']['addresses'] = array('aau', ip4String2DbusIp(
								$ip,
								$subnet,
								$gateway));
	$props['802-3-ethernet']['auto-negotiate'] = array('b', true);

	return $props;
}

function Filename2Formname($connname, $fbname) {
	preg_match("/^($fbname)\.(\d)\.nm$/i", $connname, $array);
	$formname = "{$array[2]}# {$array[1]}";
	return $formname;
}
?>
