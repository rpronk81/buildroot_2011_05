<?php 
session_start();
if($_SESSION['DbusAuth'] != "yes") {
	 echo "You have no permission to view this page, please login!";
	 echo "<meta HTTP-EQUIV='REFRESH' content='1; url=../index.html'>";
	 exit(1);
}
?>
<?php
/*
 * This file provides several classes. One for the communication with the DBus and several for 
 * the representation of Connections in PHP
 */
require "dbus-tools.inc.php";

/* 
 * This class provides several methods for the communication with the Dbus Interface of the NetworkManager.
 */
class Dbus_Connection
{	
	/** 
	 * gets all system connections with settings from dbus
	 * @return array
	 */ 
	function get_connections()
	{
		$pathList = $this->list_connections();
		$conns = array();
		for ($i = 0; $i < sizeof($pathList); $i++) {
			$conns[$i] = 
				 Connection::factory($pathList[$i],
					$this->get_connections_settings($pathList[$i]));
		}
		return $conns;
	}
        /** 
         * gets  all system connections from dbus
         * @return array
         */
	function list_connections()
	{

		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			     '|/org/freedesktop/NetworkManagerSettings',
		'method'  => 'org.freedesktop.NetworkManagerSettings.ListConnections',
		'id'      => 0,
		'params'  => array()
		);

		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		return $result2->result;		
	}

        /** 
         * deletes a system connection
         * @param string $path  to system connection in networkmananger
         */
	function delete_connection($path)
	{
		$connsettings = $this->get_connections_settings($path);
		if(!((preg_match('/^DefaultEth\.\d\.nm$/i', $connsettings->connection->id))||(preg_match('/^DefaultWLAN\.\d\.nm$/i', $connsettings->connection->id)))) {
			if(($this->get_AmountEthConns() == 2) && ($connsettings->connection->type == '802-3-ethernet')) {
				$fbpath = $this->get_Path('DefaultEth');
				$type = $this->getConnectionType($path);
				$fbsettings = $this->get_connections_settings($fbpath);
				$construct = set_FallbackEth($fbsettings->connection->id, $type, true);
				$this->update_connection($fbpath, $construct);
			}
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				     '|'.$path.'',
			'method'  => 'org.freedesktop.NetworkManagerSettings.Connection.Delete',
			'id'      => 0,
			'params'  => array()
			);
	
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);	
			return 1;
		} else {
			PrintError("Error! It is not allowed to delete this connection!");
			return 0;
		}
	}
	
        /** 
         * adds a system connection
         * @param array $props with connectionsettings
         */
	function add_connection($props)
	{		
		if(($this->get_AmountEthConns() == 1) && ($props['connection']['type'][1] == '802-3-ethernet')) {
				$fbpath = $this->get_Path('DefaultEth');
				$type = $this->getConnectionType($fbpath);
				$fbsettings = $this->get_connections_settings($fbpath);
				$construct = set_FallbackEth($fbsettings->connection->id, $type, false);
				$this->update_connection($fbpath, $construct);
			}
		
		
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			     '|/org/freedesktop/NetworkManagerSettings',
		'method'  => 'org.freedesktop.NetworkManagerSettings.AddConnection',
		'id'      => 0,
		'params'  => array("a{sa{sv}}", $props)
		);

		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
 		$result2 = json_decode($result);

	}

        /** 
         * updates a system connection
	 * @param string $path to to system connection in networkmanager
         * @param array $props with connectionsettings
         */
	function update_connection($path, $props)
	{
		$connsettings = $this->get_connections_settings($path);
		
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			    '|'.$path.'',
		'method'  => 'org.freedesktop.NetworkManagerSettings.Connection.Update',
		'id'      => 0,
		'params'  => array("a{sa{sv}}", $props)
		);

		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		
	}
	
        /** 
         * gets a connectionsettings from specified path
         * @param string $path to to system connection in networkmanager
         * @return array with connection settings
         */
	function get_connections_settings($path)
	{

		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings|'.$path.'',
		'method'  => 'org.freedesktop.NetworkManagerSettings.Connection.GetSettings',
		'id'      => 0,
		'params'  => array()
		);

		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		return $result2->result;	
		
	}

        /** 
         * gets specified secret setting from specified path
         * @param string $path to system connection in networkmanager
	 * @param string $settingname propertyname in networkmanager
         * @return array
         */
	function get_connection_secrets($path, $settingName)
	{
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			     '|'.$path.'',
		'method'  => 'org.freedesktop.NetworkManagerSettings.Connection.Secrets.GetSecrets',
		'id'      => 0,
		'params'  => array("sasb", $settingName, array(""), true)
		);

		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		return $result2->result;	
	}
        /** 
         * gets reachable accesspoints
         * @return array with reachable accesspoints
         */

	function get_reachable_wlan()
	{
		$aps = array();
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			     '|/org/freedesktop/NetworkManager',
		'method'  => 'org.freedesktop.NetworkManager.GetDevices',
		'id'      => 0,
		'params'  => array()
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		$devices =  $result2->result;

		foreach ($devices as $dev) {
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$dev.'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $dev, "DeviceType")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
			if ($result2->result == 2) {
				$data = array(
				'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
					    '|'.$dev.'',
				'method'  => 'org.freedesktop.NetworkManager.Device.Wireless.GetAccessPoints',
				'id'      => 0,
				'params'  => array()
				);
				$json_data = json_encode($data);
				$erg = curl_post("http://localhost/rpc", $json_data);
				$erg2 = json_decode($erg);
				$helpArr = $erg2->result;
				foreach ($helpArr as $ap) {
					$aps[] = $ap;
				}
			}
		}

		$accessPs= array();
		if (sizeof($aps) > 0) {
			$i = 0;
			foreach ($aps as $ap) {
				$data = array(
				'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
					    '|'.$ap.'',
				'method'  => 'org.freedesktop.DBus.Properties.Get',
				'id'      => 0,
				'params'  => array("ss", $ap, "ssid")
				);
				$json_data = json_encode($data);
				$result = curl_post("http://localhost/rpc", $json_data);
				$result2 = json_decode($result);
				$ssid = $result2->result;
				$help = array();
				foreach ($ssid as $z) {
					$help[] = chr($z);
				}
				$rSsid = implode('',$help);
				$inArray = false;
				foreach ($accessPs as $acp) {
					if ($acp['ssid'] == $rSsid)
						$inArray = true;
				}
				if (!$inArray) {
					$accessPs[$i]['ssid'] = implode('', $help);
					$data = array(
					'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
						    '|'.$ap.'',
					'method'  => 'org.freedesktop.DBus.Properties.Get',
					'id'      => 0,
					'params'  => array("ss", $ap, "Strength")
					);
					$json_data = json_encode($data);
					$erg = curl_post("http://localhost/rpc", $json_data);
					$erg2 = json_decode($erg);
					$strength = $erg2->result;
					$accessPs[$i]['strength'] = $strength;
				}
				$i++;
			}
			
		}
		return $accessPs;
	}
        /** 
         * gets all wlan devices
         * @return array with wlandevices
         */
	function get_wlan_devices()
	{
		$aps = array();
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			     '|/org/freedesktop/NetworkManager',
		'method'  => 'org.freedesktop.NetworkManager.GetDevices',
		'id'      => 0,
		'params'  => array()
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		$devices =  $result2->result;
		$wlandev = array();

		foreach ($devices as $dev) {
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$dev.'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $dev, "DeviceType")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
			
			if ($result2->result == 2) {
				$wlandev[] = $dev;
			}
		}
		return $wlandev;
	}

        /** 
         * gets all eth devices
         * @return array with ethdevices
         */
	function get_eth_devices()
	{
		$aps = array();
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			     '|/org/freedesktop/NetworkManager',
		'method'  => 'org.freedesktop.NetworkManager.GetDevices',
		'id'      => 0,
		'params'  => array()
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		$devices =  $result2->result;
		$ethdev = array();

		foreach ($devices as $dev) {		
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$dev.'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $dev, "DeviceType")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);			
			if ($result2->result == 1) {
				$ethdev[] = $dev;
			}
		}
		return $ethdev;
	}
        /** 
         * activates a specified connection
	 * @param $path to connection in networkmanager
	 * @param $type typo of connection
         * @return bool
         */
	function activate_conn($path, $type)
	{
		$devices = array();
		if ($type == '802-3-ethernet') {
			$devices = $this->get_eth_devices();
		} else {
			$devices = $this->get_wlan_devices();
		}
		
		if (sizeof($devices) > 0) {
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|/org/freedesktop/NetworkManager',
			'method'  => 'org.freedesktop.NetworkManager.ActivateConnection',
			'id'      => 0,
			'params'  => array("sooo", "org.freedesktop.NetworkManagerSystemSettings",
					  $path, $devices[0], "/")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);

			return true;
		} else {
			return false;
		}
	}
    
        /** 
         * gets active connections
         * @return array pathes to active connections
         */
	function get_active_conns($onlyReal = false)
	{
		$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|/org/freedesktop/NetworkManager',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", "/org/freedesktop/NetworkManager","ActiveConnections")
			);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		$aConns =  $result2->result;
		
		$aConnPaths = array();
		foreach ($aConns as $conn) {
			$data = array(
				'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
					    '|'.$conn.'',
				'method'  => 'org.freedesktop.DBus.Properties.Get',
				'id'      => 0,
				'params'  => array("ss", $conn,"Connection")
				);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
			if ($onlyReal) {
				$aConnPaths[] = $result2->result;
			} else {
				$aConnPaths[] =  array('real'=>$result2->result, 'activ'=>$conn);
			}
		}
		return $aConnPaths;
	}
        /** 
         * deactivates connection
	 * @param $path to connection in networkmanager
         * @return array pathes to active connections
         */
	function deactivate_conn($path)
	{
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			    '|/org/freedesktop/NetworkManager',
		'method'  => 'org.freedesktop.NetworkManager.DeactivateConnection',
		'id'      => 0,
		'params'  => array("o", $path)
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
	}

        /** 
         * deactivates wlan
         */
	function deactivateWlan ()
	{
		$wlandevs = $this->get_wlan_devices();

		foreach($wlandevs as $dev) {
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$dev.'',
			'method'  => 'org.freedesktop.NetworkManager.Device.Disconnect',
			'id'      => 0,
			'params'  => array()
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
		}

	}
        /** 
         * change Wlanstate
         */
	function changeWlanState ($state)
	{	
	     /* TODO: for some reason, turning wifi on/off with dbus	 
  	      	does not work. Use nmcli instead */
	     if ($state == 0) {
	     	system("nmcli nm wifi off");
	     } else {
	 	system("nmcli nm wifi on");
	     }
	}
//	function changeWlanState ()
//	{
//		$state = $this->getWlanState();
//		$data = array(
//			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
//				    '|/org/freedesktop/NetworkManager',
//			'method'  => 'org.freedesktop.DBus.Properties.Set',
//			'id'      => 0,
//			'params'  => array("ssv", "/org/freedesktop/NetworkManager", "WirelessEnabled", array('b', !$state))
//			);
//		$json_data = json_encode($data);
//		$result = curl_post("http://localhost/rpc", $json_data);
//		$result2 = json_decode($result);
//
//	}
        /** 
         * get Wlanstate
	 * @return string
         */
	function getWlanState()
	{
		$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|/org/freedesktop/NetworkManager',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", "/org/freedesktop/NetworkManager", "WirelessEnabled")
			);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		return $result2->result;
	}

	 /** 
	 * @param $path to connection in networkmanager
     * @return returns macaddress
     */
	function getMacaddress($path)
	{
		$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$path.'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $path, "HwAddress")
			);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		return $result2->result;
	}

	function getIpInfosFromDevice($devicePath)
	{
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			    '|'.$devicePath.'',
		'method'  => 'org.freedesktop.DBus.Properties.Get',
		'id'      => 0,
		'params'  => array("ss", $devicePath, "Ip4Config")
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		if($result2->result == "/"){
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$devicePath.'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $devicePath, "Ip6Config")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
		}
 		
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			    '|'.$result2->result.'',
		'method'  => 'org.freedesktop.DBus.Properties.Get',
		'id'      => 0,
		'params'  => array("ss", $result2->result, "Addresses")
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		
		return $result2->result;
		
	}

	function getDrivernameFromDevice($devicePath)
	{
		
	$resultarray = array();
	$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
			    '|'.$devicePath.'',
		'method'  => 'org.freedesktop.DBus.Properties.Get',
		'id'      => 0,
		'params'  => array("ss", $devicePath, "Driver")
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		$resultarray = $result2->result;
		
		return $resultarray;
	}
	function getIpInfosFromActive()
	{
		$erg = array();
		$actives = $this->get_active_conns();

		foreach($actives as $active){
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$active['activ'].'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $active['activ'], "Connection")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
			$Type = $this->getConnectionType($result2->result);
		
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$active['activ'].'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $active['activ'], "State")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
			$State = $result2->result;
			$data = array(
			'service' => 'org.freedesktop.NetworkManagerSystemSettings'.
				    '|'.$active['activ'].'',
			'method'  => 'org.freedesktop.DBus.Properties.Get',
			'id'      => 0,
			'params'  => array("ss", $active['activ'], "Devices")
			);
			$json_data = json_encode($data);
			$result = curl_post("http://localhost/rpc", $json_data);
			$result2 = json_decode($result);
			$result2 = $result2->result[0];
			$devinfos = $this->getDrivernameFromDevice($result2);
			$infos = $this->getIpInfosFromDevice($result2);
			$infos = $infos[0];
			$setts = $this->get_connections_settings($active['real']);
			$name = $setts->connection->id;
			
			$erg[] = array('name'=>$name, 'ip'=>long2ip(htonl($infos[0])), 'subnet'=>CIDRtoMask($infos[1]),
					'gateway'=>long2ip(htonl($infos[2])), 'driver'=>$devinfos, 'state'=>$State, 'type'=>$Type);
		}
		return $erg;
	}
	
	function getConnectionType($path) 
	{
		$data = array(
		'service' => 'org.freedesktop.NetworkManagerSystemSettings|'.$path.'',
		'method'  => 'org.freedesktop.NetworkManagerSettings.Connection.GetSettings',
		'id'      => 0,
		'params'  => array()
		);
		$json_data = json_encode($data);
		$result = curl_post("http://localhost/rpc", $json_data);
		$result2 = json_decode($result);
		return $result2->result->connection->type;
	}
	
	function get_AmountEthConns() 
	{
		$ethcount = 0;
		$array = $this->get_connections();
		foreach($array as $ar) {
			if($ar->type == '802-3-ethernet'){
					$ethcount++;
			}
		}
		return $ethcount;
	}
	
	function get_AmountWlanConns() 
	{
		$wlancount = 0;
		$array = $this->get_connections();
		foreach($array as $ar) {
			if ($ar->type != '802-3-ethernet') {
					$wlancount++;
			}
		}
		return $wlancount;
	}
	
	function get_Path($connname)
	{
		$path = '';
		$reg = "/.*$connname$/i";
		$conns = $this->get_connections();
		foreach($conns as $conn) {
			if(preg_match($reg, $conn->id)) {
				$path = $conn->ConnPath;
			}
		}
		return $path;
	}

}

/*
* The Connection class is a super class for the Wired_connection and Wireless_connection classes.
* It provides properties on which are for both Connection types necessary. It retrieves its data
* by parsing the data from the settings construct given by the Dbus. It also has a static factory
* method which creates the Connection Objects, by calling the constructor of the suitable class. 
*/
class Connection 
{
	public $ConnPath;
	public $uuid;
	public $id;
	public $type;
	public $autoconnect;
	//ipv4
	public $ipv4Method;
	public $ipv4Dns= array();
	public $ipv4DnsIgnoreAuto;
	public $ipv4Addresses = array();
	//ipv6
	public $ipv6Method;
	public $ipv6Dns = array();
	public $ipv6DnsIgnoreAuto;
	public $ipv6Addresses = array();

	function __construct($connection_path, $settings)
	{
		$this->ConnPath = $connection_path;

		if(isset($settings->connection->uuid))
		$this->uuid = $settings->connection->uuid;
		else $this->uuid = '';
		
		if(isset($settings->connection->id))
		$this->id = $settings->connection->id;
		else $this->id = '';

		if(preg_match("/[\w]*\.(\d)\.nm$/i", $this->id)){
			$h = preg_split("/\.(\d)\.nm$/i", $this->id);
			preg_match("/(\d)\.nm$/i", $this->id, $h2);

			$this->id = $h2[1]."# ".$h[0];
		}
		
		if(isset($settings->connection->type))
		$this->type = $settings->connection->type;
		else $this->type = '';
		
		if(isset($settings->connection->autoconnect))
		$this->autoconnect = $settings->connection->autoconnect;
		else $this->autoconnect = true;

		if (isset($settings->ipv4)) {		
			if(isset($settings->ipv4->method))
			$this->ipv4Method = $settings->ipv4->method;
			else $this->ipv4Method = 'Auto';
				
			if(isset($settings->ipv4->dns))
			$this->ipv4Dns = $settings->ipv4->dns;
			else $this->ipv4Dns = array();

			$array = (array) $settings->ipv4;
				
			if(isset($array['ignore-auto-dns']))
			$this->ipv4DnsIgnoreAuto =  $array['ignore-auto-dns'];
			else $this->ipv4DnsIgnoreAuto = false;
				
			if(isset($settings->ipv4->addresses))
			$this->ipv4Addresses = $settings->ipv4->addresses;
			else $this->ipv4Addresses = array();
				
		}
		
		if (isset($settings->ipv6)) {
			if(isset($settings->ipv6->method))
			$this->ipv6Method = $settings->ipv6->method;
			else $this->ipv6Method = 'ignore';
				
			if(isset($settings->ipv6->dns))
			$this->ipv6Dns = $settings->ipv6->dns;
			else $this->ipv6Dns = array();
		      
			$array = (array) $settings->ipv6;
				
			if(isset($array['ignore-auto-dns']))
			$this->ipv6DnsIgnoreAuto =  $array['ignore-auto-dns'];
			else $this->ipv6DnsIgnoreAuto = false;
				
			if(isset($settings->ipv6->addresses))
			$this->ipv6Addresses = $settings->ipv6->addresses;
			else $this->ipv6Addresses = array();
		}
	}
	
	static function factory($path, $settings)
	{
		switch($settings->connection->type) {
		case '802-3-ethernet':
		    return new Wired_Connection($path, $settings);
		case '802-11-wireless':
		    return new Wireless_Connection($path, $settings);
		case '802-11-wireless-security':
		    return new Wireless_Connection($path, $settings);
		default:
		    throw new Exception('Unsupported connection type');
		}
	}
}

/*
* The Wired_Connection class is a sub class of the Connection class. It doesn't have any
* further properties, since we didn't need any in this project. So it only calls the parent
* constructor in its own constructor. It also has an method called get_construct, which 
* creates a construct from the properties of the Connection Object, which can be sent to
* to the DBus for i.e. Updating the Connection. (In fact we decided to go another way for
* updating the Connections. See the dbus-tools.inc.php)
*/ 
class Wired_Connection extends Connection
{
	
	
	function __construct($path, $settings) 
	{
		parent::__construct($path, $settings);	
	}
	
	function get_construct()
	{
		$props = array(
			'connection' => array(
				'id' => array('s', $this->id),
				'uuid' => array('s', $this->uuid),
				'type' => array('s', $this->type),
				'autoconnect' => array('b', $this->autoconnect)
			)
		);
		$props['ipv4']['method'] = array('s', $this->ipv4Method);

		if(sizeof($this->ipv4Addresses) > 0) {
			$props['ipv4']['addresses'] = array('aau', $this->ipv4Addresses);
		}
		if(sizeof($this->ipv4Dns) > 0) {
			$props['ipv4']['dns'] = array('au', $this->ipv4Dns);
		}
		if($this->ipv4DnsIgnoreAuto) {
			$props['ipv4']['ignore-auto-dns'] = array('b', $this->ipv4DnsIgnoreAutoDns);
		}
		
		
		if ($this->ipv6Method != 'ignore') {
			$props['ipv6']['method'] = array('s', $this->ipv6Method);

			if(sizeof($this->ipv6Addresses) > 0) {
				$props['ipv6']['addresses'] = array('a(ayuay)', $this->ipv6Addresses);
			}
			if(sizeof($this->ipv6Dns) > 0) {
				$props['ipv6']['dns'] = array('a(ay)', $this->ipv6Dns);
			}
			if($this->ipv6DnsIgnoreAuto) {
				$props['ipv6']['ignore-auto-dns'] = array('b', $this->ipv6DnsIgnoreAuto);
			}
		}
		return $props;
	}
}

/*
* The Wireless_Connection class is a sub class of the Connection class. It has further
* properties which are given by the requirements from the project. All Properties are 
* native datas, except the security property which is an Wireless_Security Object.
* So the constructor parses the data construct from the dbus and gets the necessary
* property values. If the wireless Object has security properties, the constructor,
* creates a new Wireless_security Object. So every wireless connection has its own 
* wireless security object assosciated. This class has also the get_construct method,
* which makes a dbus readable data construct out of the properties. Like above this 
* method has no use in this project, yet.
*/
class Wireless_Connection extends Connection
{
	public $ssid;
	public $mode;
	public $band;
	public $channel;
	public $tx_power;
	public $security;
	
	function __construct($path, $settings)
	{
		parent::__construct($path, $settings);	
		
		$array = (array)$settings;
		
		if(isset($array['802-11-wireless']->ssid))
		$this->ssid = $array['802-11-wireless']->ssid;
		else $this->ssid = array();

		if(isset($array['802-11-wireless']->mode))
		$this->mode = $array['802-11-wireless']->mode;
		else $this->mode = 'infrastructure';
		
		if(isset($array['802-11-wireless']->band))
		$this->band = $array['802-11-wireless']->band;
		else $this->band = '';
		
		if(isset($array['802-11-wireless']->channel))
		$this->channel = $array['802-11-wireless']->channel;
		else $this->channel = '';
		
		$arrayN = (array) $array['802-11-wireless'];
		
		if(isset($arrayN['tx-power']))
		$this->tx_power = $arrayN['tx-power'];
		else $this->tx_power = '';
		
		if(isset($arrayN['security']) || isset($array['802-11-wireless-security']))
		$this->security = new Wireless_Security($this->ConnPath, $settings);
		else $this->security = '';
	}

	function get_construct ()
	{
		$props = array(
			'connection' => array(
				'id' => array('s', $this->id),
				'uuid' => array('s', $this->uuid),
				'type' => array('s', $this->type),
				'autoconnect' => array('b', $this->autoconnect)
			)
		);

		$props['ipv4']['method'] = array('s', $this->ipv4Method);

		if(sizeof($this->ipv4Addresses) > 0) {
			$props['ipv4']['addresses'] = array('aau', $this->ipv4Addresses);
		}
		if(sizeof($this->ipv4Dns) > 0) {
			$props['ipv4']['dns'] = array('au', $this->ipv4Dns);
		}
		if($this->ipv4DnsIgnoreAuto) {
			$props['ipv4']['ignore-auto-dns'] = array('b', $this->ipv4DnsIgnoreAutoDns);
		}
		
		
		if ($this->ipv6Method != 'ignore') {
			$props['ipv6']['method'] = array('s', $this->ipv6Method);

			if(sizeof($this->ipv6Addresses) > 0) {
				$props['ipv6']['addresses'] = array('a(ayuay)', $this->ipv6Addresses);
			}
			if(sizeof($this->ipv6Dns) > 0) {
				$props['ipv6']['dns'] = array('a(ay)', $this->ipv6Dns);
			}
			if($this->ipv6DnsIgnoreAuto) {
				$props['ipv6']['ignore-auto-dns'] = array('b', $this->ipv6DnsIgnoreAuto);
			}
		}

		if(sizeof($this->ssid) > 0) {
			$props['802-11-wireless']['ssid'] = array('ay', $this->ssid);
		}
		$props['802-11-wireless']['mode'] = array('s', $this->mode);
		if($this->band != '') {
			$props['802-11-wireless']['band'] = array('s', $this->band);
		}
		if($this->channel != '') {
			$props['802-11-wireless']['channel'] = array('u', $this->channel);
		}
		if($this->tx_power != '') {
			$props['802-11-wireless']['tx-power'] = array('u', $this->tx_power);
		}
			


		if ($this->security != '') {
			$props['802-11-wireless']['security'] = array('s', '802-11-wireless-security');
			$props['802-11-wireless-security']['key-mgmt'] = array('s', $this->security->keyMgmt);
			
			if($this->security->authAlg != '') {
				$props['802-11-wireless-security']['auth-alg'] = array('s', $this->security->authAlg);
			}
			if($this->security->wepKey0 != '') {
				$props['802-11-wireless-security']['wep-key0'] = array('s', $this->security->wepKey0);
			}
			if($this->security->psk != '') {
				$props['802-11-wireless-security']['psk'] = array('s', $this->security->psk);
			}
		}

		if ($this->security->x8021x != '') {
			if(sizeof($this->security->x8021x->eap) > 0) {
				$props['802-1x']['eap'] = array('as', $this->security->x8021x->eap);
			}
			if(sizeof($this->security->x8021x->caCert) > 0) {
				$props['802-1x']['ca-cert'] = array('ay', $this->security->x8021x->caCert);
			}
			if($this->security->x8021x->identity != '') {
				$props['802-1x']['identity'] = array('s', $this->security->x8021x->identity);
			}
			if($this->security->x8021x->password != '') {
				$props['802-1x']['password'] = array('s', $this->security->x8021x->password);
			}
			if($this->security->x8021x->anonymous_ident != '') {
				$props['802-1x']['anonymous-identity'] = array('s', $this->security->x8021x->anonymous_ident);
			}
			if(sizeof($this->security->x8021x->client_cert) > 0) {
				$props['802-1x']['client-cert'] = array('ay', $this->security->x8021x->caCert);
			}
			if($this->security->x8021x->phase2Auth != '') {
				$props['802-1x']['phase2-auth'] = array('s', $this->security->x8021x->phase2Auth);
			}
			if(sizeof($this->security->x8021x->private_key) > 0) {
				$props['802-1x']['private-key'] = array('ay', $this->security->x8021x->private_key);
			}
			if($this->security->x8021x->private_key_pwd != '') {
				$props['802-1x']['private-key-password'] = array('s', $this->security->x8021x->private_key_pwd);
			}
		}
		return $props;

	}
}

/*
* The Wireless_Security Object represents the Wireless Security properties of
* a wireless Object, all properties are native data, expect x8021x property which
* is a x802_1x Object, representing the properties for WPA-EAP secured WLANs.
* The constructor also parses the settings construct from the dbus to get the 
* necessary data. If the security method 'wpa-eap' is given, it creates a new 
* x802_1x Object.
* So every x802_1x is assosciated by a Wireless_security Object, which is also
* assosciated by one Wireless_Connection Object.
*/
class Wireless_Security
{
	public $keyMgmt;
	public $authAlg;	
	public $wepKey0;
	public $psk;
	public $x8021x;
	
	function __construct($path, $settings)
	{
  
		$settings = (array) $settings;
		$setts = $settings['802-11-wireless-security'];
		$setts = (array) $setts;

		if (isset($setts['key-mgmt'])) {
			$this->keyMgmt = $setts['key-mgmt'];
		} else {
			$this->keyMgmt = 'none';
		};
		if (isset($setts['auth-alg'])) {
			$this->authAlg = $setts['auth-alg'];
		} else {
			$this->authAlg = '';
		};
		
		$dbus = new Dbus_connection();
		$secrets = $dbus->get_connection_secrets($path, "802-11-wireless-security");
		$secrets = (array) $secrets;
		$secs = $secrets['802-11-wireless-security'];
		$secs = (array) $secs;

		if (isset($secs['wep-key0'])) {
			$this->wepKey0 = $secs['wep-key0'];
		} else {
			$this->wepKey0 = '';
		}
		if (isset($secs['psk'])) {
			$this->psk = $secs['psk'];
		} else {
			$this->psk = '';
		}
		if($setts['key-mgmt'] == 'wpa-eap') {
			$this->x8021x = new x802_1x($path, $settings);
		} else {
			$this->x8021x = '';
		}		
	}
}

/*
* This class represents the properties for WPA-EAP secured WLANs,
* all properties are native data. The constructor parses the
* Dbus data string for the necessary property datas.
* 
*/
class x802_1x
{
	public $eap;
	public $identity;
	public $caCert;
	public $password;
	public $anonymous_ident;
	public $client_cert;
	public $private_key;
	public $private_key_pwd;
	public $phase2Auth;
	
	function __construct($path, $settings)
	{
		$settings = (array) $settings;
		$setts = $settings['802-1x'];
		$setts = (array) $setts;

		if (isset($setts['eap'])) {
			$this->eap = $setts['eap'];
		} else {
			$this->eap = array();
		};
		if (isset($setts['identity'])) {
			$this->identity = $setts['identity'];
		} else {
			$this->identity = '';
		};
		if (isset($setts['ca-cert'])) {
			$this->caCert = $setts['ca-cert'];
		} else {
			$this->caCert = array();
		};
		if (isset($setts['anonymous-identity'])) {
			$this->anonymous_ident = $setts['anonymous-identity'];
		} else {
			$this->anonymous_ident = '';
		};
		if (isset($setts['client-cert'])) {
			$this->client_cert = $setts['client-cert'];
		} else {
			$this->client_cert = array();
		};
		if (isset($setts['phase2-auth'])) {
			$this->phase2Auth = $setts['phase2-auth'];
		} else {
			$this->phase2Auth = '';
		};
				
		$dbus = new Dbus_connection();
		$secrets = $dbus->get_connection_secrets($path, "802-1x");

		$secrets = (array) $secrets;
		$secs = $secrets['802-1x'];
		$secs = (array) $secs;

		if (isset($secs['password'])) {
			$this->password = $secs['password'];
		} else {
			$this->password = '';
		}
		
		if (isset($secs['private-key'])) {
			$this->private_key = $secs['private-key'];
		} else {
			$this->private_key = array();
		};

		if (isset($secs['private-key-password'])) {
			$this->private_key_pwd = $secs['private-key-password'];
		} else {
			$this->private_key_pwd = '';
		}
	}
}
