<?php
session_start();
if ($_SESSION['DbusAuth'] != "yes") {
	echo "You have no permission to view this page, please login!";
	echo "<meta HTTP-EQUIV='REFRESH' content='1; url=/index.html'>";
	exit(1);
}

/**
  * Class for valdating the form entrys
  */
class validator
{
	var $error = array();
	var $field = array();
	//parameter networkkey
	var $reg_hex = '/^[A-Fa-f0-9]+$/';
	var $reg_ascii = '/^[\x20-\x7E]*$/';
	//parameter ipv4 addresses
	var $reg_ipv4_address = '/^(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]\d|\d)(?:[.](?:25[0-5]|2[0-4]\d|1\d\d|[1-9]\d|\d)){3}$/';
	//parameter ipv6 addresses
	var $reg_ipv6_address = '/^(((?=(?>.*?::)(?!.*::)))(::)?(([0-9A-F]{1,4})::?){0,5}|((?5):){6})(\2((?5)(::?|$)){0,2}|((25[0-5]|(2[0-4]|1[0-9]|[1-9])?[0-9])(\.|$)){4}|(?5):(?5))(?<![^:]:|\.)\z/i';
	
	public function check_networkkey_wep64( $string, $field, $keyFormat='' )
	{
		if($keyFormat == 5){
			if (strlen($string) == 5) {
				if (preg_match( $this->reg_ascii, $string ))
					return true;
			}
			$this->error[$field] =  "<span style='color: red'>Network key is invalid!<p>Enter 5 ASCII characters.</span><br />";
			return false;
		} else if ($keyFormat == 10){
			if (strlen($string) == 10) {
				if (preg_match($this->reg_hex, $string))
					return true;
			}
			$this->error[$field] =  "<span style='color: red'>Network key is invalid!<p>Enter 10 hex digits.</span><br />";
			return false;
		} else {
			if (strlen($string) == 5) {
				if (preg_match( $this->reg_ascii, $string ))
					return true;
			}
			if (strlen($string) == 10) {
				if (preg_match($this->reg_hex, $string))
					return true;
			}
			$this->error[$field] =  "<span style='color: red'>Network key is invalid!<p>Enter 5 ASCII characters or 10 hex digits.</span><br />";
			return false;
		}
		
	}
	
	public function check_networkkey_wep128( $string, $keyFormat='' )
	{
		if($keyFormat == 13){
			if (strlen($string)== 13 ) {
				if (preg_match( $this->reg_ascii, $string ))
					return true;
			}
			$this->error['wep128'] = "<span style='color: red'>Network key is invalid!<p>Enter 13 ASCII characters.</span><br />";
			return false;
		} else if ($keyFormat == 26){
			if (strlen($string) == 26) {
				if (preg_match($this->reg_hex, $string))
					return true;
			} 
			$this->error['wep128'] = "<span style='color: red'>Network key is invalid!<p>Enter 26 hex digits.</span><br />";
			return false;
		} else {
			if (strlen($string)== 13 ) {
				if (preg_match( $this->reg_ascii, $string ))
					return true;
			}
			if (strlen($string) == 26) {
				if (preg_match($this->reg_hex, $string))
					return true;
			} 
			$this->error['wep128'] = "<span style='color: red'>Network key is invalid!<p>Enter 13 ASCII characters or 26 hex digits.</span><br />";
			return false;
		}
	}
	
	public function check_networkkey_wpa( $string, $keyFormat='' )
	{
		if($keyFormat == 63){
			if ((strlen($string) >= 8) && (strlen($string) <= 63)) {
				if (preg_match( $this->reg_ascii, $string ))
						return true;
			}
			$this->error['wpa'] =  "<span style='color: red'>Network key is invalid!<p>Enter 8-63 ASCII characters.</span><br />";
			return false;
		} else if ($keyFormat == 64){
			if (strlen($string) == 64) {
				if (preg_match($this->reg_hex, $string))
					return true;
			}
			$this->error['wpa'] =  "<span style='color: red'>Network key is invalid!<p>Enter 64 hex digits.</span><br />";
			return false;
		} else {
			if ((strlen($string) >= 8) && (strlen($string) <= 63)) {
				if (preg_match( $this->reg_ascii, $string ))
						return true;
			}
			if (strlen($string) == 64) {
				if (preg_match($this->reg_hex, $string))
					return true;
			}
			$this->error['wpa'] =  "<span style='color: red'>Network key is invalid!<p>Enter 8-63 ASCII characters, or 64 hex digits.</span><br />";
			return false;
		}
	}
	
	public function check_ipv4( $string, $field )
	{
		if (preg_match( $this->reg_ipv4_address, $string ))
			return true;
		$this->error['ipv4'] =  "<span style='color: red'>IPv4 address is invalid!</span><br />";
		return false;
	}
	
	public function check_ipv4_gateway( $string )
	{
		if ( $string == "" )
			return true;
		if (preg_match( $this->reg_ipv4_address, $string ))
			return true;
		$this->error['ipv4_gate'] = "<span style='color: red'>IPv4 gateway is invalid!</span><br />";
		return false;
	}

	public function check_ipv4_dns( $string )
	{
		if ( $string == "" )
			return true;
		if (preg_match( $this->reg_ipv4_address, $string ))
			return true;
		$this->error['ipv4_dns'] = "<span style='color: red'>IPv4 DNS is invalid!</span><br />";
		return false;
	}
	
	public function check_ipv6( $string )
	{
		if (preg_match( $this->reg_ipv6_address, $string ))
			return true;
		$this->error['ipv6'] = "<span style='color: red'>IPv6 address is invalid!</span><br />";
		return false;
	}
	
	public function check_ipv6_gateway( $string )
	{
		if ( $string == "" )
			return true;
		if (preg_match( $this->reg_ipv6_address, $string ))
			return true;
		$this->error['ipv6_gate'] = "<span style='color: red'>IPv6 gateway is invalid!</span><br />";
		return false;
	}

	public function check_ipv6_dns( $string )
	{
		if ( $string == "" )
			return true;
		if (preg_match( $this->reg_ipv6_address, $string ))
			return true;
		$this->error['ipv6_dns'] = "<span style='color: red'>IPv6 DNS is invalid!</span><br />";
		return false;
	}
	
	public function check_ipv6_subnetmask( $int )
	{
		if (($int >= 0) && ($int <= 128))
			return true;
		$this->error['ipv6_sub'] = "<span style='color: red'>IPv6 subnet mask is invalid!</span><br />";
		return false;
	}
	
	public function check_channel_id( $int )
	{
		// FIXME: not sure 255 is valid channel id 
		if (($int >= 0) && ($int <= 255))
			return true;
		$this->error['channel'] = "<span style='color: red'>Channel is invalid!</span><br />";
		return false;
	}
	
	public function check_identity( $string )
	{
		if ((strlen($string) >= 1) && (strlen($string) <= 100)) {
			if (preg_match( $this->reg_ascii, $string ))
				return true;
		}
		$this->error['user_name'] = "<span style='color: red'>User Name is invalid!</span><br />";
		return false;
	}
	
	public function check_password( $string )
	{
		if ((strlen($string) >= 1) && (strlen($string) <=32 )) {
			if (preg_match( $this->reg_ascii, $string ))
					return true;
		}
		$this->error['password'] = "<span style='color: red'>Password is invalid!</span><br />";
		return false;
	}
	
	public function check_ssid( $string )
	{
		if ((strlen($string) >= 0) && (strlen($string) <= 32)) {
			if (preg_match( $this->reg_ascii, $string ))
					return true;
		}
		$this->error['ssid'] = "<span style='color: red'>SSID is invalid!</span><br />";
		return false;
	}

	public function check_name( $string )
	{
		if ((strlen($string) >= 0)&&(strlen($string) <= 25)) {
			if (preg_match("/^[A-Za-z0-9-_]+$/",$string)) {
				return true;
			} else {
				$this->error['name1'] =   "<span style='color: red'>Only a-z, A-z, 0-9, - and _ in Connection Name allowed</span><br />";
				return false;
			}
		}

		$this->error['name2'] = "<span style='color: red'>Please enter a Connection Name with a maximum of 25 characters</span><br />";
		return false;
	}
}
