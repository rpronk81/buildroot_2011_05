<?php
include "validate.php";
include "../common.inc.php";
VerifyConfigAuth();
HeadJquery("Wired networks");
?>
<script type="text/javascript">
$(document).ready(function() {
	  switchdns_ipv4();
	  switchdns_ipv6();
	  switchMethod_ipv4();
	  switchMethod_ipv6();
	  switchIp();
	});
</script>
</head>
<body>
<?php
/**
 * Creates the wired form with settings
 */
include "template.php";
include "dbus_classes.php";

$dbus = new Dbus_Connection();
$nav = new NaviBanner();
$nav->render();


if (isset($_POST['chooseC']) || ($_GET['choose']==1)) {
	if(isset($_POST['chConn']) || isset($_GET['conn']))
	{	
		$array = $dbus->get_connections();
		if(isset($_GET['conn'])) {
			$conn = get_spec_conn($_GET['conn'], $array);
		} else {
			$conn = get_spec_conn($_POST['chConn'], $array);
		}
		if($_SESSION['lastformvars']['check']=='false') {
			$form = new NetworkForm("ethForm", "wired.php");
			if(preg_match('/^\d# DefaultEth$/i', $conn->id)) {
				$form->addEthConnSettsFrame($conn->id, $ipVers, $conn->autoconnect, 'false', true);
			} else {
				$form->addEthConnSettsFrame($conn->id, $ipVers, $conn->autoconnect, 'false');
			}
			
			if ($_SESSION['lastformvars']['ipv']=='IPv4') {
				SaveIpv4Session($form);
			} else {
				SaveIpv6Session($form);
			} 
			$form->addHidden("path", $conn->ConnPath);
			$form->addBr();
			if(preg_match('/^\d# DefaultEth$/i', $conn->id)) {
				$form->addButton("BackButton", "Back");
			} else {
				$form->addButton("save", "Save changes");
			}
			$form->addBr();
			$form->render();
			PrintErrorList($_SESSION['errors']->error);
			
		} else {
		
			if ($conn->ipv6Method != 'ignore' && !is_null($conn->ipv6Method)) {
				$ipVers = 6;
			} else {
				$ipVers = 4;
			}
			$form = new NetworkForm("ethForm", "wired.php");			
			
			if(preg_match('/^\d# DefaultEth$/i', $conn->id)) {
				$form->addEthConnSettsFrame($conn->id, $ipVers, $conn->autoconnect, 'false', true);
			} else {
				$form->addEthConnSettsFrame($conn->id, $ipVers, $conn->autoconnect, 'false');
			}

				$dnse = array();
				foreach($conn->ipv4Dns as $dns) {
					$dnse[] = revIp_shift($dns);
				}
				
				$compIp = dbusIp2Ip4String($conn->ipv4Addresses);
				if(preg_match('/^\d# DefaultEth$/i', $conn->id)) {
					$form->addIpSettsFrame(4, $conn->ipv4Method, $compIp['ip'],
							$compIp['subnet'], $compIp['gateway'],
							implode(",", $dnse), $conn->ipv4DnsIgnoreAuto, true);
				} else {
					$form->addIpSettsFrame(4, $conn->ipv4Method, $compIp['ip'],
							$compIp['subnet'], $compIp['gateway'],
							implode(",", $dnse), $conn->ipv4DnsIgnoreAuto);
				}
				
				
	
				$dnse_ipv6 = array();
				foreach($conn->ipv6Dns as $dns) {
					$dnse_ipv6[] = bytestoipv6($dns);
				}
				$compIp = dbusIp2Ip6String($conn->ipv6Addresses);
				if(preg_match('/^\d# DefaultEth$/i', $conn->id)) {
					$form->addIpSettsFrame(6, $conn->ipv6Method, $compIp['ip'],
							$compIp['prefix'], $compIp['gateway'], implode(",", $dnse_ipv6), $conn->ipv6DnsIgnoreAuto, true);
				} else {
					$form->addIpSettsFrame(6, $conn->ipv6Method, $compIp['ip'],
							$compIp['prefix'], $compIp['gateway'], implode(",", $dnse_ipv6), $conn->ipv6DnsIgnoreAuto);
				}
				
	
			$form->addHidden("path", $conn->ConnPath);
			$form->addBr();
			if(preg_match('/^\d# DefaultEth$/i', $conn->id)) {
				$form->addButton("BackButton", "Back");
			} else {
				$form->addButton("save", "Save changes");
			}
			$form->render();
		}
		
	} else {
		PrintError("Connection not found.");
	}
} else if (isset($_POST['deleteC'])) {
	echo "<p>Do you really want to delete this Connection?</p>";
	echo "<form action='wired.php' method='POST'>".
	     "<input type='submit' name='reallyDel' value='Yes'> ".
	     "<input type='submit' name='abortDel' value='No'>".
	     "<input type='hidden' name='chConn' value='".$_POST['chConn']."'></form>";

} else if (isset($_POST['reallyDel'])) {
	if($dbus->delete_connection($_POST['chConn'])) {
		echo "Connection deleted!";
		forward("wired.php", 1);
	} else {
		forward("wired.php", 0);
	}
	

} else if (isset($_POST['abortDel'])) {
	echo "Not deleted!";
	forward("wired.php", 1);

} else if (isset($_POST['save'])) {
	$v = new Validator();
	$check = true;
	
	SavePostinSession($_POST);

	if($_POST['ipv'] == 'IPv4' && $_POST['ipv4method'] != 'auto') {

		if(!$v->check_ipv4($_POST['ipv4ip'], "ipv4address")) {
			$check = false;
		}
			
		if(!$v->check_ipv4($_POST['ipv4subnet'], "ipv4subnetmask")) {
			$check = false;
		}
			
		if(!$v->check_ipv4_gateway($_POST['ipv4gate'], "ipv4gateway")) {
			$check = false;
		}
	} else if($_POST['ipv'] == 'IPv4' && $_POST['ipv4method'] == 'auto') {

	} else if ($_POST['ipv'] == 'IPv6' && $_POST['ipv6method'] != 'auto') {
	
		if(!$v->check_ipv6($_POST['ipv6ip'], "ipv6address")) {
			$check = false;
		}
			
		if(!$v->check_ipv6_subnetmask($_POST['ipv6subnet'], "ipv6subnetmask")) {
			$check = false;
		}
			
		if(!$v->check_ipv6_gateway($_POST['ipv6gate'], "ipv6gateway")) {
			$check = false;
		}
			
	} else if($_POST['ipv'] == 'IPv6' && $_POST['ipv6method'] == 'auto') {

	}
	if(($_POST['ipv'] == 'IPv4' && $_POST['ipv4dnsIgnoreAuto'] == 'true')||($_SESSION['lastformvars']['ipv'] == 'IPv4' && $_SESSION['lastformvars']['ipv4dnsIgnoreAuto'] == 'true')) {
		
		if(!$v->check_ipv4_dns($_POST['ipv4dns'], "ipv4dns")) {
			$check = false;
		}
			
	} else if($_POST['ipv'] == 'IPv6' && $_POST['ipv6dnsIgnoreAuto'] == 'true') {
		if(!$v->check_ipv6_dns($_POST['ipv6dns'], "ipv6dns")) {
			$check = false;
		}
			
	}
	if($check) {
		if(createConstructFromPost("802-11-wireless", $_POST)) {
			$construct = createConstructFromPost("802-3-ethernet", $_POST);
			$dbus->update_connection($_POST['path'], $construct);
			unset($_SESSION['lastformvars']);
			unset($_SESSION['errors']);
			echo "updating";
			forward("controller.php", 2);
		} else {
			echo "Error! Connectionlist is full!";
			$_SESSION['errors'] = $v;
			$_SESSION['lastformvars']['check'] = 'false';
			forward("controller.php", 2);
		}
	} else {
		$_SESSION['errors'] = $v;
		$_SESSION['lastformvars']['check'] = 'false';
		forward("wired.php?choose=1&conn=".$_POST['path']."", 0);
	}

} else {
	$array = $dbus->get_connections();
	$eths= array();
	echo "<fieldset><legend>LANs</legend>";
	$devs = $dbus->get_eth_devices();
	foreach($array as $ar) {
		if($ar->type == '802-3-ethernet'){
				$eths[] = array('show'=>$ar->id, 'value'=>$ar->ConnPath);

		}
	}
	asort($eths);
	if (sizeof($eths) > 0) {
		$list = new ConnectionList("chConn", array("chooseC", "Edit"),
					    array("deleteC", "Delete"), "wired.php");
		$list->addMore($eths);
		$list->render();

	      echo "</fieldset>";
	} else {
		echo "No connections Available";
		echo "</fieldset><br />";
	}
	if(isset($devs[0])) {
		$mac = $dbus->getMacAddress($devs[0]);
		echo "<p id='mac'>MAC-Address: ".$mac."</p>"; 
	}
}

?>
</body>
</html>
