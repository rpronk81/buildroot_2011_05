<?php 
session_start();
if($_SESSION['DbusAuth'] != "yes") {
	 echo "You have no permission to view this page, please login!";
	 echo "<meta HTTP-EQUIV='REFRESH' content='1; url=../index.html'>";
	 exit(1);
}
?>
<?php
/**
 * Creates the top navigation
 */
class NaviBanner
{
	function render()
	{
		$dbus = new Dbus_Connection();
		if(isset($_POST['wifiOff'])) {
			$dbus->changeWlanState(0);
		} else if(isset($_POST['wifiOn'])) {
			$dbus->changeWlanState(1);
		} echo 
			"<div id='up'>".
			"<a href='controller.php'><b>Start</b></a>";
		if (GetBoard() != "spacecomlite") {
			echo "<a href='wired.php'><b>LAN Connections</b></a>";
		}
		if (GetBoard() == "spacecom2") {

			exec("/sbin/wifiBridge.sh -chkEnabled", $output, $ret);
			if ($ret == "0") {
				echo	"<a href='wireless.php'><b>WLAN Connections</b></a>";
			} else {
				echo    "<a href='../../wlan/docs/status.php'><b>WiFi Bridge Settings</b></a>";
			}
			
		}
		else
		{
			echo	"<a href='wireless.php'><b>WLAN Connections</b></a>";
		}

		$wlandevs = $dbus->get_wlan_devices();
		if(isset($wlandevs[0])) {
			echo "<div id='wlanCh'><form style='display:inline' method='Post' action='"
			.substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1)."'> WLAN:";
		    	if (GetBoard() != "spacecomlite") {
			    if($dbus->getWlanState()) {
			    	echo " <i style='color:red'>ON</i> <input  type='submit' name='wifiOff' value='Turn it off'>";
			    } else {
				    echo " <i style='color:red'>OFF</i> <input type='submit' name='wifiOn' value='Turn it on'>";
			    }
            		} 
			else 
			{
			    if($dbus->getWlanState()) {
			    	echo " <i style='color:red'>ON</i>";
			    } else {
				    echo " <i style='color:red'>OFF</i>";
			    }
            		}
			echo "</form></div></div>";
		} else {
			if (GetBoard() == "spacecom2") {

				exec("/sbin/wifiBridge.sh -chkEnabled", $output, $ret);
				if ($ret == "0") {
					echo "<div id='wlanCh' style='color:red'>no WLAN-Device found";
				}
			}
			else
			{
				echo "<div id='wlanCh' style='color:red'>no WLAN-Device found";
			}
			echo "</form></div></div>";
		}
	}
}
/**
 * Provides methods to render the ethframes with settings
 */
class NetworkForm
{
	var $name;
	var $target;
	var $output;

	function __construct ($name, $target)
	{
		$this->name = $name;
		$this->target = $target;
		
		$this->output =
			"<p><form action='".$this->target."' name='".
			$this->name."' method='POST' enctype='multipart/form-data'>";
	}
/** 
 * adds a fieldset within eth connections
 * @param string $buttonName 
 * @param string $conns 
 */ 
	function addConn2EthFrame ($buttonName, $conns = "")
	{
		$this->output .= 
			"<fieldset><legend>Connect to an LAN Connection".
			"</legend><table><tr><td><select name='eth' size='6'>".
		 	"<optgroup label='--LAN-Connections--'>";
			if ($conns != "") {
				for ($i = 0; $i < sizeof($conns); $i++) {
					$this->output .= 
						"<option value='".$conns[$i]['path']."'>"
						.$conns[$i]['id'];
					if ($conns[$i]['active']) {
						$this->output .= " (active) ";
					}
					$this->output .= "</option>";
				}
			}
			$this->output .=
				"</optgroup></select></td></tr><tr><td><input type='submit' name=".
				"'".$buttonName."' value='Connect to".
				" Connection'></td></tr></table></fieldset>";
	}
	/** 
	 * adds a fieldset within reachable wlans
	 * @param string $buttonName
	 * @param string $buttonName2 
	 * @param array $connsSaved 
	 * @param array $connsNotSaved
	 */
	function addConn2ReachWlanFrame ($buttonName, $connsSaved = array(), 
					 $buttonName2, $connsNotSaved = array())
	{
		$this->output .=
			"<fieldset><legend>Connect to a reachable WLAN".
			"</legend><table style='text-align:center'><tr>";
		
		if (sizeof($connsSaved) > 0 || sizeof($connsNotSaved) >0) {;
				if (sizeof($connsSaved) > 0) {
					$this->output .= "<td><select name='wlanSav' size='6'>".
							 "<optgroup label='--WLAN-Connections--'>";
					for ($i = 0; $i < sizeof($connsSaved); $i++) {
						$this->output .=
							"<option value='".$connsSaved[$i]['path']."'>"
							.$connsSaved[$i]['id'];
						if ($connsSaved[$i]['active']) {
							$this->output .= " (active) ";
						}
						$this->output .= "</option>";
					}
					$this->output .= "</optgroup></select></td>";
				}
				
				if (sizeof($connsNotSaved) > 0) {
					$this->output .= "<td><select name='wlanNSav' size='6'>".
							 "<optgroup label='--Access Points in reach--'>";
					for ($i = 0; $i < sizeof($connsNotSaved);
					    $i++) {
						$this->output .=
							"<option>".$connsNotSaved[$i].
							"</option>";
					}
					$this->output .= "</optgroup></select></td>";
				}

				$this->output .= "</tr><tr>";	  
  
				if (sizeof($connsSaved) > 0) {
					$this->output .= 
						"<td><input type='submit'".
						" name='".$buttonName."' value='Connect".
						" to Connection'></td>";
				}

				if (sizeof($connsNotSaved) > 0) {
					$this->output .= 
						"<td><input type='submit'".
						" name='".$buttonName2."' value='Connect".
						" to AccessPoint'></td>";
				}
				
		} else {
			$this->output .= "<td>no access points in range or wifi not active</td>";
		}
		$this->output .=
			"</tr></table></fieldset>";
	}
	
	function addEthConnSettsFrame ($id, $ipv = 4, $autoconnect = true, $new='true', $isReadonly=false)
	{
	    $readonly = "";
	    if($isReadonly == true)
	        $readonly = " DISABLED";
	        
		if(isset($_SESSION['lastformvars']['ipv'])) {
			$ipv = $_SESSION['lastformvars']['ipv'];
		}
		
		
		$this->output .=
			"<fieldset><legend>Connection Settings</legend>".
			"<table><tr><td>Name:</td><td>";
		if($isReadonly == true) {
			$this->output .= "<input type='text' name='id' value='".$id."' $readonly>";
		}		
		else if($new == 'true') {
			$this->output .= "<input type='text' name='id' value='".$id."'>";
		} else {
			$this->output .= "<input type='text' name='id' value='".$id."' readonly>";
		}

			$this->output .= 
				"<tr><td>IP Version:</td><td><select name='ipv'".
				" id='ipv' onchange='switchIp(this.id)'$readonly>";
			if ($ipv == 6 || $ipv == 'IPv6') {
				$this->output .= 
					"<option>IPv4</option>".
					"<option selected>IPv6</option>";
			} else {
				$this->output .= 
					"<option selected>IPv4</option>".
					"<option>IPv6</option>";
			}
			$this->output .= "</select></td></tr></table></fieldset>";
	}
  
	function addWlanConnSettsFrame($id, $ssid='', $mode = "infrastructure", $ipv = 4, $region='', 
					$channel=1, $power =30, $autoconnect = 'true', $new='true')
	{
		if(isset($_SESSION['lastformvars']['ipv'])) {
			$ipv = $_SESSION['lastformvars']['ipv'];
		}

		$this->output .= 
			"<fieldset><legend>Connection Settings</legend>".
			"<table><tr><td>Name:</td><td>";
		if($isReadonly == true) {
			$this->output .= "<input type='text' name='id' value='".$id."' $readonly>";
		}		
		else if($new == 'true') {
			$this->output .= "<input type='text' name='id' value='".$id."'>";
		} else {
			$this->output .= "<input type='text' name='id' value='".$id."' readonly>";
		}
		$this->output .= 
			"</td></tr><tr><td>SSID:</td><td><input type='text'".
			"name='ssid' value='".$ssid."'></td></tr>".

			"<tr><td>Mode:</td><td><select name='mode' id='mode' onchange='switchMode()'>";
		if ($mode == "adhoc") {
			$this->output .=
				"<option value='infrastructure'>Infrastructure</option>".
				"<option selected value='adhoc'>Ad-hoc</option>";
		} else {
			$this->output .=
				"<option selected value='infrastructure'>Infrastructure".
				"</option><option value='adhoc'>Ad-hoc</option>";
		}
		$this->output .= 
			"</select></td></tr><tr><td>IP Version:</td><td><select name=".
			"'ipv' id='ipv' onchange='switchIp(this.id)'>";
		if ($ipv == 6 || $ipv == 'IPv6') {
			$this->output .= 
				"<option>IPv4</option>".
				"<option selected>IPv6</option>";
		} else {
			$this->output .= 
				"<option selected>IPv4</option>".
				"<option>IPv6</option>";
		}

		$this->output .= 
			"</select></td></tr><tr><td>Transmitting Power:</td><td><select name=".
			"'tx-power' id='tx-power'>";

		if (GetBoard() == "spacecomlite") {
			if ($power <= 15) {
				$this->output .= 
					"<option value=15 selected>Low</option>".
					"<option value=18>Middle</option>".
					"<option value=20>High</option>";
			} else if ($power <= 18){
				$this->output .= 
					"<option value=15>Low</option>".
					"<option value=18 selected>Middle</option>".
					"<option value=20>High</option>";
			} else {
				$this->output .= 
					"<option value=15>Low</option>".
					"<option value=18>Middle</option>".
					"<option value=20 selected>High</option>";
			}
		} else {
			if ($power <= 10) {
				$this->output .= 
					"<option value=10 selected>Low</option>".
					"<option value=20>Middle</option>".
					"<option value=30>High</option>";
			} else if ($power <= 20){
				$this->output .= 
					"<option value=10>Low</option>".
					"<option value=20 selected>Middle</option>".
					"<option value=30>High</option>";
			} else {
				$this->output .= 
					"<option value=10>Low</option>".
					"<option value=20>Middle</option>".
					"<option value=30 selected>High</option>";
			}
		}


		$this->output .= "</select></td></tr></table></fieldset>";
	}
  
	function addIpSettsFrame ($ipv=4, $method='auto', $ipAddresses='', $subnet='', 
				  $gateway='', $dns='', $dnsIgnoreAuto='false', $isReadonly=false)
	{
		$readonly = "";
	    if($isReadonly == true)
	        $readonly = " DISABLED";
	        
		if ($ipv == 4) {
			$this->output .=
			"<fieldset id='ipv4' style='display:inline'><legend>".
			"IPv4 Address Settings</legend><table><tr><td>Method:</td><td>".
			"<select name='ipv4method' id='method_ipv4' onChange='switchMethod_ipv4(this.name)'$readonly>";
			if ($method == "manual") {
				$this->output .=
					"<option value='auto'>Auto (DHCP)</option>".
					"<option selected='selected' value='manual'>Manual (Static)</option>";
			} else {
				$this->output .=
					"<option selected='selected' value='auto'>Auto (DHCP)</option>".
					"<option value='manual'>Manual (Static)</option>";
			}
			$this->output .= "</select></td></tr>".
			"<tr><td>IP Address:</td><td><input type='text' name='ipv4ip' value='".$ipAddresses."'$readonly></td></tr>".
			"<tr><td>Subnet Mask:</td><td><input type='text' name='ipv4subnet' value='".$subnet."'$readonly></td></tr>".
			"<tr><td>Gateway:</td><td><input type='text' name='ipv4gate' value='".$gateway."'$readonly></td></tr>".
			"<tr><td>DNS Server:</td><td><select name='ipv4dnsIgnoreAuto' onchange='switchdns_ipv4()'$readonly>";
			if ($dnsIgnoreAuto=='true') {
				$this->output .=
					"<option value='false'>DNS server address automatically</option>".
					"<option value='true' selected>Use following DNS server address</option>";
			} else {
				$this->output .=
					"<option value='false' selected>DNS server address automatically</option>".
					"<option value='true'>Use following DNS server address</option>";
			}
			$this->output .=
			"</select></td></tr><tr><td>DNS Server address:</td><td><input type='text' name='ipv4dns' value='".$dns."'$readonly></td></tr>".			
			"</table>".
			"</fieldset>";
		} 
		else if ($ipv == 6) {
			$this->output .=
			"<fieldset id='ipv6' style='display:inline'><legend>".
			"IPv6 Address Settings</legend><table><tr><td>Method:</td><td>".
			"<select name='ipv6method' id='method_ipv6' onChange='switchMethod_ipv6(this.name)'$readonly>";
			if ($method == "manual") {
				$this->output .=
					"<option value='auto'>Auto (DHCP)</option>".
					"<option selected='selected' value='manual'>Manual (Static)</option>";
			} else {
				$this->output .=
					"<option selected='selected' value='auto'>Auto (DHCP)</option>".
					"<option value='manual'>Manual (Static)</option>";
			}
			$this->output .= "</select></td></tr>".
			"<tr><td>IP Address:</td><td><input type='text' name='ipv6ip' value='".$ipAddresses."'$readonly></td></tr>".
			"<tr><td>Prefix:</td><td><input type='text' name='ipv6subnet' value='".$subnet."'$readonly></td></tr>".
			"<tr><td>Gateway:</td><td><input type='text' name='ipv6gate' value='".$gateway."'$readonly></td></tr>".
			"<tr><td>DNS Server:</td><td><select name='ipv6dnsIgnoreAuto' onchange='switchdns_ipv6()'$readonly>";
			if ($dnsIgnoreAuto=='true') {
				$this->output .=
					"<option value=false>DNS server address automatically</option>".
					"<option value=true selected>Use following DNS server address</option>";
			} else {
				$this->output .=
					"<option value=false selected>DNS server address automatically</option>".
					"<option value=true>Use following DNS server address</option>";
			}
			$this->output .=
			"</select></td></tr><tr><td>DNS Server address:</td><td><input type='text' name='ipv6dns' value='".$dns."'$readonly></td></tr>".
			"</table>".
			"</fieldset>";
		}
	}
	
	function addWlanSecFrame ($auth='open', $eap=array('tls'), $vsc=false, $key='', $ident='',
				  $pwd='', $cac='', $uac='', $aident='', $private_key='', $phase2_auth='tls', $ppwd='', $enc='')
	{
		$wpastring = "WPA/WPA2";
		if(GetBoard() == "spacecom1") {
			$wpastring = "WPA";
		}
		$this->output .= 
			"<fieldset><legend>WLAN Security</legend>".
			"<table><tr><td>Network Authentication:</td>".
			"<td><select id='network_auth' name='network_auth' onChange='chooseEncrypt()'>";
		switch ($auth) {
		case 'open':
			$this->output .= 
				"<option value='open' selected>Open</option>".
				"<option value='shared'>Shared</option>".
				"<option value='wpa-psk'>{$wpastring}-Personal(PSK)</option>".
				"<option value='wpa-eap'>{$wpastring}-Enterprise(EAP)</option>";
			break;
		case 'shared':
			$this->output .= 
				"<option value='open'>Open</option>".
				"<option value='shared' selected>Shared</option>".
				"<option value='wpa-psk'>{$wpastring}-Personal(PSK)</option>".
				"<option value='wpa-eap'>{$wpastring}-Enterprise(EAP)</option>";
			break;
		case 'wpa-psk':
			$this->output .= 
				"<option value='open'>Open</option>".
				"<option value='shared'>Shared</option>".
				"<option value='wpa-psk' selected>{$wpastring}-Personal(PSK)</option>".
				"<option value='wpa-eap'>{$wpastring}-Enterprise(EAP)</option>";
			break;
		case 'wpa-eap':
			$this->output .= 
				"<option value='open'>Open</option>".
				"<option value='shared'>Shared</option>".
				"<option value='wpa-psk'>{$wpastring}-Personal(PSK)</option>".
				"<option value='wpa-eap' selected>{$wpastring}-Enterprise(EAP)</option>";
			break;
		default: 
			$this->output .= 
				"<option value='open' selected>Open</option>".
				"<option value='shared'>Shared</option>".
				"<option value='wpa-psk'>{$wpastring}-Personal(PSK)</option>".
				"<option value='wpa-eap'>{$wpastring}-Enterprise(EAP)</option>";
			break;
		}
		$this->output .= 
			"</select></td></tr>".
			"<tr id='enc'><td>Encryption:</td><td><select id='encryption' name='encryption' onChange='chooseEAP();'>";
		if($enc == ''){
			if (strlen($key) == 5 || strlen($key) == 10) {
				$this->output .= "<option value='wep64' selected>WEP 64</option>".
				"<option value='wep128'>WEP 128</option>";
			} else if (strlen($key) == 13 || strlen($key) == 26) {
				$this->output .= "<option value='wep64'>WEP 64</option>".
				"<option value='wep128' selected>WEP 128</option>";
			}
			else {
				$this->output .= "<option value='wep64'>WEP 64</option>".
				"<option value='wep128'>WEP 128</option>";
			}
		} else {
			if ($enc=='wep64'){
				$this->output .= "<option value='wep64' selected>WEP 64</option>".
				"<option value='wep128'>WEP 128</option>";
			} else if ($enc == 'wep128'){
				$this->output .= "<option value='wep64'>WEP 64</option>".
				"<option value='wep128' selected>WEP 128</option>";
			} else {
				$this->output .= "<option value='wep64'>WEP 64</option>".
				"<option value='wep128'>WEP 128</option>";
			}
		}
		
		if ($auth == 'open'){
			if ($key == '') {
				$this->output .= "<option value='none' id='None' selected>None</option>";
			}else{
				$this->output .= "<option value='none' id='None'>None</option>";
			}
		} else if ($auth == 'shared') {
			$this->output .= "<option value='none' id='None' style='display:none'>None</option>";
		} else {
			if ($key == '') {
				$this->output .= "<option value='none' id='None' selected>None</option>";
			} else {
				$this->output .= "<option value='none' id='None'>None</option>";
			}
		}
		$this->output .= "</select></td></tr>".
			"<tr id='key'><td>Network key:</td><td>".
			"<select name='keyFormat' id='keyFormat' style='display:inline' onchange='keyformat();'>";
		 if ($auth == "wpa-psk") {
			if(strlen($key) < 64){
				$this->output .= "<option value='5' style='display:none'>5 alphanumeric characters</option>".
						 "<option value='10' style='display:none'>10 hexadecimal</option>".
						 "<option value='13' style='display:none;'>13 alphanumeric characters</option>".
						 "<option value='26' style='display:none;'>26 hexadecimal</option>".
						 "<option value='63' selected>8 - 63 alphanumeric characters</option>".
						 "<option value='64'>64 hexadecimal</option>";
			} else {
				$this->output .= "<option value='5' style='display:none'>5 alphanumeric characters</option>".
						 "<option value='10' style='display:none'>10 hexadecimal</option>".
						 "<option value='13' style='display:none;'>13 alphanumeric characters</option>".
						 "<option value='26'>26 hexadecimal</option>".
						 "<option value='63' style='display:none;'>8 - 63 alphanumeric characters</option>".
						 "<option value='64' selected>64 hexadecimal</option>";
			}		
		} else if (strlen($key) == 5 || strlen($key) == 10) {
			if(strlen($key) == 5){
				$this->output .= "<option value='5' selected>5 alphanumeric characters</option>".
						 "<option value='10'>10 hexadecimal</option>".
						 "<option value='13' style='display:none;'>13 alphanumeric characters</option>".
						 "<option value='26' style='display:none;'>26 hexadecimal</option>".
						 "<option value='8' style='display:none;'>8 - 63 alphanumeric characters</option>".
						 "<option value='64' style='display:none;'>64 hexadecimal</option>";
			} else {
				$this->output .= "<option value='5'>5 alphanumeric characters</option>".
						 "<option selected value='10'>10 hexadecimal</option>".
						 "<option value='13' style='display:none;'>13 alphanumeric characters</option>".
						 "<option value='26' style='display:none;'>26 hexadecimal</option>".
						 "<option value='63' style='display:none;'>8 - 63 alphanumeric characters</option>".
						 "<option value='64' style='display:none;'>64 hexadecimal</option>";
			}
		} else if (strlen($key) == 13 || strlen($key) == 26) {
			if(strlen($key) == 13){
				$this->output .= "<option value='5' style='display:none'>5 alphanumeric characters</option>".
						 "<option value='10' style='display:none'>10 hexadecimal</option>".
						 "<option value='13' selected>13 alphanumeric characters</option>".
						 "<option value='26'>26 hexadecimal</option>".
						 "<option value='63' style='display:none;'>8 - 63 alphanumeric characters</option>".
						 "<option value='64' style='display:none;'>64 hexadecimal</option>";
			} else {
				$this->output .= "<option value='5' style='display:none'>5 alphanumeric characters</option>".
						 "<option value='10' style='display:none'>10 hexadecimal</option>".
						 "<option value='13'>13 alphanumeric characters</option>".
						 "<option value='26' selected>26 hexadecimal</option>".
						 "<option value='63' style='display:none;'>8 - 63 alphanumeric characters</option>".
						 "<option value='64' style='display:none;'>64 hexadecimal</option>";
			}
		} else {
			$this->output .= "<option value='5'>5 alphanumeric characters</option>".
					  "<option value='10'>10 hexadecimal</option>".
					  "<option value='13'>13 alphanumeric characters</option>".
					  "<option value='26' selected>26 hexadecimal</option>".
					  "<option value='63'>8 - 63 alphanumeric characters</option>".
					  "<option value='64'>64 hexadecimal</option>";
		}
		$this->output .= "</select>".
			"<input type='password' name='network_key' value='".$key."'>".
			"</td></tr>".
			"<tr id='eapMethod'><td>EAP Method:</td><td><select name='eap_method' id='eap_method' onChange='chooseEAP2();'>";
		switch($eap[0]) {
		case 'tls':
			$this->output .= 
				"<option value='tls' selected='selected'>TLS</option>".
				"<option value='ttls'>TTLS</option>".
				"<option value='fast'>FAST</option>".
				"<option value='peap'>PEAPv0-MSCHAPv2</option>".
				"<option value='leap'>LEAP</option></select></td></tr>";
			break;
		case 'ttls':
			$this->output .= 
				"<option value='tls'>TLS</option>".
				"<option value='ttls' selected='selected'>TTLS</option>".
				"<option value='fast'>FAST</option>".
				"<option value='peap'>PEAPv0-MSCHAPv2</option>".
				"<option value='leap'>LEAP</option></select></td></tr>";
			break;
		case 'fast':
			$this->output .= 
				"<option value='tls'>TLS</option>".
				"<option value='ttls'>TTLS</option>".
				"<option value='fast' selected='selected'>FAST</option>".
				"<option value='peap'>PEAPv0-MSCHAPv2</option>".
				"<option value='leap'>LEAP</option></select></td></tr>";
			break;
		case 'peap':
			$this->output .= 
				"<option value='tls'>TLS</option>".
				"<option value='ttls'>TTLS</option>".
				"<option value='fast'>FAST</option>".
				"<option value='peap' selected='selected'>PEAPv0-MSCHAPv2</option>".
				"<option value='leap'>LEAP</option></select></td></tr>";
			break;
		default:
		case 'leap':
			$this->output .= 
				"<option value='tls'>TLS</option>".
				"<option value='ttls'>TTLS</option>".
				"<option value='fast'>FAST</option>".
				"<option value='peap'>PEAPv0-MSCHAPv2</option>".
				"<option value='leap' selected='selected'>LEAP</option></select></td></tr>";
			break;
		}

		$this->output .= 
			"<tr id='a_ident'><td>Anonymous identity:</td><td>".
			"<input type='text' name='anonymous_identity' value='".$aident."'></td></tr>".
			
		
			"<tr id='u_c'><td>User certificate:</td><td>".
			"<input type='file' name='client_cert' id='u_cert'></td></tr>";
			$this->output .= "<tr id='ua_c2'><td colspan='2'><i>Actual File: ".$uac."<input type='hidden'".
			"name='client_cert_h' value='".$uac."'></i></td></tr>";
			$this->output .= "<tr id='ca_c'><td>CA certificate:</td><td>".
			"<input type='file' name='ca_cert' id='test'></td></tr>";
			$this->output .= "<tr id='ca_c2'><td colspan='2'><i>Actual File: ".$cac."<input type='hidden'".
			"name='ca_cert_h' value='".$cac."'></i></td></tr>";
			$this->output .= "<tr id='private_key'><td>Private key:</td><td>".
			"<input type='file' name='private_key' id='pk'></td></tr>";
			$this->output .= "<tr id='pk2'><td colspan='2'><i>Actual File: ".$private_key."<input type='hidden'".
			"name='private_key_h' value='".$private_key."'></i></td></tr>";

			$this->output .= "<tr id='private_key_password'><td>Private key password:</td><td>".
					  "<input type='password' name='private_key_password' value='".$ppwd."'></td></tr>".
					"<tr id='phase2_auth'><td>Phase2 Authentication:".
					"</td><td><select name='ph2_auth' id='ph2_auth'>";
				switch($phase2_auth) {
				case 'pap':
					$this->output .= 
						"<option value='pap' selected='selected'>pap</option>".
						"<option value='mschap'>mschap</option>".
						"<option value='mschapv2'>mschapv2</option>".
						"<option value='chap'>chap</option></select></td></tr>";
					break;
				case 'mschap':
					$this->output .= 
						"<option value='pap'>pap</option>".
						"<option value='mschap' selected='selected'>mschap</option>".
						"<option value='mschapv2'>mschapv2</option>".
						"<option value='chap'>chap</option></select></td></tr>";
					break;
				case 'mschapv2':
					$this->output .= 
						"<option value='pap'>pap</option>".
						"<option value='mschap'>mschap</option>".
						"<option value='mschapv2' selected='selected'>mschapv2</option>".
						"<option value='chap'>chap</option></select></td></tr>";
					break;
				case 'chap':
					$this->output .= 
						"<option value='pap'>pap</option>".
						"<option value='mschap'>mschap</option>".
						"<option value='mschapv2'>mschapv2</option>".
						"<option value='chap' selected='selected'>chap</option></select></td></tr>";
					break;
				default:
					$this->output .= 
						"<option value='pap' selected='selected'>pap</option>".
						"<option value='mschap'>mschap</option>".
						"<option value='mschapv2'>mschapv2</option>".
						"<option value='chap'>chap</option></select></td></tr>";
					break;
				}
			
			
		$this->output .= "<tr id='ident'><td valign=\"top\">User Name:</td><td align=\"left\">".
			"<input type='text' name='identity' value='".$ident."'><br/><small>(Format: user@domain)</small></td></tr>".
			"<tr id='pwd'><td>Password:</td><td>".
			"<input type='password' name='password' value='".$pwd."'></td></tr>".
			"</table></fieldset>";
	}


	function addButton($buttonName, $buttonValue)
	{
		$this->output .= "<input type='submit' id='button' name='".$buttonName."' value='".$buttonValue."'>";
	}
	
	function addBr()
	{
		$this->output .= "<br />";
	}

	function addSelect($name, $values)
	{
		$this->output .= "<select name='".$name."'>";
		foreach ($values as $val) {
			$this->output .= "<option value='".$val['value']."'>".$val['show']."</option>";
		}
		$this->output .= "</select>";
	}

	function addActiveConnBox($activeConns){
		$this->output .= "<fieldset id='ActiveConn'><legend>Active Connections</legend><table id='t1' border='1'><tr id='t1h'><th>Name</th>".
				 "<th>IP Address</th><th>Subnet Mask</th><th>Gateway</th><th>Type</th><th>Driver</th><th>State</th></tr>";
		foreach ($activeConns as $activeConn){
			$state = $activeConn['state'];
			if ($state == 2) {
				$state = "connected";
			} else if ($state == 1) {
				$state = "connecting";
			}

			$this->output .= "<tr><td class='t1d'><strong>".$activeConn['name']."</strong></td>".
					  "<td class='t1d'>".$activeConn['ip']."</td><td class='t1d'>".$activeConn['subnet'].
					  "</td><td class='t1d'>".$activeConn['gateway']."</td>".
					  "<td class='t1d'>".$activeConn['type']."</td><td class='t1d'>".$activeConn['driver']."</td>".
					  "<td class='t1d'>".$state."</td></tr>";
		}
		$this->output .="</table></fieldset>";
	}
	function addHidden($name, $value) {
		$this->output .= "<input type='hidden' name='".$name."' value='".$value."'>"; 
	}

	function render()
	{
		$this->output .= "</form></p>";
		echo $this->output;
	}
  
	function __toString()
	{
		$this->render();
	}

}


class ConnectionList
{
	var $hidden;
	var $button1;
	var $button2;
	var $target;
	var $output;

	function __construct ($hidden, $button1, $button2, $target)
	{
		$this->hidden = $hidden;
		$this->button1 = $button1;
		$this->button2 = $button2;
		$this->target = $target;
		
		$this->output =
			"<p><table align='center' style='width:100%'>";
	}

	function addElement($element)
	{
		if(preg_match('/^\d\#\sDefaultEth$/i', $element['show'])){
			$this->output .= "<form action='".$this->target."' method='POST'><tr>".
				 "<td style='width:75%;text-align:left'>".$element['show']."</td>".
				 "<input type='hidden' name='".$this->hidden."' value='".$element['value']."' title='Edit'>".
				 "<td style='width:12%;text-align:left'><input type='submit' name='".$this->button1[0]."' value='Show' style='width:auto'></td>". 	                                  
				 "</tr></form>";
		} else {
			$this->output .= "<form action='".$this->target."' method='POST'><tr>".
					"<td style='width:75%;text-align:left'>".$element['show']."</td>".
					"<input type='hidden' name='".$this->hidden."' value='".$element['value']."' title='Edit'>".
					"<td style='width:12%;text-align:left'><input type='submit' name='".$this->button1[0]."' value='Edit' style='width:auto'></td>";                                 
			if(!preg_match('/^\d\#\sDefaultWLAN$/i', $element['show'])) {
				$this->output .= "<td style='width:12%;text-align:left'><input type='submit' name='".$this->button2[0]."' value='Delete' style='width:auto'></td>";
			}
			$this->output .= "</tr></form>";
		}

	}

	function addMore ($array)
	{
		foreach ($array as $entry) {
			$this->addElement($entry);
		}

	}

	function render()
	{
		$this->output .= "</table></p>";
		echo $this->output;
	}
  
	function __toString()
	{
		$this->render();
	}

}








?>
