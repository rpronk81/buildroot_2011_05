<?php
error_reporting(0);

include "validate.php";
include '../common.inc.php';
session_start();

if($_SESSION['DbusAuth'] != "yes"){
	echo "You have no permission to view this page, please login!";
	echo "<meta HTTP-EQUIV='REFRESH' content='1; url=../index.html'>";
	exit(1);
}
error_reporting(E_ERROR | E_WARNING | E_PARSE);
?>
<html>
<head><title>Template Test</title>
<link rel="stylesheet" type="text/css" href="prototype.css">
<link rel="stylesheet" type="text/css" href="jquery.readonly.css">
<script type="text/javascript" src="prototype.js"></script> 
<script type="text/javascript" src="jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="jquery.readonly.js"></script>
</head>
<body>
<?php
include "template.php";
include "dbus_classes.php";


$dbus = new Dbus_Connection();
$nav = new NaviBanner();
$nav->render();

if (isset($_POST['ethConn'])) {
	$conns = $dbus->get_connections();
	$conn = get_spec_conn($_POST['eth'], $conns);
	$aConns = $dbus->get_active_conns();
	$deactivate = false;
	foreach ($aConns as $aConn) {
		if($conn->ConnPath == $aConn['real']) {
			$deactivate = true;
			$active = $aConn['activ'];
		}
	}
	
	if($dbus->activate_conn($conn->ConnPath, $conn->type)) {
		echo "Connecting";
		forward("controller.php", 1);
	} else {
		PrintError("Error occured. Not connected!");
		forward("controller.php", 2);
	}
}

if (isset($_POST['wlanConn'])) {
	$conns = $dbus->get_connections();
	$conn = get_spec_conn($_POST['wlanSav'], $conns);
	$aConns = $dbus->get_active_conns();
	$deactivate = false;
	foreach ($aConns as $aConn) {
		if($conn->ConnPath == $aConn['real']) {
			$deactivate = true;
			$active = $aConn['activ'];
		}
	}

	if($dbus->getWlanState()) {
		if($dbus->activate_conn($conn->ConnPath, $conn->type)) {
			echo "Connecting";
			forward("controller.php", 1);
		} else {
			PrintError("Error occured. Not connected!");
			forward("controller.php", 2);
		}
	} else {
		echo "WLAN is off, please turn it on.";
		forward("controller.php", 3);
	}
}

if (isset($_POST['wlanAp']) || $_GET['wlanAp']==1) {
	echo " <script type='text/javascript'>
			$(document).ready(function() {
				  switchMode();
				  switchdns_ipv4();
				  switchdns_ipv6();
				  switchMethod_ipv4();
				  switchMethod_ipv6();
				  switchIp();
				  chooseEncrypt();
				});
			</script>";
	$form = new NetworkForm("addWConn", "quick.php");
	if(isset($_POST['wlanNSav'])) {
		$form->addWlanConnSettsFrame("New_Wireless_Conn", $_POST['wlanNSav']);
	} else {
		$form->addWlanConnSettsFrame("New_Wireless_Conn", $_SESSION['lastformvars']['ssid'], $_SESSION['lastformvars']['mode']);
	}

	if($_SESSION['lastformvars']['check']=='false') {
		if ($_SESSION['lastformvars']['ipv']=='IPv4') {
			SaveIpv4Session($form);
		} else {
			SaveIpv6Session($form);
		}
	} else {
		$form->addIpSettsFrame();
		$form->addIpSettsFrame(6);
	}
	
	if($_SESSION['lastformvars']['check']=='false') {
		$ses = $_SESSION['lastformvars'];
		$form->addWlanSecFrame($ses['network_auth'], array($ses['eap_method']), false, $ses['network_key'], $ses['identity'],
					$ses['password'], $ses['ca_cert'], $ses['client_cert'], $ses['anonymous_identity'],
					$ses['private_key'], $ses['ph2_auth'], $ses['private_key_password']);
	} else {
		$form->addWlanSecFrame();
	}
	$form->addBr();
	$form->addButton("createW", "Save connection and connect");
	$form->addBr();
	$form->render();
	PrintErrorList($_SESSION['errors']->error);
}

if (isset($_POST['doArp'])) {
        $res = exec("nohup /bin/sh -c '/sbin/enableARP.sh' > /dev/null 2>&1 &");
        if ($res == "") {
                echo "<span style='color:green; font-weight:bold;'>Gratuitous ARP has been enabled</span>";
        }
        else
        {
                echo "<span style='color:red; font-weight:bold;'>FAILED to enable gratuitousARP: ".$res."</span>";
        }

        forward("controller.php",14);
}

if (isset($_POST['disableArp'])) {
        $res = exec("nohup /bin/sh -c '/sbin/disableARP.sh' > /dev/null 2>&1 &");
        if ($res == "") {
                echo "<span style='color:red; font-weight:bold;'>Gratuitous ARP has been disabled</span>";
        }
        else
        {
                echo "<span style='color:red; font-weight:bold;'>FAILED to disable gratuitousARP: ".$res."</span>";
        }

        forward("controller.php",14);
}

if (isset($_POST['newConn'])) {
	$form = new NetworkForm("selectType", "quick.php");
	echo "<fieldset>";

	exec("wifiBridge.sh -chkEnabled", $output, $ret);
	if ($ret == "1") {
		$form->addSelect("chType",array(array('show'=>"LAN",'value'=>"Ethernet")));
	}
	else
	{
		$form->addSelect("chType",array(array('show'=>"LAN",'value'=>"Ethernet"),
					array('show'=>"WLAN", 'value'=>"WLan")));
	}

	$form->addBr();
	$form->addButton("choose", "Choose a type");
	$form->render();
	echo"</fieldset>";
}

if (isset($_POST['createW'])) {
	$cac = saveUploadedFile($_FILES['ca_cert']);
	if($cac != false)
		$_POST['ca_cert'] = $cac;

	$clc = saveUploadedFile($_FILES['client_cert']);
	if($clc != false)
		$_POST['client_cert'] = $clc;
	
	$pk = saveUploadedFile($_FILES['private_key']);
	if($pk != false)
		$_POST['private_key'] = $pk;

	$v = new Validator();
	$check = true;
	SavePostinSession($_POST);
	if($_POST['ipv'] == 'IPv4' && $_POST['ipv4method'] != 'auto') {

		if(!$v->check_ipv4($_POST['ipv4ip'], "ipv4address"))
			$check = false;
		if(!$v->check_ipv4($_POST['ipv4subnet'], "ipv4subnet"))
			$check = false;
		if(!$v->check_ipv4_gateway($_POST['ipv4gate'], ipv4gateway))
			$check = false;

		
	} else if ($_POST['ipv'] == 'IPv6' && $_POST['ipv6method'] != 'auto') {

		if(!$v->check_ipv6($_POST['ipv6ip'], "ipv6address"))
			$check = false;
		if(!$v->check_ipv6_subnetmask($_POST['ipv6subnet'], "ipv6subnetmask"))
			$check = false;
		if(!$v->check_ipv6_gateway($_POST['ipv6gate'], "ipv6gateway"))
			$check = false;
	}
	if($_POST['ipv'] == 'IPv4' && $_POST['ipv4dnsIgnoreAuto'] == 'true') {

		if(!$v->check_ipv4_dns($_POST['ipv4dns'], "ipv4dns"))
			$check = false;
	} else if($_POST['ipv'] == 'IPv6' && $_POST['ipv6dnsIgnoreAuto'] == 'true') {

		if(!$v->check_ipv6_dns($_POST['ipv6dns'], "ipv6dns"))
			$check = false;
	}

	if(!$v->check_ssid($_POST['ssid']))
		$check = false;
	if(isset($_POST['channel'])){
		if(!$v->check_channel_id($_POST['channel']))
			$check = false;
	}
	if($_POST['network_auth'] == 'wpa-psk'){
		if(!$v->check_networkkey_wpa($_POST['network_key']))
			$check = false;
	} else if($_POST['network_auth'] == 'none' || $_POST['network_auth'] == 'shared') {
		if($_POST['encryption'] == 'wep64') {
			if(!$v->check_networkkey_wep64($_POST['network_key']))
				$check = false;
		}
		else if ($_POST['encryption'] == 'wep128') {
			if(!$v->check_networkkey_wep128($_POST['network_key']))
				$check = false;
		}
	} else if ($_POST['network_auth'] == 'wpa-eap') {
		if ($_POST['eap_method'] != 'tls' && ($_POST['identity'] != '' && $_POST['anonymous_identity'] == '')){
			if(!$v->check_password($_POST['password']))
				$check = false;
		}
		if ($_POST['identity'] != ''){
			if(!$v->check_identity($_POST['identity']))
				$check = false;
		} else {
			if(!$v->check_identity($_POST['anonymous_identity']))
				$check = false;
		}
	}
	if($check) {
		$construct = createConstructFromPost("802-11-wireless", $_POST);
		$dbus->add_connection($construct);
		sleep(2);
		$uuid = $construct['connection']['uuid'][1];
		$con = $dbus->get_connections();
		foreach ($con as $conn) {
			if ($conn->uuid == $uuid) {
				$desConn = $conn;
				break;
			}
		}
		if($dbus->activate_conn($desConn->ConnPath, $desConn->type)) {
			forward("controller.php",2);
		} else {
			PrintError("Error occured. Not connected!");
		}
		unset($_SESSION['lastformvars']);
		unset($_SESSION['errors']);
		forward("controller.php", 2);
	} else {
		$_SESSION['errors'] = $v;
		$_SESSION['lastformvars']['check'] = 'false';
		forward("quick.php?wlanAp=1", 0);
	}

}

if (isset($_POST['choose']) || $_GET['choose']==1) {
    #TAMAR - override type to be wireless if running on battery
    if (GetBoard() == "spacecomlite") {
		$_POST['chType'] = "WLan";
    }

	if(isset($_POST['chType'])) {
		$type = $_POST['chType'];
	} else {
		$type = $_GET['type'];
	}
// 	var_dump($_SESSION);

	$form = new NetworkForm("addConn", "quick.php");
	$form->addHidden("sType", $type);
	if ($type == 'WLan') {	
		echo " <script type='text/javascript'>
			$(document).ready(function() {
				  switchMode();
				  switchdns_ipv4();
				  switchdns_ipv6();
				  switchMethod_ipv4();
				  switchMethod_ipv6();
				  switchIp();
				  chooseEncrypt();
				});
			</script>";
		
		if($_SESSION['lastformvars']['check']=='false') {
			$ses = $_SESSION['lastformvars'];
			$form->addWlanConnSettsFrame($ses['id'], $ses['ssid'], $ses['mode'], '', '', $ses['channel'], $ses['txpower']);
			if ($_SESSION['lastformvars']['ipv']=='IPv4') {
				SaveIpv4Session($form);
			} else {
				SaveIpv6Session($form);
			}
		} else {
			$form->addWlanConnSettsFrame("New_Wireless_Conn", "Please enter SSID", "");
			$form->addIpSettsFrame();
			$form->addIpSettsFrame(6);
		}
		if($ses['check']=='false') {

			$form->addWlanSecFrame($ses['network_auth'], array($ses['eap_method']), false, $ses['network_key'], $ses['identity'],
						$ses['password'], $ses['ca_cert'], $ses['client_cert'], $ses['anonymous_identity'],
						$ses['private_key'], $ses['ph2_auth'], $ses['private_key_password'], $ses['encryption']);
		} else {
			$form->addWlanSecFrame();
		}
	} else {
		echo "<script type='text/javascript'>
		      $(document).ready(function() {
			      switchdns_ipv4();
			      switchdns_ipv6();
			      switchMethod_ipv4();
			      switchMethod_ipv6();
			      switchIp();
			    });
		    </script>";
		$form->addEthConnSettsFrame("New_Wired_Conn");
		if($_SESSION['lastformvars']['check']=='false') {
			if ($_SESSION['lastformvars']['ipv']=='IPv4') {
				SaveIpv4Session($form);
			} else {
				SaveIpv6Session($form);
			}
		} else {
			$form->addIpSettsFrame();
			$form->addIpSettsFrame(6);
		}
	}

	$form->addButton("createConn", "Save changes");
	$form->addBr();
	$form->render();
	PrintErrorList($_SESSION['errors']->error);
}

if (isset($_POST['createConn'])) {

	$v = new Validator();

    // If a new connection is created, update the ssid in the driver, 
    // in case we are running on a hidden network
    exec("touch /tmp/do_fgscan");

	$check = true;
	if ($_POST['sType'] == 'WLan') {
		$cac = saveUploadedFile($_FILES['ca_cert']);
		if($cac != false)
			$_POST['ca_cert'] = $cac;

		$clc = saveUploadedFile($_FILES['client_cert']);
		if($clc != false)
			$_POST['client_cert'] = $clc;
		
		$pk = saveUploadedFile($_FILES['private_key']);
		if($pk != false)
			$_POST['private_key'] = $pk;
	}
	SavePostinSession($_POST);
	if (!$v->check_name($_POST['id'])) {
		$check = false;
	}
	if($_POST['ipv'] == 'IPv4' && $_POST['ipv4method'] != 'auto') {
		if(!$v->check_ipv4($_POST['ipv4ip'], "ipv4address")) {
			$check = false;
		}
			
		if(!$v->check_ipv4($_POST['ipv4subnet'], "ipv4subnetmask")) {
			$check = false;
		}
			
		if(!$v->check_ipv4_gateway($_POST['ipv4gate'], "ipv4gateway")) {
			$check = false;
		}
	} else if($_POST['ipv'] == 'IPv4' && $_POST['ipv4method'] == 'auto') {

	} else if ($_POST['ipv'] == 'IPv6' && $_POST['ipv6method'] != 'auto') {

		
		if(!$v->check_ipv6($_POST['ipv6ip'], "ipv6ipaddress")) {
			$check = false;
		}
			
		if(!$v->check_ipv6_subnetmask($_POST['ipv6subnet'], "ipv6subnetmask")) {
			$check = false;
		}
			
		if(!$v->check_ipv6_gateway($_POST['ipv6gate'], "ipv6gateway")) {
			$check = false;
		}
			
	} else if($_POST['ipv'] == 'IPv6' && $_POST['ipv6method'] == 'auto') {

	}
	if(($_POST['ipv'] == 'IPv4' && $_POST['ipv4dnsIgnoreAuto'] == 'true')) {
		
		if(!$v->check_ipv4_dns($_POST['ipv4dns'], "ipv4dns")) {
			$check = false;
		}
			
	} else if($_POST['ipv'] == 'IPv6' && $_POST['ipv6dnsIgnoreAuto'] == 'true') {
		if(!$v->check_ipv6_dns($_POST['ipv6dns'], "ipv6dns")) {
			$check = false;
		}
			
	}
	if ($_POST['sType'] == 'WLan') {
		

		if(!$v->check_ssid($_POST['ssid'], "ssid")) {
			$check = false;
		}
		
		if(isset($_POST['channel'])){
			if(!$v->check_channel_id($_POST['channel'], "channel")) {
				$check = false;
			}
				
		}

		if($_POST['network_auth'] == 'wpa-psk'){

			if(!$v->check_networkkey_wpa($_POST['network_key'], $_POST['keyFormat'])) {
				$check = false;
			}
				
		} else if($_POST['network_auth'] == 'open' || $_POST['network_auth'] == 'shared') {
			if($_POST['encryption'] == 'wep64') {
				if(!$v->check_networkkey_wep64($_POST['network_key'], "networkkey wep64", $_POST['keyFormat'])) {
					$check = false;	
				}
					
			}
			else if ($_POST['encryption'] == 'wep128') {
				if(!$v->check_networkkey_wep128($_POST['network_key'], $_POST['keyFormat'])) {
					$check = false;
				}
					
			}
		} else if ($_POST['network_auth'] == 'wpa-eap') {
			if ($_POST['eap_method'] != 'tls' && ($_POST['identity'] != '' && $_POST['anonymous_identity'] == '')){
				if(!$v->check_password($_POST['password']))
					$check = false;
			}
			if ($_POST['identity'] != ''){
				if(!$v->check_identity($_POST['identity']))
					$check = false;
			} else {
				if(!$v->check_identity($_POST['anonymous_identity']))
					$check = false;
			}
		}
		if(!$construct = createConstructFromPost("802-11-wireless", $_POST, 'true')){
			PrintError("Error! Connection List is full!");
			forward("controller.php", 2);
			exit (0);
		}
	} else {
		if(!$construct = createConstructFromPost("802-3-ethernet", $_POST, 'true')){
			PrintError("Error! Connection List is full!");
			forward("controller.php", 2);
			exit (0);
		}
	}


	if($check) {
		$dbus->add_connection($construct);
		sleep(2);
		$uuid = $construct['connection']['uuid'][1];
		$con = $dbus->get_connections();
		foreach ($con as $conn) {
			if ($conn->uuid == $uuid) {
				$desConn = $conn;
				break;
			}
		}
		unset($_SESSION['lastformvars']);
		unset($_SESSION['errors']);
		echo "Connection created";
		forward("controller.php", 2);
	} else {
		$_SESSION['errors'] = $v;
		$_SESSION['lastformvars']['check'] = 'false';
		forward("quick.php?type=".$_POST['sType']."&choose=1", 0);
	}

}


?>
</body>
</html>
