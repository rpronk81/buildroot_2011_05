<?php
include '../common.inc.php';
VerifyConfigAuth();

if (isset($_GET['savelog'])) {
	$download = $_GET['download'];
	header("Content-Type: application/octet-stream");
	header("Content-Disposition: attachment; filename=\"log.txt\"");
	passthru('/sbin/updaterwr --show-log', $result);
} else {
	StyleTitle("System log");
	include 'dbus_classes.php';

	echo "<center><div id = lognavi>";
	echo "<a href='showlogs.php?writelog=1'><b>Show log on Page</b></a> ";
	echo "<a href='showlogs.php?savelog=1'><b>Save log</b></a><br />";
	echo "</div></center>";

	if (isset($_GET['writelog'])) {
		echo "<pre>";
		passthru('/sbin/updaterwr --show-log', $result);
		echo "</pre>";
	}
}
?>
