<?php
include 'dbus_classes.php';
$dbus = new Dbus_Connection();
echo "<pre>";
$res = $dbus->getIpInfosFromDevice("/org/freedesktop/NetworkManager/Devices/0");
var_dump($res);
echo "</pre>";
?>