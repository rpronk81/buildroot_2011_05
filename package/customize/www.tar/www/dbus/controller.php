<?php 
include '../common.inc.php';
VerifyConfigAuth();
?>
<html>
<head><title>NetworkManager</title>
<link rel="stylesheet" type="text/css" href="prototype1.css">
<script type="text/javascript" src="prototype.js"></script> 
<script type="text/javascript" src="jquery-1.4.2.min.js"></script>
<script type="text/javascript" language="javascript">
	var xmlHttp = false;
	
	try {
	    xmlHttp  = new ActiveXObject("Msxml2.XMLHTTP");
	} catch(e) {
	    try {
	        xmlHttp  = new ActiveXObject("Microsoft.XMLHTTP");
	    } catch(e) {
	        xmlHttp  = false;
	    }
	}
	
	if (!xmlHttp  && typeof XMLHttpRequest != 'undefined') {
	    xmlHttp = new XMLHttpRequest();
	}

	refresh();

	setInterval("refresh()",10000);

	function refresh()
	{
	if (xmlHttp) {
	     xmlHttp.open('GET', 'controller.php', true);
	     xmlHttp.onreadystatechange = function () {
	         if (xmlHttp.readyState == 4) {
	             document.getElementsByTagName("html")[0].innerHTML = xmlHttp.responseText;
	         }
	     };
	     xmlHttp.send(null);
	 }
	}
</script>
</head>
<body>
<?php
include "template.php";
include "dbus_classes.php";
$dbus = new Dbus_Connection();

$array = $dbus->get_connections();
$aConns = $dbus->get_active_conns(true);
$eths= array();
foreach($array as $ar) {
	if($ar->type == '802-3-ethernet'){
		if (in_array($ar->ConnPath, $aConns)) {
			$eths[] = array('id'=>$ar->id, 'path'=>$ar->ConnPath, 'active'=>true);
		} else {
			$eths[] = array('id'=>$ar->id, 'path'=>$ar->ConnPath, 'active'=>false);
		}
	}
}
$aps = $dbus->get_reachable_wlan();
$acp = array();
foreach($aps as $ap) {
	$acp[] = $ap['ssid'];
}
$wlans = array();
foreach($array as $ar) {
	if($ar->type == '802-11-wireless'){
		$wlans[] = $ar;
	}
}
$reWlan = array();
foreach ($wlans as $w) {
	if (in_array($w->ConnPath, $aConns)) {
		$reWlan[] = array('id'=>$w->id, 'path'=>$w->ConnPath, 'active'=>true);
	} else {
		$reWlan[] = array('id'=>$w->id, 'path'=>$w->ConnPath, 'active'=>false);
	}
}
$nav = new NaviBanner();
$nav->render();
echo	"<h1>Welcome to the Network Management Interface</h1><br />".
	"Please use the navigation menu on top for advanced options".
	"<p><h3>Quick Start:</h3></p>";
asort($eths);
asort($reWlan);
$form = new NetworkForm("welcome", "quick.php");
$form->addBr();
#TAMAR replaced newConn with choose
#$form->addButton("newConn", "Create a new Connection");
if (GetBoard() == "spacecomlite") {
    #Bypass allowing the user to select an ethernet connection since
    #they don't exist on battery
	$form->addButton("choose", "Create a new Wireless Connection");
} else {
	$form->addButton("newConn", "Create a new Connection");
}
$form->addBr();

if (GetBoard() != "spacecomlite") {
	$form->addConn2EthFrame("ethConn", $eths);
}

$filename = '/etc/spacecom/protected/enableARP';

exec("/sbin/wifiBridge.sh -chkEnabled", $output, $ret); 
if ($ret == "0") {
	$form->addConn2ReachWlanFrame("wlanConn", $reWlan, "wlanAp", $acp);
}

$form->addBr();
$form->addActiveConnBox($dbus->getIpInfosFromActive());
$form->addBr();
$form->addBr();
if (GetBoard() == "spacecom2") {
	exec("/sbin/wifiBridge.sh -chkEnabled", $output, $ret); 
	if ($ret == "0") {
		if (file_exists($filename)) {
			echo "<span style='color:green; font-weight:bold;'>ARP enabled</span>";
			#if the enableARP file exists then gratuitousARP is enabled
			$form->addButton("disableArp", "Disable Gratuitous ARP");
		} else {
			echo "<span style='color:red; font-weight:bold;'>ARP disabled</span>";
			#if the enableARP file does not exist then gratuitousARP is disabled
			$form->addButton("doArp", "Enable Gratuitous ARP");
		}
	}
}
else
{
	if (file_exists($filename)) {
		echo "<span style='color:green; font-weight:bold;'>ARP enabled</span>";
		#if the enableARP file exists then gratuitousARP is enabled
		$form->addButton("disableArp", "Disable Gratuitous ARP");
	} else {
		echo "<span style='color:red; font-weight:bold;'>ARP disabled</span>";
		#if the enableARP file does not exist then gratuitousARP is disabled
		$form->addButton("doArp", "Enable Gratuitous ARP");
	}
}

$form->render();

?>

</body>
</html>
