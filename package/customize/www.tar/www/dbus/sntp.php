<?php
include '../common.inc.php';
VerifyConfigAuth();
StyleTitle("SNTP settings");



function upload($fname)
{
   	$fname = $_FILES['timezone']['name'];
	$linkname = "/etc/spacecom/localtime";
	$folder = "/etc/spacecom/";
	$folders[] = $folder;
	cleanup($folders);
	// For compatibility with canfileio, force limited filenames
	if (!preg_match('/(^localtime_[a-zA-Z-_0-9]*$)/', $fname)) {
		PrintError("Timezone filename must be localtime_*."); 
		return;
	}
	$dest = $folder.$fname;
	if (!move_uploaded_file($_FILES['timezone']['tmp_name'], $dest)) {
		PrintError("Failed to rename timezone.");
		return;
	}
	if (is_writable($linkname)) {
	    unlink($linkname);
	}
	if (!symlink($dest, "/etc/spacecom/localtime"))
		PrintError("Failed to symlink timezone."); 
}

if (isset($_POST['save'])) {
	if ($_FILES['timezone']['name'] != "")
		upload($fname);

	// save server address 
	$file = fopen("/etc/spacecom/ntpd.conf", "w") or exit("Unable to open file!");
	$string = "server ".$_POST['server']."\n";
	fwrite($file, $string);
	fclose($file);
	exec("/sbin/ntpd_settings_proxy");
	exec("/sbin/wifiBridge.sh -setDate");
}

$file = fopen("/etc/spacecom/ntpd.conf", "r") or exit("Unable to open file!");
$actualfilename = get_actual_filename('/etc/spacecom/');
while (!feof($file)) {
	$line = fgets($file);
	if (preg_match('/^server /i', $line))
		$ip = str_replace('server ', "", $line);
}
fclose($file);

if (isset($_POST['setDate'])) {
	$timeToSet=$_POST['time'];
	if (preg_match("/^(?P<year>[0-9]{4})-(?P<month>[0-9]{2})-(?P<day>[0-9]{2}) +(?P<hour>[0-9]{2}):(?P<minute>[0-9]{2}):(?P<second>[0-9]{2})$/", $timeToSet, $matches)) { //MMDDhhmmCCYY.ss
		exec("/sbin/ntpd_settings_proxy ".$matches["month"].$matches["day"].$matches["hour"].$matches["minute"].$matches["year"].".".$matches["second"]." 2>&1");
		exec("/sbin/wifiBridge.sh -setDate");
		$timeSetMsg="Time set.";
	} else {
		$timeSetMsg="Invalid time.";
	}
}

echo "<center><fieldset><legend>(S)NTP settings</legend><br /><form action='sntp.php' method='POST' enctype='multipart/form-data'>";
echo "<table><tr><td>Current Time: </td><td>";
passthru('date');
echo "</td></tr><tr>";
echo "<td>Actual File:</td><td><input type='text' value='".$actualfilename."' readonly></td></tr>";
echo "<td>Upload Timezone File:</td><td><input type='file' name='timezone' id='tz'></td></tr>";
echo "<tr><td>(S)NTP Server Address: </td><td><input type='text' name='server' value='".$ip."'></td></tr>";
echo "<tr><td colspan='2'><input type='submit' name='save' value='Save changes'></td></tr>";
echo "</table></form></fieldset></center>";
echo "<hr><center><fieldset><legend>Set time manually</legend><br /><form action='sntp.php' method='POST' enctype='multipart/form-data'>";
echo "<table>";
if (isset($_POST['setDate'])) {
	echo "<tr><td colspan='2'><b>".$timeSetMsg."</b></td></tr>";
}
echo "<tr><td>Time:</td><td><input type='text' name='time' value='";
passthru('date "+%F %H:%M:%S"');
echo "' /></td></tr><tr><td colspan='2'>Format: YYYY-MM-DD hh:mm:ss<br>e.g.: 2014-09-16 14:00:00</td>";
echo "<tr><td colspan='2'><input type='submit' name='setDate' value='Set Time'></td></tr>";
echo "</table></form></fieldset></center>";


function cleanup($folders)
{
	foreach($folders as $folder) {
		$files = scandir($folder);
		foreach($files as $file) {
			if (preg_match('/(^localtime_.*$)/', $file)) {
				unlink("$folder$file");
			}
		}
	}
}

function get_actual_filename($folder)
{
	$files = scandir($folder);
	foreach($files as $file) {
		if (preg_match('/(^localtime_.*$)/', $file)) {
			return $file;
		} 
	}
}

?>
