<?php

include 'common.inc.php';
include 'dbus/dbus_classes.php';
include 'wlan/docs/sshexec.php';
session_start();

$board = GetBoard();

StyleTitle("Web updater");
echo "<br />";
flush();

function BigMessage( $msg ) {
	print "<center><h1>";
	print gettext($msg);
	print "</h1></center>";

}

if (isset($_POST['PrepareUpdate'])) {
	echo '<div align="center" id="activity">Preparing for update. Please wait...<br /><br /><img src=/images/activity.gif /></div>';
	flush();
	echo "<pre>";
	passthru("/updater/prepare_update_wr 2>&1", $result);
	echo "</pre>";
	echo '<script language="javascript">document.getElementById("activity").style.display = "none";</script>';
	flush();
	if ($result != 0) {
		echo "Initialization exited with code " . $result . ". Please reboot.<br />";
		flush();
		exit();
	}

	print "<div align = \"center\"><form enctype=\"multipart/form-data\" action=\"../updater.php\" method=\"POST\">";
	// FIXME: determine right max file size! Does this do anything at all?
	print "<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"67108864\" />";
	print gettext("Upload Image: ");
	print "<input name=\"uploadedfile\" type=\"file\" /><br />";
	print "<br>";
	print "<input type=\"checkbox\" name=\"FactoryDefault\" value=\"1\"/> ";
	print gettext("Restore Factory Defaults after Update");
	print "<br> Please select \"";
	print gettext("Restore Factory Defaults after Update");
	print " when downgrading to a previous version of the firmware.";
	print "<br><br>";	
	print "<input type=\"submit\" name=\"updateFirmware\" value=\"Update Software\" />";
	print "</form></div>";

	exit();
}

if (isset($_POST['BootFallBack'])) {
	BigMessage("Will boot into fallback image");
	passthru("/sbin/updaterwr --run-fallback-prep");
} 

if (isset($_POST['updateFirmware'])) {
	$ttarget_path = "/tmp/";
	$ttarget_file = basename($_FILES['uploadedfile']['name']);
	$target_path = "";
	if ($board == "spacecom1" || $board == "spacecomlite") {
		$target_path = "/tmp/new_image";
	} else {
		$target_path = $ttarget_path . $ttarget_file;
	}

	if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
		if ($board == "spacecom1" || $board == "spacecomlite") {
			echo "<div align = \"center\">";
			echo "Checking image integrity...<br />";
			flush();
			echo "<pre>";
			passthru("/updater/check_image_wr", $result);
			echo "</pre>";
			if ($result != 0) {
				echo "Integrity check exited with code " . $result . ".<br />";
				echo "Please try again or reboot.<br /><br />";
				echo '<form><input type="button" value="Try again" onClick="javascript:history.go(-1)" /></form>';
				echo "</div>";
				flush();
				exit();
			}
			echo "OK.</div>";
			flush();
			echo '<script language="javascript">window.location="/update.html";</script>';
			flush();
			echo "<pre>";
			if (isset($_POST['FactoryDefault'])) {
				passthru("/sbin/updaterwr --restore-defaults-prep");
			}
			passthru("/do_update_wr 2>&1", $result);
			echo "</pre>";
			if ($result != 0) {
				echo "Update exited with code " . $result . ". Please reboot.<br />";
				flush();
				exit();
			}
			flush();
			exit(); // Exit here, so that the "Return to previous page" option below is not printed.
		} else {
			echo "Please wait until new image gets stored. System will reboot if store is successful.<br>";

			flush();
			if (isset($_POST['FactoryDefault'])) {
				$param = "--restore-defaults-prep ";
			}
			$param = $param . " --reboot --save-int " . $ttarget_path . escapeshellarg($ttarget_file);

			echo "<pre>" ;
			passthru('/sbin/updaterwr ' . $param . "  2>&1", $result);
			echo "</pre>" ;

			if ($result != 0) {
				echo "The updater exited with code " . $result . "<br>";
			} else {
				echo "Image stored, reboot needed to perform the update. (Hmm, this should be never reached)<br>";
			}
			flush();
			unlink($target_path);
		}
	} else {
		echo "There was an error uploading the firmware to http server, please try again!";
	}
}

if (isset($_POST['updateFirmwareWifiBridge'])) {
	$ttarget_path = "/tmp/";
	$ttarget_file = basename($_FILES['uploadedwififile']['name']);
	$target_path = "";
	$target_path = $ttarget_path . $ttarget_file;

 	$dbus_auth = $_SESSION['DbusAuth'];

 	if (isset($_POST['FactoryDefaultWifi'])) {
		$_SESSION['FactoryDefaultSetting'] = "True";
	}
	else
	{
		$_SESSION['FactoryDefaultSetting'] = "False";
	}

	if (move_uploaded_file($_FILES['uploadedwififile']['tmp_name'], $target_path)) {
$bridgeIsUp = "false";
		$_SESSION['target_path'] = $target_path;
		flush();
		echo '<script language="javascript">window.location="/updateWifi.php";</script>';
		flush();
	}
	else
	{
                echo "There was an error uploading the firmware to http server, please try again!";
	}
}

if ($_POST["FactoryDefault"] == "1") {
	BigMessage("System will be reset to factory defaults.");
	passthru("/sbin/updaterwr --restore-defaults-prep");
}

if ($_POST["Reboot"] == "1") {
        print "<p><p><p><p><p><p><p>";
	BigMessage("SpaceCom will be restarted now.");

   	if ($_POST["WifiMessage"] == "1") {
   		print gettext("Booting into fallback for firmware update. Note that you'll have to reconfigure the wifi network to mode ad-hoc, essid SpaceComFallback to connect to SpaceCom in fallback mode. Wait 2 minutes, then configure the network, and go to <a href=\"http://192.168.101.41/\">http://192.168.101.41/</a> to upload the image and finish the update.");
        }
   	flush();
		
	// /sbin/updater already includes sleep, so TCP will have time to deliver
	// back to the client 
	exec("/sbin/updaterwr --reboot");
}
?>
<br />
<br />
<div align = "center">
<form>
<input type="button" value="Return to previous page" onClick="javascript:history.go(-1)" />
</form>
</div>
</body>
</html>
