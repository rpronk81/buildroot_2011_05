<?php
include 'common.inc.php';

VerifyConfigAuth();
?>
<script type="text/javascript">
	function changeChecked(id) {

		var checked = document.getElementById(id).checked;
		if(checked == true){
			for( var i=1; i<=13; i++){
				document.getElementById("id_INM"+i).checked = false;
			}
			for( var i=1; i<=16; i++){
				document.getElementById("id_INA"+i).checked = false;
			}
		}
	}
	
	function show(id) {
		document.getElementById(id).style.display = "";
	}
	
	function hide(id) {
		document.getElementById(id).style.display = "none";
	}
	
	function changeVisible() {
		if (document.getElementById("interface").value == "TCP/IP") {
			show("bccport");
			hide("baudrate");
			hide("databits");
			hide("stopbits");
			hide("parity");
			if (document.getElementById("operationmode").value == "Cyclic") {
				show("cycletime");
				show("ipaddress");
				show("port");
				hide("bccport");
			} else {
				hide("cycletime");
				hide("ipaddress");
				hide("port");
				show("bccport");
			}
		} else {
			hide("bccport");
			show("baudrate");
			show("databits");
			show("stopbits");
			show("parity");
			hide("ipaddress");
			hide("port");
			if (document.getElementById("operationmode").value == "Cyclic") {
				show("cycletime");
			} else {
				hide("cycletime");
			}			
		}
	}
</script>
<?php
StyleTitle("BCC-Configuration Panel");

if (isset($_POST['chVers'])) {
	$xml = simplexml_load_file("/etc/spacecom/bcc.xml");
	
	$xml->appSettings->InterfaceSettings->attributes()->ActiveSystem = $_POST['version'];
	
	// Setting default data grouping [off]
	if(!isset($_POST['datagrouping']))
	{
		$xml->appSettings->InterfaceSettings->DataGrouping = 'Off';
	}
	
	// Setting default extended error codes [off]
	if(!isset($_POST['extendederrorcodes']))
	{
		$xml->appSettings->InterfaceSettings->ExtendedErrorCodes = 'Off';
	}
	
	$handle = fopen("/etc/spacecom/bcc.xml", "wb"); 
	fwrite($handle, $xml->asXML());
	fclose($handle);
}

if (isset($_POST['SaveSetts'])) {
	$xml = simplexml_load_file("/etc/spacecom/bcc.xml");
	$xml->appSettings->InterfaceSettings->Interface = $_POST['interface'];
	$xml->appSettings->InterfaceSettings->DataGrouping = $_POST['datagrouping'];
	$xml->appSettings->InterfaceSettings->ExtendedErrorCodes = $_POST['extendederrorcodes'];
	
	// Setting default data grouping [off]
	if(!isset($_POST['datagrouping']))
	{
		$xml->appSettings->InterfaceSettings->DataGrouping = 'Off';
	}
	
	// Setting default extended error codes [off]
	if(!isset($_POST['extendederrorcodes']))
	{
		$xml->appSettings->InterfaceSettings->ExtendedErrorCodes = 'Off';
	}
	
	$xml->appSettings->InterfaceSettings->Baudrate = $_POST['baudrate'];
	$xml->appSettings->InterfaceSettings->Stopbits = $_POST['stopbits'];
	$xml->appSettings->InterfaceSettings->Parity = $_POST['parity'];
	$xml->appSettings->InterfaceSettings->Databits = $_POST['databits'];
	$xml->appSettings->InterfaceSettings->Port = $_POST['bccport'];

	$handle = fopen("/etc/spacecom/bcc.xml", "wb"); 
	fwrite($handle, $xml->asXML());
	fclose($handle);

	$xml = simplexml_load_file("/etc/spacecom/".$_POST['file']);

	$xml->appSettings->BCCSettings->INSOLID = $_POST['insolid'];
	foreach ($xml->appSettings->BCCSettings->KEYS->KEY as $key) {
		$name = (array) $key;
		$name = $name['@attributes']['name'];
		if (isset($_POST[$name])) {
			if ($_POST[$name] == 'on') {
				$key->VISIBLE = 'Y';
			} else {
				$key->VISIBLE = 'N';
			}
		} else {
			$key->VISIBLE = 'N';
		}
	}
	

	if ($_POST['file'] == 'bcc_330.xml' || $_POST['file'] == 'bcc_phi_ibs_330.xml') {
		$xml->appSettings->SystemSettings->CharStuffing = $_POST['charstuff'];
		if(!preg_match("/^([0-9]+)$/", $_POST['cycletime']) || ($_POST['cycletime'] < 1) || ($_POST['cycletime'] > 300)) {
			$xml->appSettings->SystemSettings->CycleTime = 1;
			$_POST['CycletimeError'] = true;
		} else {
			$xml->appSettings->SystemSettings->CycleTime = $_POST['cycletime'];
		}
		$xml->appSettings->SystemSettings->IPAddress = $_POST['ipaddress'];
		$xml->appSettings->SystemSettings->Port = $_POST['port'];
		$xml->appSettings->SystemSettings->OperationMode = $_POST['operationmode'];
	}

	$handle = fopen("/etc/spacecom/".$_POST['file'], "wb"); 
	fwrite($handle, $xml->asXML());
	fclose($handle);

}

$xml = simplexml_load_file("/etc/spacecom/bcc.xml");
$version = (array) $xml->appSettings->InterfaceSettings;
$version = $version['@attributes']['ActiveSystem'];
if (GetBoard() == "spacecomlite") {
	$interface = "TCP/IP";
} else {
	$interface = $xml->appSettings->InterfaceSettings->Interface;
}
$datagrouping = $xml->appSettings->InterfaceSettings->DataGrouping;

// Setting default data grouping [off]
if($datagrouping == '')
{
	$datagrouping = 'Off';
}

$extendederrorcodes = $xml->appSettings->InterfaceSettings->ExtendedErrorCodes;

// Setting default extended error codes [off]
if($extendederrorcodes == '')
{
	$extendederrorcodes = 'Off';
}

$baudrate = $xml->appSettings->InterfaceSettings->Baudrate;
$stopbits = $xml->appSettings->InterfaceSettings->Stopbits;
$parity = $xml->appSettings->InterfaceSettings->Parity;
$databits = $xml->appSettings->InterfaceSettings->Databits;
$bccPort = $xml->appSettings->InterfaceSettings->Port;
echo"<div style='text-align:center'><h1></h1>\n";
echo "<form action='bccsetts.php' method='POST'>\n";
echo "<select name='version'>\n";
switch ($version) {
case 'BCC3.26':
	echo "<option selected value='BCC3.26'>BCC 3.26</option>\n".
		 "<option  value='PHI_IBS_BCC3.26'>PHI IBS BCC 3.26</option>\n".
		 "<option  value='Copra'>Copra</option>\n".
		 "<option  value='Qcare'>SpaceChart/Qcare</option>\n".
		 "<option  value='BCC3.35'>BCC 3.35</option>\n".
		 "<option  value='PHI_IBS_BCC3.35'>PHI IBS BCC 3.35</option>\n";
break;
case 'PHI_IBS_BCC3.26':
	echo "<option  value='BCC3.26'>BCC 3.26</option>\n".
		 "<option selected value='PHI_IBS_BCC3.26'>PHI IBS BCC 3.26</option>\n".
		 "<option  value='Copra'>Copra</option>\n".
		 "<option  value='Qcare'>SpaceChart/Qcare</option>\n".
		 "<option  value='BCC3.35'>BCC 3.35</option>\n".
		 "<option  value='PHI_IBS_BCC3.35'>PHI IBS BCC 3.35</option>\n";
break;
case 'Copra':
	echo "<option  value='BCC3.26'>BCC 3.26</option>\n".
		 "<option  value='PHI_IBS_BCC3.26'>PHI IBS BCC 3.26</option>\n".
		 "<option selected value='Copra'>Copra</option>\n".
		 "<option  value='Qcare'>SpaceChart/Qcare</option>\n".
		 "<option  value='BCC3.35'>BCC 3.35</option>\n".
		 "<option  value='PHI_IBS_BCC3.35'>PHI IBS BCC 3.35</option>\n";
break;
case 'Qcare':
	echo "<option  value='BCC3.26'>BCC 3.26</option>\n".
		 "<option  value='PHI_IBS_BCC3.26'>PHI IBS BCC 3.26</option>\n".
		 "<option  value='Copra'>Copra</option>\n".
		 "<option selected value='Qcare'>SpaceChart/Qcare</option>\n".
		 "<option  value='BCC3.35'>BCC 3.35</option>\n".
		 "<option  value='PHI_IBS_BCC3.35'>PHI IBS BCC 3.35</option>\n";
break;
case 'BCC3.35':
	echo "<option  value='BCC3.26'>BCC 3.26</option>\n".
		 "<option  value='PHI_IBS_BCC3.26'>PHI IBS BCC 3.26</option>\n".
		 "<option  value='Copra'>Copra</option>\n".
		 "<option  value='Qcare'>SpaceChart/Qcare</option>\n".
		 "<option selected value='BCC3.35'>BCC 3.35</option>\n".
		 "<option  value='PHI_IBS_BCC3.35'>PHI IBS BCC 3.35</option>\n";
break;
case 'PHI_IBS_BCC3.35':
	echo "<option  value='BCC3.26'>BCC 3.26</option>\n".
		 "<option  value='PHI_IBS_BCC3.26'>PHI IBS BCC 3.26</option>\n".
		 "<option  value='Copra'>Copra</option>\n".
		 "<option  value='Qcare'>SpaceChart/Qcare</option>\n".
		 "<option  value='BCC3.35'>BCC 3.35</option>\n".
		 "<option selected value='PHI_IBS_BCC3.35'>PHI IBS BCC 3.35</option>\n";
break;
}
echo "</select>";
echo "<input type='submit' name='chVers' value='Activate selected System'></form><br />\n";
$xml = simplexml_load_file("/etc/spacecom/bcc_sys.xml");
foreach($xml->appSettings->SystemSettings->Systems->System as $entry) {
	$entry = (array) $entry;
	if($entry['@attributes']['htmlvalue'] == $version) {
		$file = $entry['@attributes']['xmlfile'];
		break;
	}
}

echo "\n<form action method ='POST'>\n";

if (GetBoard() != "spacecomlite") {
	echo "<h3>Interface Settings</h3>\n";
	echo "<table style='text-align:center;display:inline;'>\n";
    echo "<tr><td>Interface</td><td><select name='interface' id='interface' onchange='changeVisible();'>\n";
    switch ($interface) {
    case 'TCP/IP':
		$visSerial = " style='display:none'";
		
        echo "<option value='TCP/IP' selected>TCP/IP</option>".
             "<option value='COM1'>COM1</option>\n";
        break;
    case 'COM1':
		$visSerial = "";

        echo "<option value='TCP/IP'>TCP/IP</option>".
             "<option value='COM1' selected>COM1</option>\n";
        break;
    }
    echo "</select></td></tr>\n";
	

	echo "<tr id='baudrate'".$visSerial."><td>Baudrate</td><td><select name='baudrate'>\n";
	switch ($baudrate) {
	case '9600':
		echo "<option selected>9600</option>\n".
			"<option>19200</option>\n".
			"<option>38400</option>\n".
			"<option>57600</option>\n";
	break;
	case '19200':
		echo "<option>9600</option>\n".
			"<option selected>19200</option>\n".
			"<option>38400</option>\n".
			"<option>57600</option>\n";
	break;
	case '38400':
		echo "<option>9600</option>\n".
			"<option>19200</option>\n".
			"<option selected>38400</option>\n".
			"<option>57600</option>\n";
	break;
	case '57600':
		echo "<option>9600</option>\n".
			"<option>19200</option>\n".
			"<option>38400</option>\n".
			"<option selected>57600</option>\n";
	break;
	}

	echo "</select></td></tr>\n";

	echo "<tr id='parity'".$visSerial."><td>Parity</td><td><select name='parity'>\n";
	switch ($parity) {
	case 'n':
		echo "<option selected>n</option>\n".
			"<option>o</option>\n".
			"<option>e</option>\n";
	break;
	case 'o':
		echo "<option>n</option>\n".
			"<option selected>o</option>\n".
			"<option>e</option>\n";
	break;
	case 'e':
		echo "<option>n</option>\n".
			"<option>o</option>\n".
			"<option selected>e</option>\n";
	break;
	}
	echo "</select></td></tr>\n";

	echo "<tr id='stopbits'".$visSerial."><td>Stopbits</td><td><select name='stopbits'>\n";
	switch ($stopbits) {
	case '1':
		echo "<option selected>1</option>\n".
			"<option>2</option>\n";
	break;
	case '2':
		echo "<option>1</option>\n".
			"<option selected>2</option>\n";
	break;
	}
	echo "</select></td></tr>\n";

	echo "<tr id='databits'".$visSerial."><td>Databits</td><td><select name='databits'>\n";
	switch ($databits) {
	case '7':
		echo "<option selected>7</option>\n".
			"<option>8</option>\n";
	break;
	case '8':
		echo "<option>7</option>\n".
			"<option selected>8</option>\n";
	break;
	}
	echo "</select></td></tr>\n";
	echo "</table><br />\n";
} else {
	echo "<input name='interface' id='interface' type='hidden' value='TCP/IP'>\n";
	echo "<input name='baudrate' id='baudrate' type='hidden' value='9600'>\n";
	echo "<input name='parity' id='parity' type='hidden' value='n'>\n";
	echo "<input name='stopbits' id='stopbits' type='hidden' value='1'>\n";
	echo "<input name='databits' id='databits' type='hidden' value='8'>\n";
}

echo "<h3>Parameter</h3>\n";
echo "<table border='1' style='display:inline'>\n".
     "<tr><th>Name</th><th>Visible</th><th>Name</th><th>Visible</th><th>Name</th><th>Visible</th><th>Name</th><th>Visible</th></tr>\n".
     "<input type='hidden' name='file' value='".$file."'>\n";
$xml = simplexml_load_file("/etc/spacecom/".$file);
$i = 0;
// echo "<pre>";var_dump($xml->appSettings->BCCSettings->KEYS->KEY);echo "</pre>";
foreach ($xml->appSettings->BCCSettings->KEYS->KEY as $key) {
	$key = (array) $key;
	if ($i == 4) {
		echo "</tr>\n<tr>";
		$i=0;
	}
	echo "<td>".$key['@attributes']['name']."</td>\n";
	if ( $key['@attributes']['name'] == 'ALARM1' || $key['@attributes']['name'] == 'ALARM2' || $key['@attributes']['name'] == 'STATUS1' || $key['@attributes']['name'] == 'STATUS2' || $key['@attributes']['name'] == 'PREALARM' ){
		$onclick = ' onclick="changeChecked(this.id);"';
	} else {
		$onclick = '';
	}
	if ($key['VISIBLE'] == 'Y') {
		echo "<td><input type='checkbox' id='id_".$key['@attributes']['name']."' name='".$key['@attributes']['name']."' checked".$onclick."></td>\n";
	} else {
		echo "<td><input type='checkbox' id='id_".$key['@attributes']['name']."' name='".$key['@attributes']['name']."'".$onclick."></td>\n";
	}
	$i++;
}
echo "</table><p><br /></p>\n";
echo "<table style='display:inline'>\n";
$insolid = $xml->appSettings->BCCSettings->INSOLID;


echo "<tr><td>INSOL</td><td><select name='insolid'>\n";

if ($insolid == '0x0A04') {
	echo "<option value='0x0A04' selected>Drugname</option>".
	     "<option value='0x0A05'>DrugID</option>\n"; 
} else {
	echo "<option value='0x0A04'>Drugname</option>".
	     "<option value='0x0A05' selected>DrugID</option>\n";
}
echo "</select></td></tr>\n";

echo "<tr><td>Data Grouping</td><td><select name='datagrouping'>\n";

if ($datagrouping == 'Off') {
	echo "<option selected>Off</option>".
			"<option>On</option>\n";
} else {
	echo "<option>Off</option>".
			"<option selected>On</option>\n";
}
echo "</select></td></tr>\n";

echo "<tr><td>Extended Error Codes</td><td><select name='extendederrorcodes'>\n";

if ($extendederrorcodes == 'Off') {
	echo "<option selected>Off</option>".
			"<option>On</option>\n";
} else {
	echo "<option>Off</option>".
			"<option selected>On</option>\n";
}
echo "</select></td></tr>\n";

function printBCC330($cyclic, $serial, $bccPort, $cycletime = "", $ipaddress = "", $port = "")
{
	if ($cyclic) {
		$visCyclic = "";
	} else {
		$visCyclic = " style='display:none'";
	}

	if ($cyclic && !$serial) {
		$visDoseTrac = "";
	} else {
		$visDoseTrac = " style='display:none'";
	}
	
	if (!$cyclic && !$serial) {
		$visBCCPort = "";
	} else {
		$visBCCPort = " style='display:none'";
	}

	echo "<tr id='cycletime'".$visCyclic."><td>Cycle time (sec.)</td><td>";
	if($_POST['CycletimeError'] == true) {
		echo "<span style='color:red'>Cycletime not in the range 1-300. Value was reset to default (1).</span><br />";
	}
	echo "<input type='text' name='cycletime' value='".$cycletime."'></td></tr>\n";
	echo "<tr id='ipaddress'".$visDoseTrac."><td>Dose Trac Server IP Address</td><td><input type='text' name='ipaddress' value='".$ipaddress."'></td></tr>\n";
	echo "<tr id='port'".$visDoseTrac."><td>Dose Trac Server Port</td><td><input type='text' name='port' value='".$port."'></td></tr>\n";
	echo "<tr id='bccport'".$visBCCPort."><td>BCC Port</td><td><input type='text' name='bccport' value='".$bccPort."'></td></tr>\n";
}

if (strpos($version, 'BCC3.3') !== false) {
	$charstuff = $xml->appSettings->SystemSettings->CharStuffing;
	$cycletime = $xml->appSettings->SystemSettings->CycleTime;
	$ipaddress = $xml->appSettings->SystemSettings->IPAddress;
	$port = $xml->appSettings->SystemSettings->Port;
	$operationmode = $xml->appSettings->SystemSettings->OperationMode;

	echo "<tr><td>Character Stuffing</td><td><select name='charstuff'>\n";
	if ($charstuff == 'On') {
		echo "<option selected>On</option>".
		     "<option>Off</option>\n";
	} else {
		echo "<option>On</option>".
		     "<option selected>Off</option>\n";
	}
	echo "</select></td></tr>\n";
	
	echo "<tr><td>Operation Mode</td><td><select name='operationmode' id='operationmode' onchange='changeVisible();'>\n";
	if ($operationmode == 'Cyclic') {
		echo "<option value='Cyclic' selected>Cyclic</option>".
		     "<option value='Request'>Request</option>\n";
	} else {
		echo "<option value='Cyclic'>Cyclic</option>".
		     "<option value='Request' selected>Request</option>\n";
	}
	echo "</select></td></tr>\n";
	
	printBCC330($operationmode == "Cyclic", $interface == "COM1", $bccPort, $cycletime, $ipaddress, $port);
} else {
	printBCC330(false, $interface == "COM1", $bccPort);
}

echo "</table><br />\n";
echo "<input type='submit' name='SaveSetts' value='Save'></form>\n";
echo "</div>";

?>
