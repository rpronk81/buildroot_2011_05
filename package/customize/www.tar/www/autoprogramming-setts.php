<?php
include 'common.inc.php';

VerifyConfigAuth();
StyleTitle("AutoProgramming Settings");


$xml = simplexml_load_file("/etc/spacecom/autoprogramming.xml");


if (isset($_POST['btn'])) {
   	$port = $_POST['port'];
	$xml[0]=$port;
	$handle = fopen("/etc/spacecom/autoprogramming.xml", "wb"); 
	fwrite($handle, $xml->asXML());
	fclose($handle);	
}

echo 	"<div id = 'autoprogramming'>".
	"<fieldset style='text-align:center'><legend>TCP Port</legend>".
		"<form method='POST' action=".$_SERVER['PHP_SELF'].">".
			"<input name='port' type='text' size='6' maxlength='6' value='{$xml[0]}'>".
				" Port<br />".
			"<input type='submit' name='btn' value=' OK '>".
		"</form>".
	"</fieldset></div>";	
?>
</body>
</html>
