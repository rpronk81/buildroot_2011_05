﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * Copyright (c) 2005,2006 des Obj.modells by B2A Corporate Marketing	*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-08, 2006-01																				*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 2.1.2																											*
 * Autor: B2A/Koe																											*
 * Letzte Bearbeitung: 2006-01-11 15:45																*
 * durch: Koe																													*
 **********************************************************************/

//***********************************************
//* Achtung:	/_js/dhtmlmenu/dhtmlmenu.supp.js	*
//*						muss zuerst includiert werden!		*
//***********************************************

// Zustandswerte für
// Menüebenen festlegen
var z,state=new Array();
		state.BASE=(z=0);		// 0000  0
		state.OPEN=(++z);		// 0001  1
		state.SLCT=(z*=2);	// 0010  2
		state.FILT=(z*=2);	// 0100  4
		state.LOCK=(z*=2);	// 1000  8
		delete z;

// --- Steuerfunktionen -------------------------------------------------------------------------------------------------------

function selectMenuItem( id, loadcont, doaction, hideSubmenus, fext ) {
// Menüebene zur
// Aktivierung auswählen

	var _id=eval( id );

	// Prüfen ob Flag zum Laden von Content übergeben
	if( typeof loadcont=='undefined' )
		loadcont=true;

	// Prüfen ob Flag zum Ausführen von Aktionen übergeben
	if( typeof doaction=='undefined' )
		doaction=true;

	// Prüfen ob Flag zur Verhinderung
	// der Submenüanzeige übergeben
	if( typeof hideSubmenus=='undefined' )
		hideSubmenus=false;

	// Prüfen ob Flag zur Verhinderung
	// der Submenüanzeige übergeben
	if( typeof fext=='undefined' )
		fext=null;

  var currstate=bin2dec( _id.state );

	if( (currstate & state.LOCK) == state.LOCK ) {
		if( !_id.quietLck )
			window.alert( msg[locale].ItemLocked );	// Gesperrte Menüebene
	} else {
		if( (currstate & state.FILT) == state.FILT )
			if( !_id.quietFlt )
				window.alert( msg[locale].ItemFiltered );	// Gefilterete Menüebene

 		// Ist evtl. eine spezielle Aktion
 		// für das Menüebenenobjekt definiert?
 		if( _id.action ) {
 			if( doaction )	// Falls nicht durch Flag verhindert ...
	  			eval( _id.action );	// ... diese ausführen
 		} else {
 			if( loadcont )	// ... ansonsten Flag zum Laden von Content prüfen ...
 				loadContentData( id, '', fext );	// ... und Content laden -- ggf. mit abweichender Dateiendung
 		}// if( eval( id ).action )

		// Angeklickte Menüebene aktivieren,
		// sofern diese noch nicht aktiv ist
		if( _id.parents[0].current ) {
			if( id != _id.parents[0].current.id )
				_id.activate( hideSubmenus );
		} else
			_id.activate( hideSubmenus );

	}// if( currstate & state.LOCK == state.LOCK )

	if( _id.parents[0].markerTmOut )
		window.clearTimeout( _id.parents[0].markerTmOut );

		// Nachbarschaftsmarkierung
	_id.markCoItems();

}// function selectMenuItem( id )

function getMenuText( id ) {
//Text einer Menüebene abfragen

	return eval( id ).getMenutext();
}	// function getMenuText( id )

function chgMenuText( id, text ) {
//Text einer Menüebene ändern

	var _id=eval( id ),
			prevtext = _id.getMenutext();

	if( text != prevtext )
		_id.setMenutext( text );

	return [_id.getMenutext(),prevtext];
}	// function chgMenuText( id, text )

function loadContentData( id, extra, fext, par ) {
// Standard: HTML-Datei für übergebene ID in
// contentFrame laden; `extra´ wird ggf. an die ID
// angehangen; `fext´ wird ggf. als alternative
// Dateiendung statt `.html´ verwendet

var contentFName;

	// Prüfen ob eine Id-Ergänzung für
	// den Dateinamen übergeben wurde
	// und diese ggf. anhängen
	if(!extra)
		extra='';
	id += extra;

	// Name des Templates für den Content-Dateinamen
	// durch die übergebene Id ersetzen
	contentFName = replacesubstr( contentURI,'init',id );

	// Prüfen ob eine abweichende Dateiendung
	// für den Dateinamen übergeben wurde
	if( fext && fext.charAt( 0 ) == '.' )
		contentFName = replacesubstr( contentFName,'.html',fext );

	// Prüfen ob ein URL-Parameter übergeben
	// wurde und diesen ggf. anhängen
	if(!par || par.charAt( 0 ) != '?')
		par='';
	contentFName += par;

	// URI aufrufen
	parent.contentFrame.location.href = contentFName;
}

function setFilter( id, quiet ) {
// Gezielt Filter einer Menüebene setzen

	var _id=eval( id );

	// Prüfen ob Quiet-Flag übergeben
	if( typeof quiet=='undefined' )
		quiet=false;

	_id.setFilter();
	_id.quietFlt=quiet;
}

function clearFilter( id ) {
// Gezielt Filter einer Menüebene aufheben
	eval( id ).clearFilter();
}

// --- Event-Handler ----------------------------------------------------------------------------------------------------------

function onmenuclick() {
// Führt Aktion(en) nach Mausklick
// auf eine Menüebene aus

	selectMenuItem( this.id );

}// function onmenuclick()

function onmouseovermenu() {
// Führt Aktion(en) aus, wenn
// Mauszeiger über eine Menüebene
// geführt wird

	var id=eval( this.id );

	// Nachbarschaftsmarkierung aktiviert?
	if( id.parents[0].coItemMarking[0] ) {

		// TimeOut ggf. zurück setzen
		if( id.parents[0].markerTmOut )
			window.clearTimeout( id.parents[0].markerTmOut );

		// Nachbarschaftsmarkierung
		id.markCoItems();
	}

	// Menütext in Statuszeile ausgeben
	window.status = stripTags( id.getMenutext() );
	return true;

}// function onmouseovermenu()

function onmouseoutmenu() {
// Führt Aktion(en) aus,
// wenn Mauszeiger
// eine Menüebene verlässt

	var _id=this.id,
			id=eval( _id );

	// Nachbarschaftsmarkierung aktiviert?
	if( id.parents[0].coItemMarking[0] ) {
		var	mouseOutAction = _id+'.parents[0].current.markCoItems';

		// TimeOut ggf. zurück setzen
		if( id.parents[0].markerTmOut )
			window.clearTimeout( id.parents[0].markerTmOut );

		// Nachbarn der momentan geöffneten
		// Menüebene zeitverzögert markieren
		mouseOutAction += id.parents[0].current.level>1?'( true )':'()';
		id.parents[0].markerTmOut = window.setTimeout( mouseOutAction,333 );
	}

}// function onmouseoutmenu()

// === Klassendefinitionen ==========================================================================================================

/***********************************
 * Konstruktur der Klasse menuItem *
 ***********************************/
function menuItem( I, L, T, S ) {

	// Eigenschaften
	this.action					= null;					// Definierte Aktion der Menüebene (JS-Code, der mit eval() ausgeführt wird)
	this.coItems				= new Array();	// Nachbar-Menüpunkte: 0 -> selbst, 1,3,5 -> oberhalb, 2,4,6 -> unterhalb
	this.coItemMarking	= [false];			// Steuerung der Nachbarschaftsmarkierung: [<ein|aus>,<Anz.Lv.1>,<Anz.Lv.2>,<Anz.Lv.3>,<...>] (nur in Lv. 0 verwendet)
	this.current				= null;					// Aktuell selektierte Menüebene (nur in Lv. 0 verwendet)
	this.id							= I;						// Id der Menüebene
	this.items					= null;					// Submenüebenen-Objekte
	this.lastlevel			= null;					// Tiefster Level der Menüebenen (nur in Lv. 0 verwendet)
	this.level					= L;						// Level der Menüebene
	this.markerTmOut		= null;					// TimeOut-Objekt für den CoItemMarker
	this.parents				= new Array();	// Ahnenreihe der Menüebene
	this.quietFlt				= false;				// Anklicken einer gefilterten Menüebene melden oder nicht
	this.quietLck	 			= false;				// Anklicken einer gesperrten Menüebene melden oder nicht
	this.state					= S;						// Zustandsmaske der Menüebene (Binärzahl als String)
	this.text						= T;						// Menütext

}// function menuItem( I, L, T, S )

// Prototypobjekt sicherstellen
new menuItem();

/*************************
 * Methoden für menuItem *
 *************************/

menuItem.prototype.build = function() {
// Generiert das Menü und
// initialisiert einige
// Eigenschaften

var i;

	switch( this.level ) {

		case 0:	// Äußere Hülle des Menüs erzeugen
			outStr( '<div id="mnumain" xml:lang="'+locale+'" lang="'+locale+'" dir="'+dir+'">' );

			// Falls vorhanden,
			// Submenüebene 1 anlegen
			if( this.items )
				for( i in this.items ) {
  				this.items[i].parents.push( this );	// Ahnenlinie beginnen
					this.items[i].build();	// Submenüebene generieren
				}

			// Äußere Hülle des Menüs abschließen
			outStr( '<\/div>' );

			break;

		default: // Submenüebene erzeugen
			outStr( '<div id="'+this.id+'" class="mnuitm-l'+this.level+'-s'+this.state+'" title="'+stripTags( this.text )+'"><div class="mnuvspc"><\/div>'+this.text+'<\/div>' );

			// Falls tiefster Level erreicht ...
			if( this.level == this.parents[0].lastlevel )
				break;	// ... ist Schluss ...
			else if( this.items ) { // ... sonst: Submenüebenen vorhanden?
      	outStr( '<div id="s'+this.id+'" class="mnusub">' );

				// Submenüebenen 2 (bzw. 3) anlegen
  			for( i in this.items ) {
  				this.items[i].parents=this.items[i].parents.concat( this.parents, this );	// Ahnenlinie fortsetzen
  				this.items[i].build();	// Submenüebene generieren
  			}

				// Abschluss für tiefste Submenüebenen
				if( this.level == this.parents[0].lastlevel-1 )
					document.write( '<div class="mnuitm-boundary"><img src="\/images\/trans.gif" alt="" height="1" width="1" border="0" \/><\/div>' );

				// Camouflage-Hülle der Submenüs abschließen
				outStr( '<\/div>' );
			}
			break;
	} //switch( this.level )

	// Jeder Menüebene ab Level 1
	// die Event-Handler zuweisen
	if( this.level ) {
		var elm=document.getElementById( this.id );
		elm.onclick=onmenuclick;
		elm.onmouseover=onmouseovermenu;
		elm.onmouseout=onmouseoutmenu;
  }
}//menuItem.prototype.build

menuItem.prototype.setState = function( s, preserve ) {
// Zustandsmaske des Menüebenenobjekts
// setzen und Zustand im Menü darstellen

	// Aktuellen Zustand
	// als Dezimalzahl ermitteln
  var currstate = bin2dec( this.state ),
			newstate = currstate;

  if( preserve ) {	// Einzelnen Zustand ...
  	if( s>=0 )
  		newstate |= s;	// ... setzen
  	else
  		newstate &= (s+state.OPEN+state.SLCT+state.FILT+state.LOCK);	// ... löschen
  } else
  	newstate = s;	// Neue Zustandsmaske komplett übernehmen

	// Nur erlaubte Zustände zulassen
	switch( newstate ) {
		case state.BASE:
		case state.OPEN:
		case state.OPEN+state.SLCT:
		case state.FILT:
		case state.OPEN+state.FILT:
		case state.OPEN+state.SLCT+state.FILT:
		case state.LOCK:
		  // Neue Zustandsmaske setzen
    	// und im Menü darstellen
  		this.state = dec2bin( newstate, 4 );
		  this.chgState();
  		break;
  }// switch( newstate )
}// menuItem.prototype.setState

menuItem.prototype.chgState = function() {
// Zustand im Menü darstellen

	var elm=document.getElementById( this.id );

	if( this.level )
		elm.className = 'mnuitm-l'+this.level+'-s'+this.state;

}// menuItem.prototype.chgState

menuItem.prototype.showSubmenu = function() {

	// Zustand der Menüebene ist "offen"
	this.setState( state.OPEN, true );

	if( this.level ) {
		if( isBrowser.moz )
			document.getElementById( 'mnucoat' ).style.display = 'none';	// Gecko: äußere Hülle verbergen
		document.getElementById( 's'+this.id ).style.display = 'block';
		if( isBrowser.moz )
			document.getElementById( 'mnucoat' ).style.display = null;		// Gecko: äußere Hülle wieder zeigen
 	}
}//menuItem.prototype.showSubmenu

menuItem.prototype.hideSubmenu = function() {

	// Zustand der Menüebene ist
	// "nicht ausgewählt" und "nicht offen"
	this.setState( -state.SLCT-state.OPEN, true );

	if( this.level ) {
		if( isBrowser.moz )
			document.getElementById( 'mnucoat' ).style.display = 'none';	// Gecko: äußere Hülle verbergen
		document.getElementById( 's'+this.id ).style.display = 'none';
		if( isBrowser.moz )
			document.getElementById( 'mnucoat' ).style.display = null;		// Gecko: äußere Hülle wieder zeigen
 	}// if( this.level )
}// menuItem.prototype.hideSubmenu

menuItem.prototype.showAll = function( m ) {

	if( this.id==m ) 	// Übergebene Ebene ...
		this.setState( state.OPEN+state.SLCT,true );	// ... aktivieren
	else
		this.setState( -state.OPEN-state.SLCT,true );	// ... andere deaktivieren

	// Falls Submenüebenen vorhanden ...
	if( this.items ) {
		// ... diese rekursiv
		// durchlaufen und abarbeiten
		for( var i in this.items )
			this.items[i].showAll( m );

		// Submenüebene(n) anzeigen
		this.showSubmenu();

	}//if( this.items )

}//menuItem.prototype.showAll

menuItem.prototype.hideAll = function( m ) {

	if( this.id==m ) 	// Übergebene Ebene ...
		this.setState( state.OPEN+state.SLCT, true );	// ... aktivieren
	else
		this.setState( -state.OPEN-state.SLCT, true );	// ... andere deaktivieren

	// Falls Submenüebenen vorhanden ...
	if( this.items ) {

		// ... diese rekursiv
		// durchlaufen und abarbeiten
		for( var i in this.items )
			this.items[i].hideAll( m );

		// Submenüebene(n) verbergen
		this.hideSubmenu();

	}//if( this.items )

}//menuItem.prototype.hideAll

menuItem.prototype.activate = function( hideSubmenus ) {
  var i=null;

	// Prüfen ob Flag zur Verhinderung
	// der Submenüanzeige übergeben
	if( typeof hideSubmenus == 'undefined' )
		hideSubmenus=false;

	// Derzeit geöffneten Submenübaum des bislang
	// selektierten Menüs von der ersten Ebene an
	// abwärts schließen
	if( this.parents[0].current ) {
		this.parents[0].current.hideAll();
		for( i in this.parents[0].current.parents )
			if( i>0 )
				if( this.parents[0].current.parents[i].items )
					this.parents[0].current.parents[i].hideSubmenu();
	}

	// Von der ersten Ebene abwärts ggf.
	// alle Submenüebenen bis zur neu
	// selektierten Ebene öffnen
	for( i in this.parents )
		if( i>0 )
			if( this.parents[i].items )
				this.parents[i].showSubmenu();

	// Ggf. Submenü der neuen
	// aktiven Ebene öffnen
	if( this.items && !hideSubmenus )
		this.showSubmenu();

	// Zustand der neuen Ebene
	// auf "offen" und "selektiert" setzen
	this.setState( state.OPEN+state.SLCT, true );

	// Neue aktive Ebene dokumentieren
	this.parents[0].current = this;

}// menuItem.prototype.activate

menuItem.prototype.setLock = function( m ) {

	var currstate=bin2dec( eval( this.id ).state );

	if( (currstate & state.LOCK) != state.LOCK ) {

		if( (this.parents[0].current == this) || (m == this.id))
			window.alert( msg[locale].ItemNotLockable );
		else {

			if( m ) {
				// Angegebene Ebene aktivieren
				eval( m ).activate();

				// Diese Ebene sperren
				this.setState( state.LOCK, false );

			} else {

				// Ggf. Submenü der zu
				// sperrenden Ebene schließen ...
				if( this.items )
					this.hideAll();

				// ... und Ebene sperren
				this.setState( state.LOCK, false );

			}// if( m )
	  }// if( (this.parents[0].current == this) || (m == this.id))
	}// if( (currstate & state.LOCK) != state.LOCK )
}// menuItem.prototype.setLock

menuItem.prototype.clearLock = function() {

	var currstate=bin2dec( eval( this.id ).state );

	if( (currstate & state.LOCK) == state.LOCK )
		// Diese Ebene entsperren
		this.setState( -state.LOCK, true );

}// menuItem.prototype.clearLock

menuItem.prototype.setFilter = function() {

	var currstate=bin2dec( eval( this.id ).state );

	if( (currstate & state.LOCK) != state.LOCK ) {
		if( (currstate & state.FILT) != state.FILT )
			// Diese Ebene filtern
			this.setState( state.FILT, true );
	} else
		window.alert( msg[locale].NoFilterOnLockedItem );

}// menuItem.prototype.setFilter

menuItem.prototype.clearFilter = function() {

	var currstate=bin2dec( eval( this.id ).state );

	if( (currstate & state.FILT) == state.FILT )
		// Filter für diese Ebene aufheben
		this.setState( -state.FILT, true );

}// menuItem.prototype.clearFilter

menuItem.prototype.markCoItems = function() {
// Benachbarte Menüpunkte
// farbig hervorheben

	// Nachbarschaftsmarkierung eingeschaltet?
	// Level ab 1?
	if( this.parents[0].coItemMarking[0] && this.level ) {

		var i,elm,
				noRefreshLo,
				CoItemCount = 0;

		// Anzahl der Nachbarn im gegebenen Level ermitteln
		if( typeof (this.parents[0].coItemMarking[this.level]) != 'undefined' )
			CoItemCount = this.parents[0].coItemMarking[this.level];
		else
			this.parents[0].coItemMarking[this.level] = CoItemCount;

		// Markierung ohne DimmRefresh?
		if( arguments.length ) {
			if( typeof arguments[0] == 'boolean' )
				noRefreshLo = arguments[0];
		} else
			noRefreshLo = ( CoItemCount < 0 );

		// Vorzeichen aufgeben
		CoItemCount = Math.abs( CoItemCount );

		// Maximale Anzahl der Nachbarn: 3
		if( CoItemCount > 3 )
			CoItemCount = 3;

		// Erstmalig Nachbar-Menüebenen ermitteln
		if( !this.coItems.length ) {
			var allItemsOfLevel = this.parents[this.parents.length-1].items;

			for( i in allItemsOfLevel )
				if( allItemsOfLevel[i].id == this.id )
					break;
			i*=1;	// TypeCasting!

			// Nachbarn gemäß Anzahl ermitteln
			this.coItems[0]=this.id;
			if( CoItemCount ) {
				this.coItems[1]=(i>=1?allItemsOfLevel[i-1].id:null);
				this.coItems[2]=(i<=allItemsOfLevel.length-2?allItemsOfLevel[i+1].id:null);
				if( CoItemCount > 1 ) {
					this.coItems[3]=(i>=2?allItemsOfLevel[i-2].id:null);
					this.coItems[4]=(i<=allItemsOfLevel.length-3?allItemsOfLevel[i+2].id:null);
					if( CoItemCount > 2 ) {
						this.coItems[5]=(i>=3?allItemsOfLevel[i-3].id:null);
						this.coItems[6]=(i<=allItemsOfLevel.length-4?allItemsOfLevel[i+3].id:null);
					}
				}
			}	// if( CoItemCount )
		}	// if( !this.coItems.length )

		// Menüdarstellung zurück setzen (mit|ohne Dimmen)
		this.parents[0].refresh( !noRefreshLo );

		// Nachbar-Menüebenen umfärben
		// (sofern nicht geblockt oder gefiltert)
		for( i in this.coItems )
			if( this.coItems[i] && !(((bin2dec( this.coItems[i].state ) & state.LOCK) == state.LOCK)||((bin2dec( this.coItems[i].state ) & state.FILT) == state.FILT)) ) {
				elm = document.getElementById( this.coItems[i] );
				elm.className = elm.className.replace( /mnuitm-lo/,'');
				elm.className += ' mnuitm-hi-'+CoItemCount+'-'+(i==0?'0':i<3?'1':i<5?'2':'3');
			}

	}	//	if( this.parents[0].coItemMarking[0] )
}	//menuItem.prototype.markCoItems

menuItem.prototype.refresh = function( lo ) {
// Zustandsdarstellung der Menüebene
// und ggf. ihrer Subebenen auffrischen

	var elm=document.getElementById( this.id );

	// Ab Level 1 ...
	if( this.level ) {
		this.chgState();	// Korrekten Zustand darstellen ...
		// ... und ggf. dimmen, falls
		// nicht geblockt oder gefiltert
		if( lo && !(((bin2dec( this.state ) & state.LOCK) == state.LOCK)||((bin2dec( this.state ) & state.FILT) == state.FILT)) )
			elm.className += ' mnuitm-lo';
	}

	// Falls Subebenen vorhanden ...
	if( this.items )
		// ... auch diese rekursiv
		// durchlaufen und auffrischen
		for( var i in this.items )
			this.items[i].refresh( lo );

}//menuItem.prototype.refresh

menuItem.prototype.getId = function() {
	return this.id;
}// menuItem.prototype.getId

menuItem.prototype.setMenutext = function( t ) {
// Menütext ändern

	var elm = document.getElementById( this.id );

	if( typeof t == 'string' ) {
		this.text = t;

		// Menü und title-Attribut aktualisieren
		elm.innerHTML=this.text;
		elm.title=stripTags( this.text );
	}
}// menuItem.prototype.setMenutext

menuItem.prototype.getMenutext = function() {
	return this.text;
}// menuItem.prototype.getMenutext

menuItem.prototype.toString = function() {
	return this.id + ': ' + this.getMenutext();
}// menuItem.prototype.toString

// === Ende der Klassendefinitionen ===============================================================================================
