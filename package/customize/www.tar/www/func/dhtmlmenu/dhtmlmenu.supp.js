﻿/****************************************************************
 * Javascript-Hilfsfunktionen																		*
 * Copyright (c) 2004,2005 by B2A Corporate Marketing						*
 * All rights reserved																					*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2004-07, 2005-07																	*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * *** Die Verwendung ist gestattet ***													*
 * Version: n/a																									*
 * Autor: B2A/koe																								*
 * Letzte Bearbeitung: 2006-02-02 09:44													*
 * durch: Koe																										*
 ****************************************************************/

function countChar( c, s ) {
// Zählt in einem String 's'
// das Vorkommen des Zeichens 'c'
	for( var i=0,n=0;i<s.length;i++ )
		void( s.charAt( i )==c?n++:0 );
	return n;
}

function bin2dec( b ) {
// Wandelt eine Binärzahl (String
// oder Zahl) in eine Dezimalzahl um

	var d=0;
	b=String( b );

	if( b )
		for( var n=1,i=b.length-1;i>=0;i-- ) {
			d+=b.charAt( i )=='1'?n:0;
			n*=2;
		}

	return d;
}

function dec2bin( d, dig ) {
// Wandelt eine Dezimalganzzahl in
// eine Binärdarstellung (String) um,
// die optional eine Mindestanzahl von
// Stellen aufweist.

	var b=d.toString( 2 );

	if( dig )
		for( var i=b.length;i<dig;i++ )
			b='0'+b;

	return b;
}

function leadingZero( num, dig ) {
// Versieht eine Zahl angegebener
// Stellenzahl mit führenden Nullen

	if( typeof dig != 'number' )
		dig = 2;

	return num2str( num, null, dig );
}

function num2str( num, dec, dig, decchar ) {
	// Formatiert eine übergebene Zahl
	// als String gemäß der Parameter:
	//	dig:			Vordezimalstellen
	//	dec:			Dezimalstellen
	//	decchar:	Dezimalzeichen

	if(typeof num=='number') {
		var neg=num<0;
		if(typeof dec=='number') {
			num=String( parseFloat( Math.round( Math.abs( num )*Math.pow( 10,dec ))/Math.pow( 10,dec )));
			if(dec&&num.indexOf( '.' )==-1)
				num+='.';
			var l=dec-(num.substring( num.indexOf( '.' ),num.length )).length;
			for(var d=0;d<=l;d++)
				num+='0';
			if(typeof decchar=='string') {
				num=num.replace( /\./,decchar );
			}
		}
		if(typeof dig=='number') {
			if(dig=dig<0?1:dig) {
				var l=num.indexOf( decchar )>-1?(num.substring( 0,num.indexOf( decchar ))).length:num.length;
				for(var i=l;i<dig;i++)
					num='0'+num;
			}
		}
		if(neg)
			num='-'+num;
	}
	return num;
}	//function num2str( num, dec, dig, decchar )

function replacesubstr( str,source,target ) {
	return( str.split( source ).join( target ) );
}

function stripTags( str ) {
	return str.replace( /<br \/>/g,' ' ).replace( /&nbsp;/g,' ' ).replace( /&ndash;/g,'—' ).replace( /&shy;/g,'' ).replace( /<sub>/g,'' ).replace( /<\/sub>/g,'' ).replace( /<sup>/g,'' ).replace( /<\/sup>/g,'' ).replace( /<strong>/g,'' ).replace( /<\/strong>/g,'' ).replace( /<em>/g,'' ).replace( /<\/em>/g,'' );
}

function outStr( str, elmid ){
// Gibt einen String aus

	if( typeof elmid == 'string' )
		document.getElementById( elmid ).innerHTML = str;
	else
		document.write( str );
}	//function outStr()


/**********************************************************************************
   DynAPI Distribution
   Browser Class

   The DynAPI Distribution is distributed under the terms of the GNU LGPL license.

   Additions by RJKoester 2003-07-04

***********************************************************************************/
function Browser() {
	var an=navigator.appName.toLowerCase();
	var ua=navigator.userAgent.toLowerCase();

	if((an.indexOf('netscape')>-1) && (ua.indexOf("mozilla")>-1) && (ua.indexOf("compatible")==-1) && (ua.indexOf("gecko")>-1))
		this.b="moz";
	else if(an.indexOf('netscape')>-1)
		this.b="ns";
	else if((an=="opera") || (ua.indexOf("opera")>-1))
		this.b="opera";
	else if(an=="microsoft internet explorer")
		this.b="ie";
	if(!an)
		alert('Unidentified user agent.\nthis.browser is not supported!');

	this.version=navigator.appVersion.toLowerCase();
	this.v=parseInt(this.version);
	this.ns=(this.b=="ns" && this.v>=4);
	this.ns3=(this.b=="ns" && this.v<4);
	this.ns4=(this.b=="ns" && this.v==4);
	this.ns6=(this.b=="ns" && this.v==5);
	this.mz=this.moz=(this.b=="moz");
	this.mz100=(this.b=="moz" && (ua.indexOf("rv:1.0.0")>-1 || ua.indexOf("gecko/200205")>-1 || ua.indexOf("gecko/200206")>-1));
	this.mz110=(this.b=="moz" && (ua.indexOf("rv:1.1")>-1 || ua.indexOf("gecko/200208")>-1));
	this.mz140=(this.b=="moz" && (ua.indexOf("rv:1.4")>-1 || ua.indexOf("Gecko/200306")>-1));
	this.mz1=(this.mz100 || this.mz110 || this.mz140);
	this.ie=(this.b=="ie" && this.v>=4);
	this.ie4=(this.version.indexOf('msie 4')>0);
	this.ie5=(this.version.indexOf('msie 5')>0);
	this.ie55=(this.version.indexOf('msie 5.5')>0);
	this.ie6=(this.version.indexOf('msie 6.0')>0);
	this.op=this.opera=(this.b=="opera");
	this.op4=(ua.indexOf("opera 4")>-1)||(ua.indexOf("opera/4")>-1);
	this.op5=(ua.indexOf("opera 5")>-1)||(ua.indexOf("opera/5")>-1);
	this.op6=(ua.indexOf("opera 6")>-1)||(ua.indexOf("opera/6")>-1);
	this.dom=(document.createElement && document.appendChild && document.getElementsByTagName && document.getElementsByName)?true:false;
	this.def=(this.ie||this.dom); // most used browsers, for faster if loops
	this.out=(!an||this.op4||this.ns4);

	if (ua.indexOf("win")>-1)
		this.platform="win32";
	else if (ua.indexOf("mac")>-1)
		this.platform="mac";
	else if (ua.indexOf("linux")>-1)
		this.platform="lnx";
	else if (ua.indexOf("os/2")>-1)
		this.platform="os2";
	else
		this.platform="other";
}
var isBrowser=new Browser();

