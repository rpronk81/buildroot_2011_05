﻿/****************************************************************
 * JavaScript-Funktionen für Projekt														*
 * SpaceOnline BBraun.com																				*
 * Copyright (c) 2003,2006 des Menü-Layouts by BBMAG						*
 * Copyright (c) 2004,2006 des Codes by B2A Corporate Marketing	*
 * All rights reserved																					*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2004, 2005-03, 05..08														*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * Version: -																										*
 * Autor: B2A/Koe																								*
 * Letzte Bearbeitung: 2006-07-27 08:26													*
 * durch: Koe																										*
 ****************************************************************/

function selectMenuItem( m,c,a,h,e ) {
// Auswahl der Menüebene 1:1
// an Menü-Funktion weiterreichen
	parent.menuFrame.selectMenuItem( m,c,a,h,e );
}

function chgMenuText( m,t ) {
// Änderung des Menütextes 1:1
// an Menü-Funktion weiterreichen
	return parent.menuFrame.chgMenuText( m,t );
}

function getMenuText( m ) {
// Änderung des Menütextes 1:1
// an Menü-Funktion weiterreichen
	return parent.menuFrame.getMenuText( m );
}

function setFilter( m,q ) {
// Setzen des Filters 1:1
// an Menü-Funktion weiterreichen
	return parent.menuFrame.setFilter( m,q );
}

function clearFilter( m ) {
// Aufheben des Filters 1:1
// an Menü-Funktion weiterreichen
	return parent.menuFrame.clearFilter( m );
}

function hiliteTopic( t, ts, tSrc ) {
// Aktiven Listenpunkt
// optisch hervorheben

	if( t ) {
		for( var e in ts )
			if( document.getElementById )
				document.getElementById( ts[e] ).src=tSrc.lo;
			else if( document.all )
				document.all[ts[e]].src=tSrc.lo;

		if( document.getElementById )
			document.getElementById( t ).src=tSrc.hi;
		else if( document.all )
			document.all[t].src=tSrc.hi;
	}

}//function hiliteTopic( t, ts, tSrc )

function chgImg( imgid, imgsrc ) {

	if( imgsrc ) {
		if( document.getElementById )
			document.getElementById( imgid ).src=imgsrc;
		else if( document.all )
			document.all[imgid].src=imgsrc;
	} //if( imgsrc )
} //function chgImg( imgid, imgsrc )

function toggleMenuFilter() {
// Schaltet die Filterfunktion
// für identische Trainingskapitel um

	for( var m=0;m<MenuFilter.chapters.length;m++ )
		if(MenuFilter.enabled)
			clearFilter( MenuFilter.chapters[m] );
		else
			setFilter( MenuFilter.chapters[m],true );

	MenuFilter.enabled=!MenuFilter.enabled;
	chgImg( "chkbox",MenuFilter.enabled?chkboxsrc[1]:chkboxsrc[0] );
}	//function toggleMenuFilter()


///////////////////////////////
// Algemeine Hilfsfunktionen //
///////////////////////////////

function ObjPrint( msg,obj,useCookie ) {
//Ruft nach Typprüfung und Benutzerbestätigung
//die Druck-Methode eines Objekts auf
var flag=useCookie && GetCookie( 'scom_printwarn' )=='nowarn';

	if( typeof obj != "object" )
		obj = window;

	if(!flag) {
		flag=obj.confirm( msg );
		SetCookie( 'scom_printwarn','nowarn',null,'/' );	// Flag-Sessioncookie setzen
	}

	if(flag)
		obj.print();
}	//function ObjPrint()

function outStr( str, elmid ){
	if( typeof elmid == 'string' ) {
		if( document.getElementById( elmid ))
			document.getElementById( elmid ).innerHTML = str;
	} else
		document.write( str );
}	//function outStr()

function pushData( id,dta,attr ) {
// Schiebt Daten in ein bestimmtes Elementattribut
//
// Parameter:
//	id:			Id des Elements
//	dta:		zu schiebende Daten
//	attr:		Tag-Attribut des Elements
//					(Default: 'innerHTML')

	var elem = document.getElementById( id );

	if( elem ) {
		attr = typeof attr != 'string' ? 'innerHTML' : attr;

		if( elem[attr] ) {
			elem[attr] = dta;
		}
		else {
			elem.innerHTML = dta;
		}
	}
}	// function pushData()

function stripSpace( s ) {
//--------------------------------------------------
// Funktion trennt von einem String
// ggf. anhängende Leerzeichen ab
//
// Übergabe:
//  s:	String
//
// Rückgabe:
//  s:	String ohne anhängende Leerzeichen
//--------------------------------------------------

	while(s.length&&' '.indexOf( s.substr( -1,1 ))+1)
		s = s.substr(0,s.length-1);
	return s;
}

function cutStr( str,len ) {
var i,hellip='…',
		s='',p=str.split( ' ' );

	for( i=0;i<p.length;i++ ) {
		if( p[i].length>=len )
			p[i]=p[i].substr( 0,len-2 )+hellip;
		s+=p[i]+' ';
	}
	return stripSpace( s );
}


function chgBgCol( id, color ) {
/************************************************************/
/* Austausch der Hintergrundfarbe eines Tabellenfelds <td>, */
/* welches mit einer Id versehen wurde.                     */
/* koester@b2a.de, 2003-03-27                               */
/*                                                          */
/* Parameter:                                               */
/*   id [string] - Id des Tabellenfelds                     */
/*   color [string]- Gewünschter Farbname oder -wert des    */
/*                   Tabellenfelds.                         */
/*                                                          */
/* Rückgabe:                                                */
/*   -keine-                                                */
/************************************************************/
  if( document.getElementById )
    document.getElementById( id ).style.backgroundColor=color;
  else if( document.all )  // MSIE ab 4.x
    document.all[id].style.backgroundColor=color;
}

function setCSSClass( e,c ) {
// CSS-Klasse eines
// beliebigen Elements setzen
	if( document.getElementById )
		document.getElementById( e ).className = c;
	else if( document.all )
		document.all[e].className = c;
}

function replacesubstr( str,source,target ) {
	return str.split( source ).join( target );
}

function stripTags( str ) {
	return str.replace( /<br \/>/g,' ' ).replace( /&nbsp;/g,' ' ).replace( /&ndash;/g,'—' ).replace( /&shy;/g,'' ).replace( /<sub>/g,'' ).replace( /<\/sub>/g,'' ).replace( /<sup>/g,'' ).replace( /<\/sup>/g,'' ).replace( /<strong>/g,'' ).replace( /<\/strong>/g,'' ).replace( /<em>/g,'' ).replace( /<\/em>/g,'' );
}

function chgvis( elmid,vis ) {
/***************************************************
 * Funktion zeigt oder versteckt ein Element durch *
 * Verändern des Styles Visibility                 *
 *-------------------------------------------------*
 * Aufrufparameter:                                *
 *  elmid					- Id des Elements                *
 *  boolean                                        *
 *  vis						- zeigen oder verstecken         *
 *         					[false,true|0,1]               *
 *-------------------------------------------------*
 * Option:                                         *
 *   Fehlt `vis´, so wird die Sichtbarkeit         *
 *   umgeschaltet.                                 *
 * Rückgabe:                                       *
 *  <keine>                                        *
 ***************************************************/
  switch( vis ) {
    case 0:
    case false:
      vis = "hidden";
      break;
    case 1:
    case true:
      vis = "visible";
      break;
    default:
      var v;
      if(document.getElementById)
        v=document.getElementById( elmid ).style.visibility;
      else if(document.all)
        v=document.all[id].style.visibility;

      if(v=="hidden")
      	vis = "visible";
      else
      	vis = "hidden";
      break;
  }

  if(document.getElementById)
    document.getElementById( elmid ).style.visibility = vis;
  else if(document.all)
    document.all[id].style.visibility = vis;
} //function chgvis( elmid,vis )

function chgdisplay( id,vis,elmtype ) {
/***************************************************
 * Funktion zeigt oder versteckt ein Element durch *
 * Verändern des Styles Display                    *
 *-------------------------------------------------*
 * Aufrufparameter:                                *
 *  id						- Id des Elements                *
 *  boolean                                        *
 *  showhide			- zeigen oder verstecken         *
 *         					[false,true|0,1]               *
 *-------------------------------------------------*
 * Rückgabe:                                       *
 *  <keine>                                        *
 ***************************************************/
  switch( vis ) {
  	case 0:
    case false:
      if(document.getElementById)
        document.getElementById( id ).style.display='none';
      else if(document.all)
        document.all[id].style.display='none';
    	break;
    case 1:
    case true:
    default:
    	switch(elmtype) {
    		case 'div':
    		case 'block':
    			elmtype='block';
    			break;
    		case 'span':
    		case 'inline':
    			elmtype='inline';
    			break;
    		case 'td':
    		case 'table-cell':
    			elmtype='table-cell';
    			break;
    		case 'tr':
    		case 'table-row':
    			elmtype='table-row';
    			break;
    		case 'table':
    			elmtype='table';
    			break;
    	}
      if(document.getElementById)
        document.getElementById( id ).style.display=elmtype;
      else if(document.all)
        document.all[id].style.display='block';
      break;
  }
}// chgdisplay()

function leadingZero( num, dig ) {
// Versieht eine Zahl angegebener
// Stellenzahl mit führenden Nullen

	if( typeof dig != 'number' )
		dig = 2;

	return num2str( num, null, dig );
}

function num2str( num, dec, dig, decchar ) {
	// Formatiert eine übergebene Zahl
	// als String gemäß der Parameter:
	//	dig:			Vordezimalstellen
	//	dec:			Dezimalstellen
	//	decchar:	Dezimalzeichen

	if(typeof num=='number') {
		var neg=num<0;
		if(typeof dec=='number')
			dec=Math.abs( dec );
		else
			dec=0;
		num=String( parseFloat( Math.round( Math.abs( num )*Math.pow( 10,dec ) )/Math.pow( 10,dec ) ));
		if(dec&&num.indexOf( '.' )==-1)
			num+='.';
		var l=dec-(num.substring( num.indexOf( '.' ),num.length )).length;
		for(var d=0;d<=l;d++)
			num+='0';
		if(typeof decchar!='string')
			decchar='.';
		if(decchar!='.')
			num=num.replace( /\./,decchar );

		if(typeof dig=='number') {
			if(dig=dig<0?1:dig) {
				var l=num.indexOf( decchar )>-1?(num.substring( 0,num.indexOf( decchar ))).length:num.length;
				for(var i=l;i<dig;i++)
					num='0'+num;
			}
		}
		if(neg)
			num='-'+num;
	}
	return num;
}	//function num2str( num, dec, dig, decchar )

function calcTime( t ) {
// Gibt eine dezimale Stundenangabe
// als String der Form `hh:mm´ zurück
	if( t ) {
		return num2str( Math.floor( t ),0,2 )+':'+num2str( Math.round( (t-Math.floor( t ))*60.0 ),0,2 );
	}	else
		return '00:00';
}

function getDt( fmt ) {
//-------------------------------------------------
// Gibt Tagesdatum in einstellbarem Format zurück:
// 		'de'			= 'TT.MM.JJJJ',
//		'en'			= 'MM/DD/YYYY',
//		'ISO8601'	= 'JJJJ-MM-TT' (Standard)
//-------------------------------------------------
	var dt=new Date(),t,m,j;

	t=dt.getDate();
	t=(t<10?"0"+t:t);
	m=dt.getMonth() + 1;
	m=(m<10?"0"+m:m);
	j=dt.getYear();
	j=(j<1900?j+1900:j);

	if( typeof fmt=='undefined' )
		fmt='iso8601';

	switch( fmt.toLowerCase()) {
		case "de":
		case "tt.mm.jjjj":
		case "dd.mm.yyyy":
			return( t+'.'+m+'.'+j );
			break;
		case "en":
		case "mm/tt/jjjj":
		case "mm/dd/yyyy":
			return( m+'/'+t+'/'+j );
			break;
		case "iso":
		case "iso8601":
		case "jjjj-mm-tt":
		case "yyyy-mm-dd":
		default:
			return( j+'-'+m+'-'+t );
			break;
	}
	return null;
}

function getTm( fmt ) {
//----------------------------------------------------------------------------------------------------------
// Gibt Uhrzeit in einstellbarem Format zurück:
//		'ISO8601'	= 'hh:mm' (Standard)
// 		'de'			= 'hh.mm',
//		'en'			= 'hh:mm am|pm', (--> <http://www.boulder.nist.gov/timefreq/general/misc.htm#Anchor-57026>)
//----------------------------------------------------------------------------------------------------------
	var tm=new Date(),h,m;

	h=tm.getHours();
	m=tm.getMinutes();

	m=(m<10?'0'+m:m);

	if( typeof fmt=='undefined' )
		fmt='iso8601';

	switch( fmt.toLowerCase()) {
		case "de":
		case "hh.mm":
			return( (h<10?'0'+h:h)+'.'+m );
			break;
		case "en":
		case "hh:mm xm":
			return( (h>12?h-12:h==0?12:h)+':'+m+(h<12?' a.m.':m>'00'?' p.m.':'') );
			break;
		case "iso":
		case "iso8601":
		case "hh:mm":
		default:
			return( (h<10?'0'+h:h)+':'+m );
			break;
	}
	return null;
}

function ixTime2Str( ixtime,fmt,offset ) {
// Wandelt einen optionalen LongInt-Wert mit UNIX-Zeitangabe
// (= Millisekunden seit 1970-01-01, 00:00:00.00 UTC) bzw.
// die aktuellen Werte für Datum/Uhrzeit in einen festlegbaren
// Datums-/Zeit-String mit optionalem Offset gegen UTC um.
//
// Parameter:
//	ixtime:		(LongInt) -	fakultativ: Unix-Zeitangabe
//	fmt:			(Formatstring) -	fakultativ: Rückgabeformat
//	offset:		(Integer) -	fakultativ: Offset als Differenz
//												zwischen UTC und Rückgabezeitzone
//
// Autor/Letzte Änderung: Koe/Koe 2006-01-24 10:09

	var	date = typeof ixtime == 'number' ? new Date( ixtime ) : new Date(),
			Y=date.getUTCFullYear(),			// Jahr
			M=date.getUTCMonth()+1,				// Monat 1-12
			D=date.getUTCDate(),					// Tag
			h=date.getUTCHours(),					// Stunden
			m=date.getUTCMinutes(),				// Minuten
			s=date.getUTCSeconds(),				// Sekunden
			ms=date.getUTCMilliseconds();	// Millisekunden

	// Ggf. Default-Rückgabeformat einstellen
	// (ISO 8601 ohne Sekunden und Millisekunden)
	if( typeof fmt != 'string' )
		fmt="$Y-$0M-$0D $0h:$0m";

	// Wurde Offset angegeben?
	if( typeof offset != 'number' )
		offset=0;

	// Offset berücksichtigen
	if( offset ) {
		h -= offset<0 ? Math.ceil( offset/60 ) : Math.floor( offset/60 );
		m -= offset%60;
	}

	// Rückgabe des formatierten Datum-/Zeit-Strings
	return fmt.replace( /\$Y/,Y ).replace( /\$M/,M ).replace( /\$0M/,M<10 ? '0'+M : M ).replace( /\$D/,D ).replace( /\$0D/,D<10 ? '0'+D : D ).replace( /\$h/,h ).replace( /\$0h/,h<10 ? '0'+h : h ).replace( /\$m/,m ).replace( /\$0m/,m<10 ? '0'+m : m ).replace( /\$s/,s ).replace( /\$0s/,s<10 ? '0'+s : s ).replace( /\$ms/,ms );
}	// function ixTime2Str()

var startTime;
function startStopwatch() {
	var time=new Date();
	startTime=time;
}

function stopStopwatch() {
	var stopTime=new Date(),
			diffTime=stopTime-startTime;
	return diffTime/1000;
}

function showClock() {
	outStr( ixTime2Str( null,null,offsetUTC ),'clock' );
}	// function showClock()

var _countdown=new Array();
		_countdown.obj;
		_countdown.fwLoc;
		_countdown.time=10;
		_countdown.intvl=1000;
		_countdown.elmId='countdown';
function countdown() {
/**********************************************************
 * Funktion führt einen (sichtbaren) Countdown durch, nach*
 * dessen Ablauf eine Folgeseite geladen wird.						*
 * Achtung: Die aufrufende Seite sollte ein Element mit		*
 * eindeutiger Id definieren, in das die jeweils aktuelle	*
 * Zeit injiziert wird. Diese Id lautet normalerweise			*
 * `countdown´.																						*
 *--------------------------------------------------------*
 * Globale Variable:																			*
 *	_countdown.elmId:	die Element-Id für die Anzeige			*
 *	_countdown.fwLoc:	URI der Nachfolgeseite							*
 *	_countdown.intvl:	die Intervallzeit (i.d.R. 1000 ms)	*
 *	_countdown.obj:		das Intervallobjekt									*
 *	_countdown.time:	die Countdown-Zeit in [s]						*
 *--------------------------------------------------------*
 * Parameter:																							*
 *	keine																									*
 *--------------------------------------------------------*
 * Rückgabe:																							*
 *	- keine -																							*
 **********************************************************/

	if(_countdown.time > 0) {
		_countdown.time *= -1;
		if( _countdown.obj )
			window.clearInterval( _countdown.obj );
		_countdown.obj = window.setInterval( 'countdown()',_countdown.intvl );
	} else
		_countdown.time++;

	if(document.getElementById( _countdown.elmId ))
		document.getElementById( _countdown.elmId ).innerHTML = -_countdown.time;

	if(_countdown.time == 0) {
		if( _countdown.obj )
			window.clearInterval( _countdown.obj );
		if(_countdown.fwLoc)
			void( window.setTimeout( 'location.href="'+_countdown.fwLoc+'"',10 ));
	}
}	// function countdown()

function swapImage( dir, imgID, imgPath, imgExt ) {

	imgNo += dir;
	imgNo = (imgNo==0?lastImg:imgNo>lastImg?1:imgNo);

	document.getElementById( imgID ).src = imgPath+leadingZero( imgNo )+imgExt;
}	//function swapImage()

function interpolateY( x, x1, x2, y1, y2 ) {
//---------------------------------------------------------------------------------------------------
//	1.  y - y1		x - x1			2.						x - x1									3.			 x - x1
//		 ------- = ------- 					y - y1 = ------- * (y2 - y1)					y = ------- * (y2 - y1) + y1
//		 y2 - y1	 x2 - x1									 x2 - x1													x2 - x1
//---------------------------------------------------------------------------------------------------

	return (x - x1) / (x2 - x1) * (y2 - y1) + y1;

}	// function interpolateY()

/**** Funktionen für den Topframe ****/

function buildLocaleOption( l10n ){
// Sprachumschaltung: Pulldown-Menü bevölkern
	document.write( '<option '+(l10n==locale?'selected="selected" ':'')+'value="'+l10n+'">'+l10ndta[l10n]+'<\/option>' );
}	// function buildLocaleOption()

function chgL10n( elmid ){
// Sprachumschaltung vornehmen (Frameset neu laden)
// und gewählte Sprache in Cookie ablegen

	var	expdate = new Date();

	FixCookieDate( expdate );
	expdate.setTime( expdate.getTime() + 365 * 24 * 60 * 60 * 1000 );

	document.getElementById( elmid ).blur();
	locale = document.getElementById( elmid ).value;

	// L10n-Cookie setzen
  SetCookie( 'scom_l10n',locale,expdate,'\/' );

  // L10n-spezifisches Frameset laden
  	parent.location.href = locale + '\/' + frameURIs.top;
}	// function chgL10n()


/**** Funktionen für die Pumpenauswahl ****/

function selectSlot( slotId ) {
// Ermittelt den selektierten Steckplatz
// aus der angeklickten Tabellen-Id

var	isPump,
		pillar, segment, pump;

	parent.coverdata.selected = -1;
	parent.pumpdata.selected = [-1,-1,-1];

	if( slotId ) {
		isPump = slotId.indexOf( '_pu' )>-1;

		pillar = parseInt( slotId.substr( slotId.indexOf( '_pi' )+3,1 ));
		parent.coverdata.selected = pillar;

		if( isPump ) {
			segment = parseInt( slotId.substr( slotId.indexOf( '_sg' )+3,1 ));
			pump = parseInt( slotId.substr( slotId.indexOf( '_pu' )+3,1 ));
			parent.pumpdata.selected = [pillar,segment,pump];
		}	// if( isPump )
	}	// if( slotId )

	// Daten aktualisieren
	if(parent.dataFrame.feedData)
		parent.dataFrame.feedData();
}	// function selectSlot()


function toggleDrugnameNotation( notation ) {
// Schreibweise des
// Medikamentnamens setzen
	var p=parent,
		pMF=p.menuFrame,
		elm,
		expdate = new Date();
		
	if( !pMF ) {
		return;
	}

	// Notation setzen oder wechseln
	switch( notation ) {
		case 's':
		case 'l':
			elm = pMF.document.getElementById( 'drugname_' + notation );
			break;
		default:
			notation = softLimit.notation == 's' ? 'l' : 's';
			elm = pMF.document.getElementById( 'drugname_' + notation );
			break;
	}	// switch

	softLimit.notation = notation;	// Neue Notation sichern

	if( elm )
		elm.checked = true;	// RB-Zustand setzen

	selectSlot();	// Slots updaten

	// Cookie setzen
	FixCookieDate( expdate );
	expdate.setTime( expdate.getTime() + 365 * 24 * 60 * 60 * 1000 );
	SetCookie( 'scom_notation',softLimit.notation,expdate,'\/' );

}	// function toggleDrugnameNotation( notation )

function processDrugnameNotation( pageType ) {
// Umschaltmöglichkeit für Medikamentnamensschreibweise
// zeigen oder verbergen
var p=parent,
		pMF=p.menuFrame;

	if( typeof pageType != 'undefined' )
		if( elm = pMF.document.getElementById( 'shell_toggleDrugname' ))
			elm.style.display = pageType=='status' ? 'block' : 'none';
}	// function processDrugnameNotation( pageType )

function restoreDrugnameNotation( defNotation ) {
// Notation aus Cookie
// wiederherstellen
var	notation=null;

	notation = GetCookie( 'scom_notation' );	// Cookie auslesen

	// Falls Cookie nicht gesetzt, aber Default übergeben
	if( !notation && typeof defNotation == 'string' )
		notation = defNotation;

	// Notation setzen
	if( notation )
		toggleDrugnameNotation( notation );

}	// function restoreDrugnameNotation()

/**********************************************************************************
   DynAPI Distribution
   Browser Class

   The DynAPI Distribution is distributed under the terms of the GNU LGPL license.

   Additions by RJKoester 2003-07-04

***********************************************************************************/
function Browser() {
	var an=navigator.appName.toLowerCase();
	var ua=navigator.userAgent.toLowerCase();

	if((an.indexOf('netscape')>-1) && (ua.indexOf("mozilla")>-1) && (ua.indexOf("compatible")==-1) && (ua.indexOf("gecko")>-1))
		this.b="moz";
	else if(an.indexOf('netscape')>-1)
		this.b="ns";
	else if((an=="opera") || (ua.indexOf("opera")>-1))
		this.b="opera";
	else if(an=="microsoft internet explorer")
		this.b="ie";
	if(!an)
		alert('Unidentified user agent.\nthis.browser is not supported!');

	this.version=navigator.appVersion.toLowerCase();
	this.v=parseInt(this.version);
	this.ns=(this.b=="ns" && this.v>=4);
	this.ns3=(this.b=="ns" && this.v<4);
	this.ns4=(this.b=="ns" && this.v==4);
	this.ns6=(this.b=="ns" && this.v==5);
	this.mz=this.moz=(this.b=="moz");
	this.mz100=(this.b=="moz" && (ua.indexOf("rv:1.0.0")>-1 || ua.indexOf("gecko/200205")>-1 || ua.indexOf("gecko/200206")>-1));
	this.mz110=(this.b=="moz" && (ua.indexOf("rv:1.1")>-1 || ua.indexOf("gecko/200208")>-1));
	this.mz140=(this.b=="moz" && (ua.indexOf("rv:1.4")>-1 || ua.indexOf("Gecko/200306")>-1));
	this.mz1=(this.mz100 || this.mz110 || this.mz140);
	this.ie=(this.b=="ie" && this.v>=4);
	this.ie4=(this.version.indexOf('msie 4')>0);
	this.ie5=(this.version.indexOf('msie 5')>0);
	this.ie55=(this.version.indexOf('msie 5.5')>0);
	this.ie6=(this.version.indexOf('msie 6.0')>0);
	this.op=this.opera=(this.b=="opera");
	this.op4=(ua.indexOf("opera 4")>-1)||(ua.indexOf("opera/4")>-1);
	this.op5=(ua.indexOf("opera 5")>-1)||(ua.indexOf("opera/5")>-1);
	this.op6=(ua.indexOf("opera 6")>-1)||(ua.indexOf("opera/6")>-1);
	this.dom=(document.createElement && document.appendChild && document.getElementsByTagName && document.getElementsByName)?true:false;
	this.def=(this.ie||this.dom); // most used browsers, for faster if loops
	this.out=(!an||this.op4||this.ns4);

	if (ua.indexOf("win")>-1)
		this.platform="win32";
	else if (ua.indexOf("mac")>-1)
		this.platform="mac";
	else if (ua.indexOf("linux")>-1)
		this.platform="lnx";
	else if (ua.indexOf("os/2")>-1)
		this.platform="os2";
	else
		this.platform="other";
}
var isBrowser=new Browser();

/**** Copyright by Macromedia *****/
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_showHideLayers() { //v6.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

/**** Copyright by Macromedia *****/



