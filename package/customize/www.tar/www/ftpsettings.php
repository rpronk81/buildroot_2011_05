<?php 
include 'common.inc.php';

VerifyConfigAuth();
StyleTitle("FTP settings");

function CheckPasswordComplexity( $password ) {
	return  ((strlen($password) >= 6) &&
		 (preg_match("/[a-z]/", $password)) &&
		 (preg_match("/[A-Z]/", $password)) &&
		 (preg_match("/[0-9]/", $password)) &&
		 (preg_match('/[-.,_#+=!?~&%$§]/', $password)));
}

$filename = '/etc/spacecom/ftpd.passwd';
if (isset($_POST['sbt_ftp'])) {
	$user = $_POST['txt_user'];
	$password = $_POST['pwd_user'];
	$password_re = $_POST['pwd_re_user'];
	
	if ($password == $password_re) {
		
		if (!(empty($password))) {
			
			if(CheckPasswordComplexity($password)) {
						
				$pwd_hash = crypt($password);
				$string = "$user:$pwd_hash:2:2::/:/bin/false\n";
				
				if (file_exists($filename)) {
					echo "Password changed.<br>";
					$handle = fopen($filename, 'w');
					fwrite($handle, $string);
					fclose($handle);
				} else {
					$error = "Password file does not exist.";
				}
				
			} else {
				$error = "Password complexity to low. Please create a password with at least 6 characters that contains at least one lowercase character (a-z), uppercase character (A-Z), number (0-9) and one of -.,_#+=!?~&%\$§";
			} 
			
		} else {
			// Password was empty, remove config file
			if (file_exists($filename)) {
				fclose(fopen($filename, 'w+'));
			}
		}
		
	} else {
		$error = "Password does not match!";
	}	
}
if (file_exists($filename)) {
	$handle = fopen($filename, 'r');
	while ($content = fgets($handle, 4096)) {
	 	preg_match('/(^\w*):/i', $content, $matches);
	}
	if (isset($matches[1])) {
		$user_file = $matches[1];
	}
}


?>
<center>
<fieldset>
<legend>FTP Settings</legend>
<form action='./ftpsettings.php' method='POST'>
<table>
	<tr>
		<td>Username:</td>
		<td><input type='text' name='txt_user' value='<?php if(!empty($user_file)) echo $user_file; ?>'></td>
	</tr>
	<tr>
		<td>Password:</td>
		<td><input type='password' name='pwd_user'></td>
	</tr>
	<tr>
		<td>Confirm password:</td>
		<td><input type='password' name='pwd_re_user'></td>
	</tr>
	<tr>
		<td></td>
		<td><input type='submit' name='sbt_ftp' value='submit'></td>
	</tr>
</table>
</form>
</fieldset>
<?php 
if (empty($user_file)) {
	echo "<p>FTP is disabled, fill in details</p>";
} else {
	echo "<p>FTP is enabled, username is $user_file (password not shown)</p>";
}
PrintError($error);
?>

</center>
</body>
</html>

