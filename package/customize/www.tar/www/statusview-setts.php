<?php
include 'common.inc.php';

$xml = simplexml_load_file("/etc/spacecom/statusview.xml");

if (isset($_POST['btn'])) {
   	$viewId = $_POST['viewId'];
	$xml->ViewID=$viewId;
	$handle = fopen("/etc/spacecom/statusview.xml", "wb"); 
	fwrite($handle, $xml->asXML());
	fclose($handle);
	//redirect to index.html so that menu structure is rebuilt
	header("Location: index.html");
	exit();
}

VerifyConfigAuth();
StyleTitle("StatusView Settings");

function isSelected($value) {
	global $xml;
	if ($xml->ViewID == $value) {
		return "selected='selected'";
	}
	else {
		return "";
	}
}

echo 	"<div id = 'statusview'>".
	"<fieldset style='text-align:center'><legend>StatusView</legend>".
		"<form method='POST' action=".$_SERVER['PHP_SELF'].">".
			"<select name='viewId'>".
				"<option ".isSelected('1')." value='1'>Pump View</option>".
				"<option ".isSelected('4')." value='4'>Table View</option>".
			"</select>".
			"<input type='submit' name='btn' value=' OK '>".
		"</form>".
	"</fieldset></div>";	
?>
</body>
</html>
