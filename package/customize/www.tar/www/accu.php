<?php
include 'common.inc.php';

VerifyConfigAuth();
StyleTitle("Accu Management");

/**
 * Create Form for Accu recharge period and save it
 */
include 'dbus/dbus_classes.php';
$xml = simplexml_load_file("/etc/spacecom/AccuManagement.xml");

// FIXME: determine what should be the lower bound
if (isset($_POST['btn_accu'])) {
   	$accutime = $_POST['accu_txt'];
	if (is_numeric($accutime) && ($accutime >= 1) && ($accutime <= 255)) {
		$xml->Service_Interval=$accutime;
		$handle = fopen("/etc/spacecom/AccuManagement.xml", "wb"); 
		fwrite($handle, $xml->asXML());
		fclose($handle);
	} else {
		PrintError("Enter number between 1 and 255!");
	}
}

echo 	"<div id = 'accu'>".
	"<fieldset style='text-align:center'><legend>Service Interval</legend>".
		"<form method='POST' action=".$_SERVER['PHP_SELF'].">".
			"<input name='accu_txt' type='text' size='5' maxlength='3' value='{$xml->Service_Interval}'>".
				" Days (max. 255)<br />".
			"<input type='submit' name='btn_accu' value=' Send '>".
		"</form>".
	"</fieldset></div>";	
?>
</body>
</html>
