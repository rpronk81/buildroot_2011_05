<?php

session_start();

echo "<script src='../func/cookie.js' type='text/javascript'></script>";

$_SESSION = array();
$_POST = array();
$_GET = array();

session_destroy();

echo "<script type='text/javascript'>DeleteCookie('scomusrnamestatus','/');DeleteCookie('scomusrnameservice','/');DeleteCookie('scomusrnameconfig','/');</script>";

if (isset($_COOKIE["scomusrnamestatus"]))
{
    unset($_COOKIE["scomusrnamestatus"]);
    setcookie("scomusrnamestatus", null, -1, "/");
}

if (isset($_COOKIE["scomusrnameservice"]))
{
    unset($_COOKIE["scomusrnameservice"]);
    setcookie("scomusrnameservice", null, -1, "/");
}

if (isset($_COOKIE["scomusrnameconfig"]))
{
    unset($_COOKIE["scomusrnameconfig"]);
    setcookie("scomusrnameconfig", null, -1, "/");
}

echo "<script type='text/javascript'>window.location='https://".$_SERVER['HTTP_HOST']."'</script>";

exit;

?>
