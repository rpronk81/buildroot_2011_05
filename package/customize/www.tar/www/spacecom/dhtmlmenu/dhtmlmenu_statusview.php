﻿/************************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'											*
 * Copyright (c) 2003,2005 des Menü-Layouts by B. Braun Melsungen AG		*
 * Copyright (c) 2004,2005 des Objektmodells by B2A Corporate Marketing	*
 * All rights reserved																									*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03, 05, 07																					*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de					*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***					*
 * Version: 2.0.0																												*
 * Autor: B2A/Koe																												*
 * Letzte Bearbeitung: 2005-08-01 10:14																	*
 * durch: Koe																														*
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **
 * Achtung:	/func/dhtmlmenu/dhtmlmenu.classes.js muss zuerst includiert	*
 *					werden, und die globalen Variablen `parent.locale´,					*
 *					`parent.dir´, `parent.mnutxt´ und `parent.msg´ müssen				*
 *					verfügbar sein!																							*
 ************************************************************************/

// Menüobjekt generieren
var	menu = new menuItem( 'menu',0,null,null );

// Tiefste Menüebene festlegen (muss
// mit CSS-Klassen korrespondieren!)
menu.lastlevel = 3;

// Nachbarschaftsmarkierung definieren
menu.coItemMarking = [false,0,0,0];

var startItem = 'm4';

if( typeof locale!='undefined' ) {

	// (Unter-)Menüobjekte dynamisch generieren;
	// da hierbei der locale berücksichtigt wird,
	// muss dieser vorher gesetzt worden sein
	for ( var i in mnutxt[locale] )
		eval( "var %menuItem%=new menuItem('%menuItem%',%lvl%,mnutxt[locale].%menuItem%,'0000')".replace( /%menuItem%/g,i ).replace( /%lvl%/,(1+countChar( '_',i ))).replace( /0000/,dec2bin( state.BASE,4 )));

	// mnutxt-Array wird
	// nicht mehr benötigt
	void( delete mnutxt );

	// Struktur und Hierarchie der (Unter-)Menüobjekte
	// Stand: 2005-04-21
	switch( startItem ) {
		case 'm1':
			menu.items = [m1, m2, m3];
			break;
		case 'm4':
			//menu.items = [m1, m2, m3, m4];
			menu.items = [m4, m2, m3];
			break;
	}	// switch()

	// (Sonder-)Aktionen für einzelne Menüebenen
	// festlegen (Javascript in Quotes!), z.B.:
	//mX.action = "loadContentData('mX');";
	m3.action = "parent.contentFrame.location.href = '../login.php?target=config&locale=" + locale + "';";
	m1.action = "parent.contentFrame.location.href = '../login.php?target=status&locale=" + locale + "';";
	m2.action = "parent.contentFrame.location.href = '../login.php?target=service&locale=" + locale + "';";
	m4.action = "parent.contentFrame.location.href = '../login.php?target=status&TBView=1&locale=" + locale + "';";

} else
	window.alert( 'Sprachversion undefiniert,\nMenü nicht generierbar!\n\nLocale undefined,\nunable to build menu!' );


function buildMenu( Delay ) {
/****************************************************************
 * Funktion generiert das Menü, versteckt alle Untermenüebenen	*
 * und wählt die Startmenüebene aus. Der Aufruf sollte verzögert*
 * in `dhtmlmenu.html´ erfolgen.				*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Rückgabe:																										*
 * 	- keine -																										*
 ****************************************************************/
	// Bei erstmaligem Start oder
	// nach Aktualisierung ...
	if(parent.freshLoad) {
		parent.freshLoad=false;
		Delay*=10;	// beim ersten Aufruf deutliche Verzögerung
	}

	// Start-URI des Content-Frames sichern; wird später
	// zum Nachladen innerhalb des Content-Frames benötigt
	if(parent.contentURI==null)
		parent.contentURI=parent.window.location.href;

	// Falls der Start-URI nicht mehr den Dateinamen
	// der Initdatei enthält, URI wiederherstellen
	if(parent.contentURI.indexOf( '.init.' )==-1)
		parent.contentURI=parent.contentURI.substr( 0,parent.contentURI.lastIndexOf( '\/' )+1 )+parent.contentInitFName;

	contentURI=parent.contentURI;

	// Menü generieren
	menu.build();
	menu.hideAll();	// IE benötigt dies, wenn `dhtmlmenu.html´ in UTF-8-Codierung

	// Startmenüpunkt verzögert selektieren
	void( window.setTimeout( 'selectMenuItem(startItem)', Delay ));
}	// function buildMenu()
