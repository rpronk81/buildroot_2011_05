<?php
include '../common.inc.php';
include 'login_limiter.php';
session_start();

// Session needed for authentication against dbus php pages
// gettext initialization

$language = $_GET["locale"];
putenv("LANG=$language");
setlocale(LC_ALL, $language);
$domain = 'messages';
bindtextdomain($domain, "./");
bind_textdomain_codeset($domain, "UTF-8");
textdomain($domain);

$loginFile = "/etc/spacecom/login.xml";
$loginSource = new DomDocument;
$loginSource->load($loginFile);
$loginXpath = new DOMXPath($loginSource);

$allowedChars = array("-", ".", ",", "_", "#", "+", "=", "!", "?", "~", "&", "%", "$", "§");

$userNode	= "";

if ($_GET["target"] == "") {
	Header("Location: login.php?target=config&locale=".$language);
}
if ($_POST['sbmt_login']) {
	if (! loginTryAllowed()) {
		TriesExceeded();
	}else{
		HandleLogin();
	}
} else {
	if (($_GET['target']=='config') && ($_SESSION["DbusAuth"] == "yes")) {
		if(($_REQUEST['ChangePSW'] == 1) || ($_REQUEST["ChangeLoginName"] == 1) || ($_REQUEST["ChangeAccessRight"] == 1)){
			HandleLogin();
		} else if($_GET['UserAdmin'] == 1) {
			ConfigurationLinksForUserAdministration($_GET["target"]);
		} else {
			ConfigurationLinks($_GET["target"]);
		}
	} else if (($_GET['target']=='status') && ($_SESSION["StatusAuth"] == "yes")) {
		if(($_REQUEST['ChangePSW'] == 1) || ($_REQUEST["ChangeLoginName"] == 1) || ($_REQUEST["ChangeAccessRight"] == 1)){
			HandleLogin();
		} else {
			if($_GET['TBView'] == 1) {
				echo "<script type='text/javascript'>location.href='".$language."/scom_c.m4.html'</script>";
			} else {
				echo "<script type='text/javascript'>location.href='".$language."/scom_c.m1.html'</script>";
			}
		}
	} else if (($_GET['target']=='service') && ($_SESSION["ServiceAuth"] == "yes")) {
		if(($_REQUEST['ChangePSW'] == 1) || ($_REQUEST["ChangeLoginName"] == 1) || ($_REQUEST["ChangeAccessRight"] == 1)){
			HandleLogin();
		} else {
			echo "<script type='text/javascript'>location.href='".$language."/scom_c.m2.html'</script>";
		}
	} else {
		HandleLogin();
	}
}

function validateInput($user)
{
	// each array entry is an special char allowed
	// besides the ones from ctype_alnum
	if ( ctype_alnum( str_replace($allowedChars, '', $user ) ) ) {
		return $user;
	} else {
		$user = "";
		return $user;
	}
}

function HandleLogin()
{
	global $loginSource, $loginFile, $userNode, $loginXpath;

	if (count($_POST) <= 0) {	// Not POST method
		NoUser("");
		return;
	}

	$userNode = $loginXpath->query("//Users/User[@name=\"".$_POST["username"]."\"]");

	if (gettype($userNode) == "NULL") {
		UnknownUser();
		return;
	}

	if (md5($_POST["passwordold"]) != $userNode->item(0)->nodeValue) {
	   	WrongPassword();
		return;
	}

	if($_SESSION["DbusAuth"]!='yes') {
		$_SESSION["DbusAuth"] = "no";
	}

	if ($_GET["UserAdmin"] == "1") {
		ConfigurationLinksForUserAdministration($_GET["target"]);
	} else if (($_REQUEST["ChangePSW"] == "1")) {
		ChangePassword($userNode);
	} else if ($_REQUEST["ChangeLoginName"] == "1") {
		ChangeLoginName($userNode);
	} else if ($_REQUEST["ChangeAccessRight"] == "1") {
		ChangeAccessRights($userNode);
	} else if (CheckTarget($userNode) == "1") {
		if ($userNode->item(0)->getAttribute("expired") != "False") {
			PasswordExpiredConfirmation();
		} else {
			setCookiesAndForward($userNode);
		}
	}
}

function nodeExistsAndEquals($node, $value) {
	return (!is_null($node) && ($node->nodeValue == $value));
}

function setCookiesAndForward($userNode) {
	// if the user is accessing config and has permission to do so,
	// set the Session variable which grants access to dbus pages
	if ($_GET["target"] == "config") {
		$_SESSION["DbusAuth"] = "yes";
	}
	
	$userAttribs = $userNode->item(0)->attributes;
	if(nodeExistsAndEquals($userAttribs->getNamedItem("status"), "Y")) {
		$_SESSION["StatusAuth"] = "yes";
	}
	
	if(nodeExistsAndEquals($userAttribs->getNamedItem("service"), "Y")) {
		$_SESSION["ServiceAuth"] = "yes";
	}
	
	if ($_GET["target"] == "status") {
		setcookie("scomusrnamestatus", $_POST["username"], 0, "/");
		
		if($_GET["TBView"] == 1) {
			if((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443) {
				Header("Location: https://".$_SERVER['HTTP_HOST']."/spacecom/".$_GET["locale"]."/scom_c.m4.html");
			}else{
				Header("Location: http://".$_SERVER['HTTP_HOST']."/spacecom/".$_GET["locale"]."/scom_c.m4.html");
			}
		} else {
			if((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443) { 
				Header("Location: https://".$_SERVER['HTTP_HOST']."/spacecom/".$_GET["locale"]."/scom_c.m1.html");
	        }else{
	        	Header("Location: http://".$_SERVER['HTTP_HOST']."/spacecom/".$_GET["locale"]."/scom_c.m1.html");
			}
		}
	} else if ($_GET["target"] == "service") {
		setcookie("scomusrnameservice", $_POST["username"], 0, "/");
		
		if((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443) { 
			Header("Location: https://".$_SERVER['HTTP_HOST']."/spacecom/".$_GET["locale"]."/scom_c.m2.html");
        }else{
        	Header("Location: http://".$_SERVER['HTTP_HOST']."/spacecom/".$_GET["locale"]."/scom_c.m2.html");
		}
	} else {
		setcookie("scomusrnameconfig", $_POST["username"], 0, "/");
		
		ConfigurationLinks($_GET["target"]);
	}
}

function CheckTarget( $targetNode ) {
	$checkTarget = 0;

	$attributeNameForTarget = $targetNode->item(0)->getAttributeNode($_GET["target"]);

	if ($attributeNameForTarget->value == "Y") {
		$checkTarget = 1;
	} else {
		NoPermission();
	}

	return $checkTarget;
}

function CheckPasswordComplexity( $password ) {
	return  ((strlen($password) >= 6) &&
		 (preg_match("/[a-z]/", $password)) &&
		 (preg_match("/[A-Z]/", $password)) &&
		 (preg_match("/[0-9]/", $password)) &&
		 (preg_match('/[-.,_#+=!?~&%$§]/', $password)));
}

function ChangePassword( $node2Check ) {
// 	if (CheckTarget($node2Check) == "1") {
	global $userNode, $loginSource, $loginFile;

	if ($_POST["passwordnew"] == $_POST["passwordconf"]) {
		if (CheckPasswordComplexity($_POST["passwordnew"])) {
			$node2Check->item(0)->nodeValue = md5($_POST["passwordnew"]);
			$node2Check->item(0)->setAttribute("expired","False");
			ParanoidFileSave($loginFile, $loginSource);
			setCookiesAndForward($userNode);
		} else {
			PasswordNotComplexEnough();
		}
	} else {
		WrongPasswordConfirmation();
	}
// 	}
}

function ChangeLoginName( $node2Check ) {
	global $loginSource, $loginFile, $userNode;

// 	if (CheckTarget( $node2Check ) == "1") {
		if ($_POST["usernamenew"] == $_POST["usernameconf"])		{
			$attributeNode = $userNode->item(0)->getAttributeNode("name");
			$attributeNode->value = $_POST["usernamenew"];
			ParanoidFileSave($loginFile, $loginSource);
			ConfigurationLinks($_GET["target"]);
		} else {
			WrongLoginNameConfirmation();
		}
// 	}
}

function ChangeAccessRights( $node2Check ) {
// 	if (CheckTarget( $node2Check ) == "1") {
		global $userNode, $loginSource, $loginFile;

		$attributeNode = $userNode->item(0)->getAttributeNode("service");
		$attributeNode->value = (($_POST["service"] == "Y") ? "Y" : "N");
		$attributeNode = $userNode->item(0)->getAttributeNode("status");
		$attributeNode->value = (($_POST["status"] == "Y") ? "Y" : "N");
		$attributeNode = $userNode->item(0)->getAttributeNode("config");
		$attributeNode->value = (($_POST["config"] == "Y") ? "Y" : "N");
		ParanoidFileSave($loginFile, $loginSource);
		ConfigurationLinks($_GET["target"]);
// 	}
}

function SetInputFields() {
	if ($_REQUEST["ChangePSW"] == "1") {
		InputFieldsForChangePSW("");
	} else if ($_REQUEST["ChangeLoginName"] == "1") {
		InputFieldsForChangeLoginName("");
	} else if ($_REQUEST["ChangeAccessRight"] == "1") {
		if(isset($_COOKIE["scomusrnameconfig"]) && !empty($_COOKIE["scomusrnameconfig"]))
		{
			InputFieldsForChangeAccessRight( $_COOKIE["scomusrnameconfig"] );
		}
		else
		{
			HandleLogin();
		}
	} else {
		InputFields( $parameter );
	}
}

function LoginHeader( $message, $message2 ) {
	StyleTitle("Welcome to the SpaceOnline login");
	print "<br><br><br><br><br><br>";
	print "<center>";
	print "<h4>";
	print gettext($message);
	print "</h4>";
	print "<strong>";
	print gettext($message2);
	print "</strong>";
}

function LoginTrailer() {
	print "</center>";
	print "</body></html>";
}

function PasswordExpiredConfirmation() {
	LoginHeader("Password expired", "The password for your user has expired, please assign a new one");
	InputFieldsForChangePSW($_POST["username"]);
	LoginTrailer();
}

function PasswordNotComplexEnough() {
	LoginHeader("Password complexity to low",
		'Please create a password with at least 6 characters that contains at least one lowercase character (a-z), uppercase character (A-Z), number (0-9) and one of "-.,_#+=!?~&%$§"');
	InputFieldsForChangePSW($_POST["username"]);
	LoginTrailer();
}

function WrongPasswordConfirmation() {
	LoginHeader("Wrong password confirmation.", "Please reenter Username and Password");
	InputFieldsForChangePSW($_POST["username"]);
	LoginTrailer();
}

function WrongLoginNameConfirmation() {
	LoginHeader("Wrong user name confirmation.", "Please reenter Username and Password");
	InputFieldsForChangeLoginName($_POST["username"]);
	LoginTrailer();
}

function NoUser() {
	if ($_GET["UserAdmin"] == "1") {
		ConfigurationLinksForUserAdministration($_GET["target"]);
	} else {
	    LoginHeader("", "Please enter Username and Password");
		SetInputFields();
		LoginTrailer();
	}
}

function TriesExceeded() {
	LoginHeader("Maximal amount of login attempts exceeded", "Please wait one minute before your next attempt.");
	SetInputFields($_POST["username"]);
	LoginTrailer();
}

function UnknownUser() {
	LoginHeader("Unknown username.", "Please reenter Username and Password");
	SetInputFields("");
	LoginTrailer();
}

function WrongPassword() {
	LoginHeader("Wrong password.", "Please reenter Username and Password");
	SetInputFields($_POST["username"]);
	LoginTrailer();
}

function NoPermission() {
	LoginHeader("No permission for the given target.", "Please reenter Username and Password");
	SetInputFields($_POST["username"]);
	LoginTrailer();
}

function InputFields( $username ) {
	$username = validateInput($username);
	
	print "<form method=\"post\">";
	print "<br><br><br><br>";
	print "<table>";
	print "<tr>";
	print "<td><input type=\"text\" name=\"username\" id=\"feldusername\" size=\"20\" value=\"";
	print $username;
	print "\"/></td>";
	print "<td><label for=\"feldusername\">";
	print gettext("Username");
	print "</label></td>";
	print "</tr>";
	print "<tr>";
	print "<td><input type=\"password\" name=\"passwordold\" id=\"feldpasswordold\" size=\"20\"/></td>";
	print "<td><label for=\"feldpasswordold\">";
	print gettext("Password");
	print "</label></td>";
	print "</tr>";
	print "</table>";
	print "<br><br><br><br>";
	print "<input type=\"submit\" value=\"";
	print gettext("Login");
	print "\" name=\"sbmt_login\" />";
	print "</form>";
}

function InputFieldsForChangeAccessRight( $username ) {
	global $loginXpath;

	print "<form method=\"post\">";
	print "<br><br><br><br>";
	print "<table>";
	print "<tr>";
	print "<td><input type=\"text\" name=\"username\" id=\"feldusername\" size=\"20\" value=\"";
	print $username;
	print "\"/></td>";
	print "<td><label for=\"feldusername\">";
	print gettext("Username");
	print "</label></td>";
	print "</tr>";
	print "<tr>";
	print "<td><input type=\"password\" name=\"passwordold\" id=\"feldpasswordold\" size=\"20\"/></td>";
	print "<td><label for=\"feldpasswordold\">";
	print gettext("Password");
	print "</label></td>";
	print "</tr>";
	print "</table>";

	$userNode1 = $loginXpath->query("//Users/User[@name=\"".$username."\"]");

	$attrib = $userNode1->item(0)->getAttributeNode("status");

	print "<br></br><br></br>";

	print "<table>";
	print "<th>";
	print gettext("Access Rights");
	print "</th>";
	print "<tr>";
	if ($attrib->value == "Y") {
		print "<td><input type=\"checkbox\" name=\"status\" value=\"Y\" checked/>";
		print gettext("Status");
		print "</td>";
	} else {
		print "<td><input type=\"checkbox\" name=\"status\" value=\"Y\"/>";
		print gettext("Status");
		print "</td>";
	}
	print "</tr>";

	print "<tr>";
	$attrib = $userNode1->item(0)->getAttributeNode("service");
	if ($attrib->value == "Y") {
		print "<td><input type=\"checkbox\" name=\"service\" value=\"Y\" checked/>";
		print gettext("Service");
		print "</td>";
	} else {
		print "<td><input type=\"checkbox\" name=\"service\" value=\"Y\"/>";
		print gettext("Service");
		print "</td>";
	}
	print "</tr>";

	print "<tr>";
	$attrib = $userNode1->item(0)->getAttributeNode("config");
	if ($attrib->value == "Y") {
		print "<td><input type=\"checkbox\" name=\"config\" value=\"Y\" checked/>";
		print gettext("Configuration");
		print "</td>";
	} else {
		print "<td><input type=\"checkbox\" name=\"config\" value=\"Y\"/>";
		print gettext("Configuration");
		print "</td>";
	}
	print "</tr>";
	print "</table>";

	print "<br><br><br><br>";
	print "<input type=\"submit\" value=\"";
	print gettext("Change access rights");
	print "\"/>";
	print "</form>";
}

function InputFieldsForChangePSW( $username, $oldNecessary=true ) {
	
	$user = validateInput($username);
	
	print "<form method=\"post\">";
	print "<input type=\"hidden\" name=\"ChangePSW\" value=\"1\" />";
	print "<br><br><br><br>";
	print "<table>";
	print "<tr>";
	print "<td><input type=\"text\" name=\"username\" id=\"feldusername\" size=\"20\" value=\"";
	print $user;
	print "\"/></td>";
	print "<td><label for=\"feldusername\">";
	print gettext("Username");
	print "</label></td>";
	print "</tr>";
	if ($oldNecessary) {
		print "<tr>";
		print "<td><input type=\"password\" name=\"passwordold\" id=\"feldpasswordold\" size=\"20\"/></td>";
		print "<td><label for=\"feldpasswordold\">";
		print gettext("Password");
		print "</label></td>";
		print "</tr>";
	}
	print "<tr>";
	print "<td><input type=\"password\" name=\"passwordnew\" id=\"feldpasswordnew\" size=\"20\"/></td>";
	print "<td><label for=\"feldpasswordnew\">";
	print gettext("New password");
	print "</label></td>";
	print "</tr>";
	print "<tr>";
	print "<td><input type=\"password\" name=\"passwordconf\" id=\"feldpasswordconf\" size=\"20\"/></td>";
	print "<td><label for=\"feldpasswordconf\">";
	print gettext("Password confirmation");
	print "</label></td>";
	print "</tr>";
	print "</table>";
	print "<br><br><br><br>";
	print "<input type=\"submit\" value=\"";
	print gettext("Change password");
	print "\"/>";
	print "</form>";
}

function InputFieldsForChangeLoginName( $username ) {
	
	$user = validateInput($username);
	
	print "<form method=\"post\">";
	print "<br><br><br><br>";
	print "<table>";
	print "<tr>";
	print "<td><input type=\"text\" name=\"username\" id=\"feldusername\" size=\"20\" value=\"";
	print $user;
	print "\"/></td>";
	print "<td><label for=\"feldusername\">";
	print gettext("Username");
	print "</label></td>";
	print "</tr>";
	print "<tr>";
	print "<td><input type=\"password\" name=\"passwordold\" id=\"feldpasswordold\" size=\"20\"/></td>";
	print "<td><label for=\"feldpasswordold\">";
	print gettext("Password");
	print "</label></td>";
	print "</tr>";
	print "<tr>";
	print "<td><input type=\"text\" name=\"usernamenew\" id=\"feldusernamenew\" size=\"20\"/></td>";
	print "<td><label for=\"feldusernamenew\">";
	print gettext("New user name");
	print "</label></td>";
	print "</tr>";
	print "<tr>";
	print "<td><input type=\"text\" name=\"usernameconf\" id=\"feldusernameconf\" size=\"20\"/></td>";
	print "<td><label for=\"feldusernameconf\">";
	print gettext("User name confirmation");
	print "</label></td>";
	print "</tr>";
	print "</table>";
	print "<br><br><br><br>";
	print "<input type=\"submit\" value=\"";
	print gettext("Change user name");
	print "\"/>";
	print "</form>";
}

function OneLink( $ref, $text ) {
	 print "<br><br>";
	 print "<a href=\"" . $ref . "\">";
	 print gettext( $text );
	 print "</a>";
}

function ConfigurationLinks( $target ) {
	StyleTitle("Welcome to the SpaceOnline login");
	if($target == 'config') setlogin();
	// workaround to keep auto page updates runnung:
	echo<<<EOT
<script type="text/javascript">
subPanels = new Array();
</script>
<script src="_js/scom.infopage.js" type="text/javascript"></script>
EOT;
	print "<br><br><br><br>";
	print "<center>";
	print "<h4>";
	print gettext("Please select configuration type");
	print "</h4>";
	OneLink("login.php?UserAdmin=1&target=$target&locale=$language", "User administration");
	//if (GetBoard() != "spacecomlite") {
		OneLink("../dbus/controller.php", "Network settings");
	//}
	OneLink("../bccsetts.php", "BCC Protocol settings");
	OneLink("../autoprogramming-setts.php", "AutoProgramming settings");
	OneLink("../pcs-setts.php", "PCS settings");
	if (GetBoard() != "spacecomlite") {
		OneLink("../accu.php", "Accu settings");
	}
	OneLink("../db-setts.php", "Database settings");
	OneLink("../dbus/showlogs.php", "Log files");
	OneLink("../ftpsettings.php", "FTP settings");
	OneLink("../dbus/sntp.php", "(S)NTP settings");
	OneLink("../export.php", "Export / Import settings");
	OneLink("../maint.php", "Maintenance and software updates");
	OneLink("../statusview-setts.php", "StatusView settings");
	print "</form>";
	print "</center>";
	print "</body></html>";
}

function ConfigurationLinksForUserAdministration( $target ) {
	global $language;

	StyleTitle("Welcome to the SpaceOnline login");
	print "<br><br><br><br><br><br>";
	print "<center>";
	print "<h4>";
	print gettext("Please select administration link");
	print "</h4>";
	print "<br><br>";
	OneLink("login.php?ChangePSW=1&target=$target&locale=$language", "Change the password");
	OneLink("login.php?ChangeLoginName=1&target=$target&locale=$language", "Change the login name");
	OneLink("login.php?ChangeAccessRight=1&target=$target&locale=$language", "Change the access rights");
	print "</center>";
	print "</body></html>";
  }

function ParanoidFileSave($fname, &$xmlobject) {

	$data = $xmlobject->saveXML();
	$fname_prep = $fname . "." . rand();
	$handle = fopen($fname_prep, "w+");

	if ($handle === FALSE) {
		return false;
	}

	if (fwrite($handle, $data) === FALSE) {
		return false;
	}

	if (fclose($handle) === FALSE) {
		return false;
	}

	exec("sync");

	if (rename($fname_prep, $fname) === FALSE) {
		return false;
	}

	exec("sync");

	return true;
}

function setlogin() {                                                                                               
echo "<script language='JavaScript' type='text/javascript'>                                                          
<!--                                                                                                                 
var ch='m3',                                                                                        
        p=parent,                                                                                                    
        locale=p.locale,                                                                                             
        msg=p.msg[locale],                                                                                
        pageType='config',                                                                                  
        usrname=p.GetCookie('scomusrname'+pageType);                                                                
                                                                 
var regEx = /[^\s\w@_.-]+/g;                                                                                      
var validusr = null;                                                                                                 
                                                                                                             
if(!usrname) {                                                                                                   
        location.href='login.php?target=config&locale='+locale;                      
} else {                                                                                                    
        validusr = usrname.replace(regEx, '');                                        
        var userElem = p.topFrame.document.getElementById('user');                                                   
        userElem.innerHTML=p.msg[locale].lbl_loginName+(p.userdata.usrname=validusr);                       
        userElem.href = 'login.php?target=config&ChangePSW=1&locale='+locale;                                        
}                                                                                                                    
//-->                                                                                                                
</script>";
}
?>

