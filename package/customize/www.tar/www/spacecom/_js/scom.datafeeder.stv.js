/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Javascript-Code: DataFeeder für StatusView
 * Projekt: SpaceOnline, B. Braun Melsungen AG
 * Copyright (c) 2005,2010 by B2A Corporate Marketing GmbH
 * All rights reserved
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 * Development:
 *	2005-03,04…09
 *	2006-01,02,07…09
 *	2010-05,06,07
 * Code Revisions:
 *	1:	2010-05
 * by B2A Corporate Marketing GmbH, Kassel; mailto:dev-AT-b2a-DOT-de
 * Version: 1.5.0
 * Autor: B2A/koe
 * Letzte Bearbeitung: 2010-07-06 08:26
 * durch: Koe
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*******************
 * Initialisierung *
 *******************/
 		// Frameset-globale Variablen
 		// importieren
var p		= parent,
		pCF	= p.contentFrame,
		pTF	= p.topFrame,
		msg	= p.msg[p.locale];

		// Globale Laufvariablen und Schleifengrenzen
var	pillar, maxpillar		= 2,	// Säule, letzte Säule
		segment, maxsegment	= 5,	// Segment, letztes Segment
		pump, maxpump				= 3;	// Pumpe, letzte Pumpe

		// Globale Code-Templates
var	templates = {
			pumpIcon:	'<img class="pumpicon" title="$desc" alt="$desc" src="\/images\/ico.ptype.$type.s.blk.png" />'
		};

		// Globale Daten-Arrays
var	pumpdata		= [],
		svccoverdta	= [],
		svcpumpdta	= [],
		systemdata	= [];

		// Sortiermethoden
var	statusViewSort	= {
	curr:		['slotid'],
	desc:		[false],
	method:	{
		doserate:	function( a,b ) {	return 1*(a.doserate>b.doserate)-1*(a.doserate<b.doserate)	},
		drugname:	function( a,b ) {	return 1*(a.drugname>b.drugname)-1*(a.drugname<b.drugname)	},
		infrate:	function( a,b ) {	return 1*(a.infrate>b.infrate)-1*(a.infrate<b.infrate)	},
		infvol:		function( a,b ) {	return 1*(a.infvol>b.infvol)-1*(a.infvol<b.infvol)	},
		pump:			function( a,b ) {	return 1*(a.pump>b.pump)-1*(a.pump<b.pump)	},
		remtime:	function( a,b ) {	return 1*(a.infrtime>b.infrtime)-1*(a.infrtime<b.infrtime)	},
		slotid:		function( a,b ) {	return 1*(a.slotid>b.slotid)-1*(a.slotid<b.slotid)	},
		status:		function( a,b ) {	return 1*(a.statuscolor>b.statuscolor)-1*(a.statuscolor<b.statuscolor)	}
	}
};


/*************************
 * Funktionsdefinitionen *
 *************************/
function initSystemData() {
/**
	* \brief	Initialisierung der Systemdaten
	*
	*					Prozedur initSystemData(): Initialisierung der
	*					Datenliste der Systemdaten
	*
	* \param	keine
	* \return	keine
	*
	*/

	systemdata.stationid				= null;
	systemdata.numpillars				= 0;
	systemdata.numsegperpillar	= [];

	// Iteration über Säulen
	for( pillar=0; pillar<=maxpillar; ++pillar ) {
		systemdata.numsegperpillar[pillar] = 0;
	}	// for( pillar… )
}	// function initSystemData()

function initPumpData() {
/**
	* \brief	Initialisierung der Pumpendaten
	*
	*					Prozedur initPumpData(): Initialisierung der
	*					Datenliste der Pumpendaten
	*
	* \param	keine
	* \return	keine
	*
	*/

	// Iteration über Säulen
	for( pillar=0; pillar<=maxpillar; ++pillar ) {
		pumpdata[pillar] = [];

		// Iteration über Segmente
		for( segment=0; segment<=maxsegment; ++segment ) {
			pumpdata[pillar][segment] = [];

			// Iteration über Pumpen
			for( pump=0; pump<=maxpump; ++pump ) {
				pumpdata[pillar][segment][pump]								= {};
				pumpdata[pillar][segment][pump].alarm					= null;
				pumpdata[pillar][segment][pump].doserate			= null;
				pumpdata[pillar][segment][pump].drugcolor			= null;
				pumpdata[pillar][segment][pump].drugconcent		= null;
				pumpdata[pillar][segment][pump].drugname			= null;
				pumpdata[pillar][segment][pump].drugnameshort	= null;
				pumpdata[pillar][segment][pump].infrate				= null;
				pumpdata[pillar][segment][pump].infrtime			= null;
				pumpdata[pillar][segment][pump].infrvol				= null;
				pumpdata[pillar][segment][pump].inftime				= null;
				pumpdata[pillar][segment][pump].infvol				= null;
				pumpdata[pillar][segment][pump].patbirthday		= null;
				pumpdata[pillar][segment][pump].patbirthmonth	= null;
				pumpdata[pillar][segment][pump].patbirthyear	= null;
				pumpdata[pillar][segment][pump].patgender			= null;
				pumpdata[pillar][segment][pump].patid					= null;
				pumpdata[pillar][segment][pump].patname				= null;
				pumpdata[pillar][segment][pump].patsurname		= null;
				pumpdata[pillar][segment][pump].patweight			= null;
				pumpdata[pillar][segment][pump].prealarm			= null;
				pumpdata[pillar][segment][pump].profiletype		= null;
				pumpdata[pillar][segment][pump].remalarm			= null;
				pumpdata[pillar][segment][pump].serialnumber	= null;
				pumpdata[pillar][segment][pump].slotid				= null;
				pumpdata[pillar][segment][pump].SLstatus			= null;
				pumpdata[pillar][segment][pump].software			= null;
				pumpdata[pillar][segment][pump].status				= null;
				pumpdata[pillar][segment][pump].syrname				= null;
				pumpdata[pillar][segment][pump].syrvol				= null;
			}	// for( pump… )
		}	// for( segment… )
	}	// for( pillar… )
}	// function initPumpData()

function reloadFeeder() {
/**
	* \brief	 Feeder-Frame neu laden
	*
	*					Prozedur reloadFeeder():
	*					Initiiert einen Reload des DataFeeder-Frames
	*
	* \param	keine
	* \return	keine
	*
	*/

	// Feeder-Frame neu laden
	if( iv ) {
		window.clearTimeout( iv );
	}	// if…

	p.isAlive = false;

	location.reload();
}	// function reloadFeeder()

function feedData() {
/**
	* \brief	Datenausgabezyklus ausführen
	*
	*					Prozedur feedData():
	*					Führt einen Datenausgabezyklus aus
	*
	* \param	keine
	* \return	keine
	*
	*/

	// Aktualisierungsprozess in Statuszeile melden
	window.status = window.defaultStatus + ' ' + msg.feedingData;

	// Flag: Aktualisierung im Gang
	p.feedingIsInProgress = true;

	// Zeichen-›Konstanten‹
	var	_DASH_	= '&minus;',	// Kein Wert (Strich)
			_SEP_		= ' | ',	// Trennung von Meldungen
			_LI_		= '',					// Ende eines Listeneintrags
			_NBSP_	= '&nbsp;';		// Leeres Feld

	// Zustandsfilter ›importieren‹
	var	alarmStates			= p.alarmStates,
			preAlarmStates	= p.preAlarmStates,
			remAlarmStates	= p.remAlarmStates,
			workingStates		= p.workingStates;

	// SoftLimit-Daten ›importieren‹
	var	softLimit	= p.softLimit;

	// Zähler
	var	n,pillarCount,
			segmentsPerPillar	= [];

	// Flags, Status- und Typkennungen
	var	pumpHasAlarm,pumpHasPrealarm,pumpHasRemalarm,
			stateVar,pumpType,
			pumpWorkingState	= 0;

	// Ausgabemeldungen und Label
	var	alarmDesc,preAlarmDesc,remAlarmDesc,
			pumpStateDesc,pumpTypeDesc;

	// Pumpensymbol
	var	pumpIcon;

	// Nutzdaten (rein alphabetisch)
	var	alarmText,doserate,drugname,
			infrate,infrtime,infvol,slotid;

	// StatusView-Liste und -Zähler
	var statusView	= [],
			i						= 0,
			vis					= false;

	// Benötigte Systemdaten ermitteln …
	pillarCount	= parseInt( systemdata.numpillars,10 );
	for( pillar=0; pillar<pillarCount; pillar++ ) {
		segmentsPerPillar[pillar] = parseInt( systemdata.numsegperpillar[pillar],10 );
	}	// for…


	/* Aktuelle Daten erheben */

	// Iteration über Säulen
	for( pillar=0; pillar<pillarCount; ++pillar ) {

		// Iteration über Segmente
		for( segment=0; segment<segmentsPerPillar[pillar]; ++segment ) {

			// Iteration über Pumpen-Slots
			for( pump=0; pump<=maxpump; ++pump ) {
				// Pumpendaten systematisch ermitteln

				// Beschreibungs- und Klassenfelder
				// leeren, Flags zurücksetzen
				alarmDesc				=
				preAlarmDesc		=
				remAlarmDesc		=
				pumpStateDesc		=
				pumpTypeDesc		= '';
				pumpHasAlarm		=
				pumpHasPrealarm	=
				pumpHasRemalarm	= false;

				// Betriebszustand ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].status,10 );
				if( isNaN( stateVar )) {
					pumpWorkingState	= 0;
				} else {
					statusView[i]			= {};	// StatusView-Listeneintrag vorbereiten
					pumpWorkingState	= 1;
					pumpStateDesc			= msg.stat_OFF;

					// Sukzessive den exakten Betriebsstatus ermitteln
					if( p.workingStates.SYSTEMACTIVE == (stateVar & p.workingStates.SYSTEMACTIVE) ) {
						pumpWorkingState	= 2;
						pumpStateDesc			= msg.stat_SYSTEMACTIVE;
					}	// if…

					if( p.workingStates.STANDBY == (stateVar & p.workingStates.STANDBY) ) {
						pumpWorkingState	= 3;
						pumpStateDesc			= msg.stat_STANDBY;
					}	// if…

					if( p.workingStates.RUN == (stateVar & p.workingStates.RUN) ) {
						pumpWorkingState	= 4;
						pumpStateDesc			= msg.stat_RUN;
					}	// if…

					// Zusätzliche Stati
					if( p.workingStates.MAINS == (stateVar & p.workingStates.MAINS) ) {
						pumpStateDesc += _SEP_ + msg.stat_MAINS;
					}	// if…

					if( p.workingStates.TPYBEGUN == (stateVar & p.workingStates.TPYBEGUN) ) {
						pumpStateDesc += _SEP_ + msg.stat_TPYBEGUN;
					}	// if…

					if( p.workingStates.MANBOL == (stateVar & p.workingStates.MANBOL) ) {
						pumpStateDesc += _SEP_ + msg.stat_MANBOL;
					}	// if…

					if( p.workingStates.VOLBOL == (stateVar & p.workingStates.VOLBOL) ) {
						pumpStateDesc += _SEP_ + msg.stat_VOLBOL;
					}	// if…

					if( p.workingStates.KVOACTIVE == (stateVar & p.workingStates.KVOACTIVE) ) {
						pumpStateDesc += _SEP_ + msg.stat_KVOACTIVE;
					}	// if…

					if( p.workingStates.DATALOCK == (stateVar & p.workingStates.DATALOCK) ) {
						pumpStateDesc += _SEP_ + msg.stat_DATALOCK;
					}	// if…

					if( p.workingStates.DOSIS == (stateVar & p.workingStates.DOSIS) ) {
						pumpStateDesc += _SEP_ + msg.stat_DOSIS;
					}	// if…

					if( p.workingStates.ALARMACTUALQUIT == (stateVar & p.workingStates.ALARMACTUALQUIT) ) {
						pumpStateDesc += _SEP_ + msg.stat_ALARMACTUALQUIT;
					}	// if…

					if( p.workingStates.PREALARMACTUALQUIT == (stateVar & p.workingStates.PREALARMACTUALQUIT) ) {
						pumpStateDesc += _SEP_ + msg.stat_PREALARMACTUALQUIT;
					}	// if…

					if( p.workingStates.AIRSENSOROFF == (stateVar & p.workingStates.AIRSENSOROFF) ) {
						pumpStateDesc += _SEP_ + msg.stat_AIRSENSOROFF;
					}	// if…
				}	// if( isNaN( stateVar )) else

				// Erinnerungsalarmstatus ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].remalarm,10 );
				if( !isNaN( stateVar )) {
					pumpHasRemalarm = (stateVar > 0);
					switch( stateVar ) {
						case remAlarmStates.NOREMALARM:
							remAlarmDesc = '';
							break;
						case remAlarmStates.EDIT:
						case remAlarmStates.CONFIG_MENUE:
						case remAlarmStates.DEFAULT_MENUE:
							remAlarmDesc = msg.RemAlarm_IS_ACTIVE;
							break;
						default:
							remAlarmDesc = msg.RemAlarm_UNKNOWN;
							break;
					}	// switch
				}	// if( !isNaN( stateVar ))

				// Voralarmstatus ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].prealarm,10 );
				if( isNaN( stateVar )) {
					if( pumpWorkingState ) {
						preAlarmDesc = msg.preAlarm_NOPREALARM;
					}	// if…
				} else {
					if( stateVar == 0 ) {
						preAlarmDesc = msg.preAlarm_NOPREALARM;
					} else {
						// Pumpe im Voralarmstatus
						pumpHasPrealarm = true;

						if( preAlarmStates.DISPOSABLE == (stateVar & preAlarmStates.DISPOSABLE) ) {
							preAlarmDesc += (preAlarmDesc.length ? _SEP_ + msg.preAlarm_DISPOSABLE : msg.preAlarm_DISPOSABLE);
						}	// if…

						if( preAlarmStates.VTBD == (stateVar & preAlarmStates.VTBD) ) {
							preAlarmDesc += (preAlarmDesc.length ? _SEP_ + msg.preAlarm_VTBD : msg.preAlarm_VTBD);
						}	// if…

						if( preAlarmStates.TIME == (stateVar & preAlarmStates.TIME) ) {
							preAlarmDesc += (preAlarmDesc.length ? _SEP_ + msg.preAlarm_TIME : msg.preAlarm_TIME);
						}	// if…

						if( preAlarmStates.ACCU == (stateVar & preAlarmStates.ACCU) ) {
							preAlarmDesc += (preAlarmDesc.length ? _SEP_ + msg.preAlarm_ACCU : msg.preAlarm_ACCU);
						}	// if…

						if( preAlarmStates.KOR == (stateVar & preAlarmStates.KOR) ) {
							preAlarmDesc += (preAlarmDesc.length ? _SEP_ + msg.preAlarm_KOR : msg.preAlarm_KOR);
						}	// if…

						// Unbekannter Voralarmtyp
						preAlarmDesc += (preAlarmDesc.length ? '' : msg.preAlarm_UNKNOWN);

						// Voralarm labeln
						preAlarmDesc = (preAlarmDesc.length ? msg.preAlarm_Label + ' ' +preAlarmDesc : '');
					}	// if( stateVar == 0 )…else…
				}	// if( isNaN( stateVar ))…else…

				// Alarmstatus ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].alarm,10 );
				if( isNaN( stateVar )) {
					if( pumpWorkingState ) {
						alarmDesc = msg.Alarm_NOALARM;
					}	// if…
				} else {
					if( stateVar == 0 ) {
						alarmDesc = msg.Alarm_NOALARM;
					} else {
						// Pumpe im Alarmstatus
						pumpHasAlarm = true;

						if( alarmStates.CALDATA == (stateVar & alarmStates.CALDATA) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_CALDATA : msg.Alarm_CALDATA);
						}	// if…

						if( alarmStates.ACCU == (stateVar & alarmStates.ACCU) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_ACCU : msg.Alarm_ACCU);
						}	// if…

						if( alarmStates.TPYDATA == (stateVar & alarmStates.TPYDATA) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_TPYDATA : msg.Alarm_TPYDATA);
						}	// if…

						if( alarmStates.TPYANDPUMPDATA == (stateVar & alarmStates.TPYANDPUMPDATA) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_TPYANDPUMPDATA : msg.Alarm_TPYANDPUMPDATA);
						}	// if…

						if( alarmStates.ACCUVOLTAGE == (stateVar & alarmStates.ACCUVOLTAGE) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_ACCUVOLTAGE : msg.Alarm_ACCUVOLTAGE);
						}	// if…

						if( alarmStates.NOACCU == (stateVar & alarmStates.NOACCU) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_NOACCU : msg.Alarm_NOACCU);
						}	// if…

						if( alarmStates.ACCU_EMPTY == (stateVar & alarmStates.ACCU_EMPTY) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_ACCU_EMPTY : msg.Alarm_ACCU_EMPTY);
						}	// if…

						if( alarmStates.ACCUCOVER == (stateVar & alarmStates.ACCUCOVER) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_ACCUCOVER : msg.Alarm_ACCUCOVER);
						}	// if…

						if( alarmStates.SYREND == (stateVar & alarmStates.SYREND) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_SYREND : msg.Alarm_SYREND);
						}	// if…

						if( alarmStates.PRESSURE == (stateVar & alarmStates.PRESSURE) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_PRESSURE : msg.Alarm_PRESSURE);
						}	// if…

						if( alarmStates.SMBLOCK == (stateVar & alarmStates.SMBLOCK) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_SMBLOCK : msg.Alarm_SMBLOCK);
						}	// if…

						if( alarmStates.STANDBY == (stateVar & alarmStates.STANDBY) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_STANDBY : msg.Alarm_STANDBY);
						}	// if…

						if( alarmStates.VOLEND == (stateVar & alarmStates.VOLEND) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_VOLEND : msg.Alarm_VOLEND);
						}	// if…

						if( alarmStates.TIMEEND == (stateVar & alarmStates.TIMEEND) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_TIMEEND : msg.Alarm_TIMEEND);
						}	// if…

						if( alarmStates.SYRCLAW == (stateVar & alarmStates.SYRCLAW) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_SYRCLAW : msg.Alarm_SYRCLAW);
						}	// if…

						if( alarmStates.KPS == (stateVar & alarmStates.KPS) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_KPS : msg.Alarm_KPS);
						}	// if…

						if( alarmStates.SYRHOLD == (stateVar & alarmStates.SYRHOLD) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_SYRHOLD : msg.Alarm_SYRHOLD);
						}	// if…

						if( alarmStates.SYRAXIAL == (stateVar & alarmStates.SYRAXIAL) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_SYRAXIAL : msg.Alarm_SYRAXIAL);
						}	// if…

						if( alarmStates.KVOEND == (stateVar & alarmStates.KVOEND) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_KVOEND : msg.Alarm_KVOEND);
						}	// if…

						if( alarmStates.BAGEMPTY == (stateVar & alarmStates.BAGEMPTY) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_BAGEMPTY : msg.Alarm_BAGEMPTY);
						}	// if…

						if( alarmStates.TEMPERATURE == (stateVar & alarmStates.TEMPERATURE) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_TEMPERATURE : msg.Alarm_TEMPERATURE);
						}	// if…

						if( alarmStates.DRIP == (stateVar & alarmStates.DRIP) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_DRIP : msg.Alarm_DRIP);
						}	// if…

						if( alarmStates.NODROP == (stateVar & alarmStates.NODROP) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_NODROP : msg.Alarm_NODROP);
						}	// if…

						if( alarmStates.LESSDROPS == (stateVar & alarmStates.LESSDROPS) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_LESSDROPS : msg.Alarm_LESSDROPS);
						}	// if…

						if( alarmStates.MANYDROPS == (stateVar & alarmStates.MANYDROPS) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_MANYDROPS : msg.Alarm_MANYDROPS);
						}	// if…

						if( alarmStates.FREEFLOW == (stateVar & alarmStates.FREEFLOW) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_FREEFLOW : msg.Alarm_FREEFLOW);
						}	// if…

						if( alarmStates.DRIPDISCONNECT == (stateVar & alarmStates.DRIPDISCONNECT) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_DRIPDISCONNECT : msg.Alarm_DRIPDISCONNECT);
						}	// if…

						if( alarmStates.AIR == (stateVar & alarmStates.AIR) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_AIR : msg.Alarm_AIR);
						}	// if…

						if( alarmStates.AIRBUBBLE == (stateVar & alarmStates.AIRBUBBLE) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_AIRBUBBLE : msg.Alarm_AIRBUBBLE);
						}	// if…

						if( alarmStates.AIRRATE == (stateVar & alarmStates.AIRRATE) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_AIRRATE : msg.Alarm_AIRRATE);
						}	// if…

						if( alarmStates.NOAIRTEST == (stateVar & alarmStates.NOAIRTEST) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_NOAIRTEST : msg.Alarm_NOAIRTEST);
						}	// if…

						if( alarmStates.CONTEND == (stateVar & alarmStates.CONTEND) ) {
							alarmDesc += (alarmDesc.length ? _SEP_ + msg.Alarm_CONTEND : msg.Alarm_CONTEND);
						}	// if…

						// Unbekannter Alarmtyp
						alarmDesc += (alarmDesc.length ? '' : msg.Alarm_UNKNOWN);

						// Alarm labeln
						alarmDesc = (alarmDesc.length ? (msg.Alarm_Label + ' ' + alarmDesc) : '');
					}	// if( stateVar == 0 )…else…
				}	// if( isNaN( stateVar ))…else…

				// Pumpentyp ermitteln
				if( pumpWorkingState && (pumpdata[pillar][segment][pump].software != null) ) {
					pumpType = pumpdata[pillar][segment][pump].software.substr( 1,2 );
					switch( pumpType ) {
						case '86':	// Infusomat
							pumpTypeDesc	= msg.lbl_LegendPumpInfusomat;
							break;

						case '87':	// Infusomat P
							pumpTypeDesc	= msg.lbl_LegendPumpInfusomat + ' P';
							break;

						case '88':	// Perfusor
							pumpTypeDesc	= msg.lbl_LegendPumpPerfusor;
							break;

						default:	// Unbekannt oder falsch
							pumpTypeDesc	=
							pumpIcon			= '';
							break;
					}	// switch()

					if( pumpTypeDesc != '' ) {
						pumpIcon	= templates.pumpIcon
													.replace( /\$desc/g,pumpTypeDesc )
													.replace( /\$type/,pumpType );
					}	// if( pumpTypeDesc… )…
				}	// if( pumpWorkingState… )…


				// SoftLimit-Status ermitteln
				softLimit.currstate = 0;	// Soft Limit-Momentandaten
				softLimit.currimg = '';		// zurücksetzen
				softLimit.showshort = (softLimit.notation == 's' && pCF.pageType == 'status');	// Kurzname anzeigen
				stateVar = parseInt( pumpdata[pillar][segment][pump].SLstatus );
				if( (!isNaN( stateVar )) && ( stateVar != 0 ) ) {	
					softLimit.currstate = stateVar;
					softLimit.currimg = softLimit.img.replace( /\$state/,softLimit.currstate );
				}	// if( !isNaN( stateVar ))


				// Nutzdaten zusammenstellen
				if( pumpWorkingState ) {
					doserate		= (pumpdata[pillar][segment][pump].doserate != null ? pumpdata[pillar][segment][pump].doserate : _NBSP_);
					drugconcent	= (pumpdata[pillar][segment][pump].drugconcent != null ? pumpdata[pillar][segment][pump].drugconcent : _NBSP_);
					drugname		= (pumpdata[pillar][segment][pump].drugname != null ? pumpdata[pillar][segment][pump].drugname : _NBSP_);
					drugcolor		= (pumpdata[pillar][segment][pump].drugcolor != null ? pumpdata[pillar][segment][pump].drugcolor : (drugname != _NBSP_) ? '0' : '');
					infrate			= (pumpdata[pillar][segment][pump].infrate != null ? pumpdata[pillar][segment][pump].infrate : _NBSP_);
					pumpdrug		= "#p #s #d #c"
													.replace( /#p/,pumpIcon )
													.replace( /#s/,softLimit.currimg ).replace( /\$imgsz/,'b' )
													.replace( /#d/,drugname )
													.replace( /#c/,drugconcent );


					// Erweiterte Felder berücksichtigen
					if( p.statusView == -1 ) {
						infvol	= (pumpdata[pillar][segment][pump].infvol != null ? pumpdata[pillar][segment][pump].infvol : _NBSP_);
						// Remaining Time:
						if( parseFloat( pumpdata[pillar][segment][pump].syrremtime )) {
							// Minimum aus eingegebener Infusionsrestzeit,
							// Spritzenrestlaufzeit (Perfusor)
							// und ggf. Standby-Restzeit
							infrtime	= getRemTime(
													pumpdata[pillar][segment][pump].infrtime,
													pumpdata[pillar][segment][pump].syrremtime,
													pumpdata[pillar][segment][pump].timestbyremain
												);
						} else if( parseFloat( pumpdata[pillar][segment][pump].infrvol ) &&
												parseFloat( pumpdata[pillar][segment][pump].infrate )) {
							// Minimum aus eingegebener Infusionsrestzeit,
							// kalkulierter Restlaufzeit (Infusomat)
							// und ggf. Standby-Restzeit
							infrtime	= getRemTime(
													pumpdata[pillar][segment][pump].infrtime,
													'# h'.replace( /#/,parseFloat( pumpdata[pillar][segment][pump].infrvol )/parseFloat( pumpdata[pillar][segment][pump].infrate )),
													pumpdata[pillar][segment][pump].timestbyremain
												);
						} else {
							// Ggf. Standby-Restzeit
							infrtime	= getRemTime(
													pumpdata[pillar][segment][pump].infrtime,
													null,
													pumpdata[pillar][segment][pump].timestbyremain
												);
						}	// if…
					}	// if…

					// Alarmtext festlegen
					if( pumpHasAlarm && pumpHasPrealarm && pumpHasRemalarm ) {
						alarmText = remAlarmDesc + _SEP_ + alarmDesc + _SEP_ + preAlarmDesc;
					} else if( pumpHasAlarm && pumpHasRemalarm ) {
						alarmText = remAlarmDesc + _SEP_ + alarmDesc;
					} else if( pumpHasAlarm && pumpHasPrealarm ) {
						alarmText = alarmDesc + _SEP_ + preAlarmDesc;
					} else if( pumpHasPrealarm && pumpHasRemalarm ) {
						alarmText = remAlarmDesc + _SEP_ + preAlarmDesc;
					} else if( pumpHasAlarm ) {
						alarmText = alarmDesc;
					} else if( pumpHasPrealarm ) {
						alarmText = preAlarmDesc;
					} else if( pumpHasRemalarm ) {
						alarmText = remAlarmDesc;
					} else {
						alarmText = '';
					}	// if…else if…else…

					// Laufende SlotID ermitteln:
					//	Zählung beginnt im untersten Slot
					//	des untersten Segments der Säule 0
					//	bei ›1‹.
					slotid = 1 + pump + (1 + maxpump) * (segment + (pillar==0 ? 0 : pillar==1 ? segmentsPerPillar[0] : pillar==2 ? (segmentsPerPillar[0] + segmentsPerPillar[1]) : 0));

					// StatusView-Liste zusammenstellen
					statusView[i].alarmtext		= alarmText.length ? alarmText.replace( /<strong>/g,'' ).replace( /<\/strong>/g,'' ) : '';
					statusView[i].doserate		= doserate;
					statusView[i].drugcolor		= (pumpWorkingState>1) ? drugcolor : '';
					statusView[i].drugconcent	= drugconcent;
					statusView[i].drugname		= drugname;
					statusView[i].infrate			= infrate;
					statusView[i].pump				= pumpType;
					statusView[i].pumpdrug		= pumpdrug;
					statusView[i].slotid			= slotid;
					statusView[i].statedesc		= pumpStateDesc;
					statusView[i].statuscolor = (pumpHasAlarm ? 11 : (pumpHasPrealarm || pumpHasRemalarm) ? 10 : pumpWorkingState);

					// Erweiterte Felder berücksichtigen
					if( p.statusView == -1 ) {
						statusView[i].infrtime	= infrtime;
						statusView[i].infrtmstr	= (infrtime>1/60) ? strTime( infrtime,'hh:mm h' ) : (infrtime>0) ? '≤00:01 h' : _NBSP_;
						statusView[i].infvol		= infvol;
					}	// if…

					// Zähler der StatusView-Liste erhöhen
					i += 1;
				}	// if( pumpWorkingState )

			}	// for( pump… )
		}	// for( segment… )
	}	// for( pillar… )

	// Prüfen, ob ContentFrame bereits geladen
	if( typeof pCF.pageType == 'string' ) {

		// StatusView-Liste sortieren
		for( var idx=0; idx<statusViewSort.curr.length; ++idx ) {
			statusView = statusView.sort( statusViewSort.method[statusViewSort.curr[idx]] );
			if( statusViewSort.desc[idx] ) {
				statusView.reverse();	// Sortierung umkehren
			}	// if…
		}	// for…

		for( var rowNum=0; rowNum<24; ++rowNum ) {
			vis = 'concealed';

			if( statusView[rowNum] ) {
				// Zuweisung von CSS-Klassen
				pCF.pushData( 'out_status_'+rowNum,'status_coat status-'+statusView[rowNum].statuscolor,'className' );
				if( statusView[rowNum].drugcolor.length && statusView[rowNum].drugname.length) {
					pCF.pushData( 'out_pumpdrug_'+rowNum,'stv-font drugcolor-'+statusView[rowNum].drugcolor,'className' );
				} else {
					pCF.pushData( 'out_pumpdrug_'+rowNum,'stv-font','className' );
				}	// if…

				// Datenausgabe in title
				if( statusView[rowNum].statedesc.length ) {
					pCF.pushData( 'out_status_'+rowNum,statusView[rowNum].statedesc,'title' );
				}	// if…
				if( statusView[rowNum].alarmtext.length ) {
					pCF.pushData( 'out_pumpdrug_'+rowNum,statusView[rowNum].alarmtext,'title' );
				}	// if…

				// Datenausgabe
				pCF.pushData( 'out_slotid_'+rowNum,statusView[rowNum].slotid );
				pCF.pushData( 'out_pumpdrug_'+rowNum,statusView[rowNum].pumpdrug );
				pCF.pushData( 'out_infratestr_'+rowNum,statusView[rowNum].infrate );
				pCF.pushData( 'out_doseratestr_'+rowNum,statusView[rowNum].doserate );
				if( p.statusView == -1 ) {
						pCF.pushData( 'out_infvolstr_'+rowNum,statusView[rowNum].infvol );
						pCF.pushData( 'out_remtimestr_'+rowNum,statusView[rowNum].infrtmstr );
				}	// if…
				vis = 'revealed';
			}	// if( statusView[rowNum] )

			// Listenzeile ein-/ausblenden
			pCF.pushData( 'row_'+rowNum,vis,'className' );
		}	// for( var row=0;… )

		// Erweiterte Felder ein-/ausblenden
		extendedView();
	}	// if( typeof pCF.pageType == 'string' )

	// Standard-Statuszeile wieder herstellen
	window.status = window.defaultStatus;

	// Flag: Aktualisierung beendet
	p.feedingIsInProgress = false;
}	// function feedData()

function switchStatusView() {

	if( typeof p.statusView != 'number' ) {
		return;
	}	// if…

	p.statusView *= -1;

	// Erweiterte Felder ein-/ausblenden
	extendedView();

	pCF.document.getElementById( 'stv-switch' ).blur();
	pCF.document.getElementById( 'stv-switch' ).className = 'rubric-toggle ' + ((p.statusView<0) ? 'hide' : 'show');
}	// function switchStatusView()

function extendedView() {
// Umschaltung zwischen normaler
// und erweiterter Stausliste

		if( typeof pCF.pageType != 'string' ) {
			return;
		}	// if…

		var	width	= (p.statusView==-1) ? '800px' : '390px',
				vis		= (p.statusView==-1) ? 'revealed' : 'concealed';

		// ContentShell in der Breite verändern
		var contentshell = pCF.document.getElementById( 'contentshell' );
		if (contentshell) {
			contentshell.style.width	=
			contentshell.style.minWidth	= width;
		}

		// Erweiterte Felder ein-/ausblenden
		pCF.pushData( 'infvol','stv-font ' + vis,'className' );
		pCF.pushData( 'remtime','stv-font ' + vis,'className' );
		for( var rowNum=0;rowNum<24;++rowNum ) {
			pCF.pushData( 'out_infvolstr_'+rowNum,'stv-font right ' + vis,'className' );
			pCF.pushData( 'out_remtimestr_'+rowNum,'stv-font right ' + vis,'className' );
		}	// for…
}	// function extendedView()

function num2str( num, dec, dig, decchar ) {
	// Formatiert eine übergebene Zahl
	// als String gemäß der Parameter:
	//	dig:			Vordezimalstellen
	//	dec:			Dezimalstellen
	//	decchar:	Dezimalzeichen

	if(typeof num=='number') {
		var neg=num<0;
		if(typeof dec=='number')
			dec=Math.abs( dec );
		else
			dec=0;
		num=String( parseFloat( Math.round( Math.abs( num )*Math.pow( 10,dec ) )/Math.pow( 10,dec ) ));
		if(dec&&num.indexOf( '.' )==-1)
			num+='.';
		var l=dec-(num.substring( num.indexOf( '.' ),num.length )).length;
		for(var d=0;d<=l;d++)
			num+='0';
		if(typeof decchar!='string')
			decchar='.';
		if(decchar!='.')
			num=num.replace( /\./,decchar );

		if(typeof dig=='number') {
			if(dig=dig<0?1:dig) {
				var l=num.indexOf( decchar )>-1?(num.substring( 0,num.indexOf( decchar ))).length:num.length;
				for(var i=l;i<dig;i++)
					num='0'+num;
			}
		}
		if(neg)
			num='-'+num;
	}
	return num;
}	//function num2str( num, dec, dig, decchar )

function strTime( h,tmFmt ) {
// Formatiert eine in Stunden übergebene Zeit
// in einen festlegbaren Ausgabestring

	var	retStr='';

	if( typeof h == 'number' ) {
		if( typeof tmFmt != 'string' )
			tmFmt = 'hh:mm';
		var	hh = Math.floor( h ),
				mm = Math.floor( (h-hh)*60 ),
				ss = Math.round( ((h-hh)*60-mm)*60 );

		retStr = tmFmt;

		if( hh>=1 && retStr.indexOf( 'hh' )==-1 && retStr.indexOf( '_h' )==-1 ) {
			mm += hh*60;
			hh = 0;
			if( mm>=1 && retStr.indexOf( 'mm' )==-1 && retStr.indexOf( '_m' )==-1 ) {
				ss += mm*60;
				mm = 0;
				if( retStr.indexOf( 'ss' )==-1 && retStr.indexOf( '_s' )==-1 )
					retStr = '_s s';
			}	// if( mm>=1...
		}	// if( hh>=1...

		retStr = retStr.replace( /hh/,num2str( hh,0,2 ));
		retStr = retStr.replace( /_h/,hh );

		retStr = retStr.replace( /mm/,num2str( mm,0,2 ));
		retStr = retStr.replace( /_m/,mm );

		retStr = retStr.replace( /ss/,num2str( ss,0,2 ));
		retStr = retStr.replace( /_s/,ss );
	}	// if( typeof h
	return retStr;
}	// function strTime()

function getRemTime( infrtime,syrremtime,timestbyremain ) {
// Restzeit als Minimum der eingestellten Infusionszeit,
// der kalkulierten Restlaufzeit und der Standby-Restzeit ermitteln

	if( infrtime ) {
		switch( true ) {
			case (infrtime.indexOf( 'h' )>-1):
				infrtime = parseFloat( infrtime );
				break;
			case (infrtime.indexOf( 'm' )>-1):
				infrtime = parseFloat( infrtime )/60;
				break;
			case (infrtime.indexOf( 's' )>-1):
				infrtime = parseFloat( infrtime )/3600;
				break;
			default:
				infrtime = -1;
		}	// switch
	} else {
		infrtime = -1;
	}

	if( syrremtime ) {
		switch( true ) {
			case (syrremtime.indexOf( 'h' )>-1):
				syrremtime = parseFloat( syrremtime );
				break;
			case (syrremtime.indexOf( 'm' )>-1):
				syrremtime = parseFloat( syrremtime )/60;
				break;
			case (syrremtime.indexOf( 's' )>-1):
				syrremtime = parseFloat( syrremtime )/3600;
				break;
			default:
				syrremtime = -1;
		}	// switch
	} else {
		syrremtime = -1;
	}

	if( timestbyremain ) {
		switch( true ) {
			case (timestbyremain.indexOf( 'h' )>-1):
				timestbyremain = parseFloat( timestbyremain );
				break;
			case (timestbyremain.indexOf( 'm' )>-1):
				timestbyremain = parseFloat( timestbyremain )/60;
				break;
			case (timestbyremain.indexOf( 's' )>-1):
				timestbyremain = parseFloat( timestbyremain )/3600;
				break;
			default:
				timestbyremain = -1;
		}	// switch
	} else {
		timestbyremain = -1;
	}

	switch( true ) {
		case (infrtime>0 && syrremtime>0 && timestbyremain>0):
			return Math.min( Math.min( infrtime,syrremtime ),timestbyremain );
		case (infrtime>0 && syrremtime>0):
			return Math.min( infrtime,syrremtime );
		case (infrtime>0 && timestbyremain>0):
			return Math.min( infrtime,timestbyremain );
		case (syrremtime>0 && timestbyremain>0):
			return Math.min( syrremtime,timestbyremain );
		default:
			return( (infrtime>0) ? infrtime : (syrremtime>0) ? syrremtime : (timestbyremain>0) ? timestbyremain : 0 );
	}	// 	switch( true )
}	// function getRemTime()


/*******************
 * Code-Ausführung *
 *******************/
// Initialisierung der Daten-Arrays durchführen
initSystemData();
initPumpData();
