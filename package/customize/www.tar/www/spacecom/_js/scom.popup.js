﻿/****************************************************************
 * JavaScript-Popup-Management für Projekt:					 						*
 * SpaceOnline BBraun.com																				*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-07, 08, 09																	*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * Version: 1.2.0																								*
 * Autor: B2A/koe																								*
 * Letzte Bearbeitung: 2005-09-21 09:57													*
 * durch: Koe																										*
 ****************************************************************/

function popup( pid ) {
/**********************************************************
 * Funktion öffnet bzw. setzt den Fokus auf ein in der		*
 * Liste vorparametrisertes Fenster.											*
 * Achtung: Die aufrufende Seite muss eine globale Variab-*
 * le mit dem Namen des Popups und führendem Unterstrich	*
 * deklarieren -- etwa `_popupname´.											*
 *--------------------------------------------------------*
 * Parameter:																							*
 *	pid: Popup-Id bzw. Name																*
 *--------------------------------------------------------*
 * Rückgabe:																							*
 *	- keine -																							*
 **********************************************************/
var ok=true,
		_popup=new Array();

	_popup.id = eval( '_'+pid );

	// Standard-Fensterparameter
	_popup.par = "left=50,top=50,dependent=yes,location=no,menubar=no,resizable=no,scrollbars=no,status=yes,toolbar=no,";

	// Individuelle Fensterparameter für pid festlegen
	switch( pid ) {
		case 'help':
			_popup.url=locale+"\/scom_p.help.html";
			_popup.par+="width=464,height=400";
			break;
		default:
			window.alert( "Fehler:\tPopUp-Fenster '"+pid+"' kann nicht geöffnet werden -- fehlende Daten.\n\nError:\tUnable to open pop up window '"+pid+"' -- missing data!" );
			ok=false;
		break;
	}	// switch()

	if(ok) {
		if(!_popup.id||_popup.id.closed)
			_popup.id=window.open( _popup.url,pid,_popup.par );
		else
			_popup.id.focus();

		eval( '_'+pid+'=_popup.id;' );
	}
}
