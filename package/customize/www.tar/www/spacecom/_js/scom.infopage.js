﻿/****************************************************************
 * JavaScript-Funktionen für Projekt														*
 * SpaceOnline BBraun.com: Service Information									*
 * Copyright (c) 2003,2006 des Menü-Layouts by BBMAG						*
 * Copyright (c) 2004,2006 des Codes by B2A Corporate Marketing	*
 * All rights reserved																					*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2006-01																					*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * Version: -																										*
 * Autor: B2A/Koe																								*
 * Letzte Bearbeitung: 2006-01-20 11:35													*
 * durch: Koe																										*
 ****************************************************************/

function subPanel( id,excl,set ) {
// Informationsfeld ein-/ausblenden, Button-Grafik
// entsprechend tauschen und Titeltext anpassen
//
// Parameter:
//	id:			Element-Id des Button-Links
//	excl:		Flag (fakultativ): Angeklicktes Infofeld exklusiv öffnen?
//					Default: true (mutually exclusive)
//	set:		Schalter (fakultativ): Zustand direkt setzen

	// Id verarbeiten und kontrollieren
	var	tmp = id.split( '_' );
	if( tmp[0] == 'btn' && tmp[1].length )
		id = tmp[1];
	else
		id = false;

	// Falls passende Id übergeben wurde ...
	if( id ) {

		excl = typeof excl != 'boolean' ? true : excl;	// Mutual exclusivity-Flag per Default setzen

		subPanels[id] = typeof set == 'boolean' ? set : !subPanels[id];	// Zustand des angeklickten Infofelds direkt setzen oder umkehren

		if( excl && subPanels[id] )	// Falls Mutual exclusivity-Flag gesetzt und Infofeld geöffnet:
			for( var e in subPanels )	// Alle
				if( e != id )						// anderen Infofelder
					subPanels[e] = false;	// schließen

		for( var e in subPanels ) {	// Alle Informationsfelder ...
			if( document.getElementById( 'subpanel_' + e ))
				document.getElementById( 'subpanel_' + e ).style.display = subPanels[e] ? 'block' : 'none';	// ... zeigen bzw. verbergen, ...
			if( document.getElementById( 'img_' + e )) {
				tmp = document.getElementById( 'img_' + e ).src;
				document.getElementById( 'img_' + e ).src = subPanels[e] ? tmp.replace( /plus/,'minus' ) : tmp.replace( /minus/,'plus' )	// ... mit Button-Grafik ...
			}
			if( document.getElementById( 'btn_' + e ))
				document.getElementById( 'btn_' + e ).title = msg.subPanel.replace( /\$verb/, subPanels[e] ? msg.verbClose : msg.verbOpen );	// ... und Titeltext ausstatten
		}	// for(...)
	}	// if( id )
}	// function subPanel()

function pushData( id,dta,attr ) {
// Schiebt Daten in ein bestimmtes Elementattribut
//
// Parameter:
//	id:			Id des Elements
//	dta:		zu schiebende Daten
//	attr:		Tag-Attribut des Elements
//					(Default: 'innerHTML')

	var elem = document.getElementById( id );

	if( elem ) {
		attr = typeof attr != 'string' ? 'innerHTML' : attr;

		if( elem[attr] ) {
			elem[attr] = dta;
		}
		else {
			elem.innerHTML = dta;
		}
	}
}	// function pushData()
