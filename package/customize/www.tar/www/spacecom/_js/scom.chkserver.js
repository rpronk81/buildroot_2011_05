﻿/****************************************************************
 * JavaScript-Funktionen zum ServerCheck												*
 * Projekt: SpaceOnline, B. Braun Melsungen AG									*
 * Copyright (c)2005,2006 by B. Braun Melsungen AG							*
 * All rights reserved																					*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-05, 2006-02																	*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * Version: 1.0.2																								*
 * Autor: B2A/koe																								*
 * Letzte Bearbeitung: 2006-02-08 14:29													*
 * durch: Koe																										*
 ****************************************************************/

document.writeln("<script type='text/javascript' src='../func/cookie.js'></script>");

function chkServer() {
// Funktion prüft die Existenz und den Zustand
// des Flags `isAlive´ im DataFrame, das Auskunft
// darüber gibt, ob dieser Frame nachgeladen werden
// konnte. Ist dies nicht der Fall, wird eine Warnmeldung
// ausgegeben und der Benutzer kann die Applikation
// neu starten.

var reconnect,
		reconnect_msg,
		connect_state=1;

	if( typeof dataFrame.isAlive == 'undefined' )
		connect_state=0;
	else if(!isAlive)
		connect_state=-1;

	reconnect = (connect_state<1?function(){ location.reload(); }:function(){ /**/ });
	reconnect_msg = (!connect_state?msg[locale].ServerNumb:connect_state==-1?msg[locale].ServerSuspect:msg[locale].OK);

	if( topFrame.document.getElementById( 'connect_state' ))
		topFrame.document.getElementById( 'connect_state' ).className = (!connect_state?'bg_red':connect_state==-1?'bg_orange':'bg_green');

	if( topFrame.document.getElementById( 'reconnect' )) {
		topFrame.document.getElementById( 'reconnect' ).onclick = reconnect;
		topFrame.document.getElementById( 'reconnect' ).alt = reconnect_msg;
	}
	
	if(GetCookie('scomusrnamestatus')!=null || GetCookie('scomusrnameservice')!=null || GetCookie('scomusrnameconfig')!=null)
	{
		topFrame.document.getElementById( 'logout' ).style.visibility = "visible";
	}
	else
	{
		topFrame.document.getElementById( 'logout' ).style.visibility = "hidden";
	}
}

function chkRefreshCycleState( datapool ) {
// Funktion prüft das Alter der Datenpools anhand
// eines Zeitstempels, der von der Server-seitigen
// Aktualisierungsroutine in die Datenpools geschrieben
// wird. Der Zeitstempel muss zwischen zwei Refresh-
// Zyklen um die ebenfalls in die Datenpools geschriebene
// Zeitdifferenz (±100 ms Toleranz) wachsen.
var chkSrv=false,
		prevStamp,currStamp,
		validDiff,currDiff;

	switch( datapool ) {
		case 'pumpdata':
			if( typeof( dataFrame.pumpdata )!='undefined' ) {
				prevStamp=refreshCheck.pumpdata.prevStamp;
				currStamp=parseInt( dataFrame.pumpdata[0][0][0].timestamp );
				validDiff=parseInt( dataFrame.pumpdata[0][0][0].dumpintvl );
				if( prevStamp ) {
					currDiff=Math.abs( Math.abs( currStamp-prevStamp )-validDiff );
					refreshCheck.pumpdata.ok=((currDiff<=100)&&(currStamp!=prevStamp));
				}
				refreshCheck.pumpdata.prevStamp=currStamp;
				if( ! refreshCheck.pumpdata.intvlObj ) {
					refreshCheck.pumpdata.intvlObj=window.setInterval( "chkRefreshCycleState('pumpdata')", 3000 );
				}
			} else
				chkSrv=true;
			break;

		case 'systemdata':
			if( typeof( dataFrame.systemdata )!='undefined' ) {
				prevStamp=refreshCheck.systemdata.prevStamp;
				currStamp=parseInt( dataFrame.systemdata.timestamp );
				validDiff=parseInt( dataFrame.systemdata.dumpintvl );
				if( prevStamp ) {
					currDiff=Math.abs( Math.abs( currStamp-prevStamp )-validDiff );
					refreshCheck.systemdata.ok=((currDiff<=100)&&(currStamp!=prevStamp));
				}
				refreshCheck.systemdata.prevStamp=currStamp;
				if( ! refreshCheck.systemdata.intvlObj ) {
					refreshCheck.systemdata.intvlObj=window.setInterval( "chkRefreshCycleState('systemdata')", 3000 );
				}
			} else
				chkSrv=true;
			break;

		case 'svcpumpdata':
			if( typeof( dataFrame.svcpumpdata )!='undefined' ) {
				prevStamp=refreshCheck.svcpumpdata.prevStamp;
				currStamp=parseInt( dataFrame.svcpumpdata[0][0][0].timestamp );
				validDiff=parseInt( dataFrame.svcpumpdata[0][0][0].dumpintvl );
				if( prevStamp ) {
					currDiff=Math.abs( Math.abs( currStamp-prevStamp )-validDiff );
					refreshCheck.svcpumpdata.ok=((currDiff<=100)&&(currStamp!=prevStamp));
				}
				refreshCheck.svcpumpdata.prevStamp=currStamp;
				if( ! refreshCheck.svcpumpdata.intvlObj ) {
					refreshCheck.svcpumpdata.intvlObj=window.setInterval( "chkRefreshCycleState('svcpumpdata')", 3000 );
				}
			} else
				chkSrv=true;
			break;

		case 'svccoverdata':
			if( typeof( dataFrame.svccoverdata )!='undefined' ) {
				prevStamp=refreshCheck.svccoverdata.prevStamp;
				currStamp=parseInt( dataFrame.svccoverdata[0][0][0].timestamp );
				validDiff=parseInt( dataFrame.svccoverdata[0][0][0].dumpintvl );
				if( prevStamp ) {
					currDiff=Math.abs( Math.abs( currStamp-prevStamp )-validDiff );
					refreshCheck.svccoverdata.ok=((currDiff<=100)&&(currStamp!=prevStamp));
				}
				refreshCheck.svccoverdata.prevStamp=currStamp;
				if(! refreshCheck.svccoverdata.intvlObj ) {
					refreshCheck.svccoverdata.intvlObj=window.setInterval( "chkRefreshCycleState('svccoverdata')", 3000 );
				}
			} else
				chkSrv=true;
			break;

		default:
			chkRefreshCycleState( 'pumpdata' );
			chkRefreshCycleState( 'systemdata' );
			chkRefreshCycleState( 'svcpumpdata' );
			chkRefreshCycleState( 'svccoverdata' );
			break;
	}	// switch( datapool )

	if( topFrame.document.getElementById( 'dataage_state' ))
		topFrame.document.getElementById( 'dataage_state' ).className = ((refreshCheck.pumpdata.ok&&refreshCheck.systemdata.ok&&refreshCheck.svcpumpdata.ok&&refreshCheck.svccoverdata.ok)?'bg_green':(refreshCheck.pumpdata.ok||refreshCheck.systemdata.ok||refreshCheck.svcpumpdata.ok||refreshCheck.svccoverdata.ok)?'bg_orange':'bg_red');

	if( topFrame.document.getElementById( 'dataage' ))
		topFrame.document.getElementById( 'dataage' ).alt = ((refreshCheck.pumpdata.ok&&refreshCheck.systemdata.ok&&refreshCheck.svcpumpdata.ok&&refreshCheck.svccoverdata.ok)?msg[locale].OK:(refreshCheck.pumpdata.ok||refreshCheck.systemdata.ok||refreshCheck.svcpumpdata.ok||refreshCheck.svccoverdata.ok)?msg[locale].ServerDataSuspect:msg[locale].ServerDataAge);

	if( chkSrv )
		chkServer();

}	// function chkRefreshCycleState()
