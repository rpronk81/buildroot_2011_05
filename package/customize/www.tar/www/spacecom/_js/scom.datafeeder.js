﻿/****************************************************************
 * Javascript-Code: DataFeeder																	*
 * Projekt: SpaceOnline, B. Braun Melsungen AG									*
 * Copyright (c) 2005,2006 by B2A Corporate Marketing						*
 * All rights reserved																					*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03,04..09, 2006-01..02,07..09								*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * Version: 1.4.1a																							*
 * Autor: B2A/koe																								*
 * Letzte Bearbeitung: 2006-09-05 09:43													*
 * durch: Koe																										*
 ****************************************************************/
var p=parent,
		msg=p.msg[p.locale],
		pCF=p.contentFrame,

		// Globale Laufvariablen und Schleifengrenzen
		pillar, maxpillar = 2,	// Säule, letzte Säule
		segment, maxsegment = 5,	// Segment, letztes Segment
		pump, maxpump = 3,	// Pumpe, letzte Pumpe

		// Daten-Arrays global deklarieren
		pumpdata = new Array(),
		svccoverdta = new Array(),
		svcpumpdta = new Array(),
		systemdata = new Array(),

		// Code-Templates
		templates = {
			abbrevPumpText:	'<span class="narrow" title="$pumpText">$abbrevPumpText<\/span>',
			pumpLbl:				'<strong>&gt; $lbl<\/strong>',
			shortPumpText:	'<table border="0" cellspacing="0" cellpadding="0"><tr><td>$slimg<\/td><td>$pumptxt<\/td><\/tr><\/table>'
		};

	// Pumpen-, Service- und System-
	// Daten-Arrays initialisieren
	initPumpData();
	initServiceCoverData();
	initServicePumpData();
	initSystemData();

function initPumpData() {
	// Initialisierung der Pumpendaten
	for( pillar=0; pillar<=maxpillar; pillar++ ) {
		pumpdata[pillar] = new Array();
		for( segment=0; segment<=maxsegment; segment++ ) {
			pumpdata[pillar][segment] = new Array();
			for( pump=0; pump<=maxpump; pump++ ) {
				pumpdata[pillar][segment][pump] = new Array();
				pumpdata[pillar][segment][pump].alarm = null;
				pumpdata[pillar][segment][pump].doserate = null;
				pumpdata[pillar][segment][pump].drugconcent = null;
				pumpdata[pillar][segment][pump].drugname = null;
				pumpdata[pillar][segment][pump].infrate = null;
				pumpdata[pillar][segment][pump].infrtime = null;
				pumpdata[pillar][segment][pump].infrvol = null;
				pumpdata[pillar][segment][pump].inftime = null;
				pumpdata[pillar][segment][pump].infvol = null;
				pumpdata[pillar][segment][pump].patbirthday = null;
				pumpdata[pillar][segment][pump].patbirthmonth = null;
				pumpdata[pillar][segment][pump].patbirthyear = null;
				pumpdata[pillar][segment][pump].patgender = null;
				pumpdata[pillar][segment][pump].patid = null;
				pumpdata[pillar][segment][pump].patname = null;
				pumpdata[pillar][segment][pump].patsurname = null;
				pumpdata[pillar][segment][pump].patweight = null;
				pumpdata[pillar][segment][pump].prealarm = null;
				pumpdata[pillar][segment][pump].profiletype = null;
				pumpdata[pillar][segment][pump].serialnumber = null;
				pumpdata[pillar][segment][pump].software = null;
				pumpdata[pillar][segment][pump].status = null;
				pumpdata[pillar][segment][pump].syrname = null;
				pumpdata[pillar][segment][pump].syrvol = null;
				pumpdata[pillar][segment][pump].tubename = null;
				pumpdata[pillar][segment][pump].SLstatus = null;
				pumpdata[pillar][segment][pump].drugnameshort = null;
				pumpdata[pillar][segment][pump].remalarm = null;
			}	// for( pump ... )
		}	// for( segment ... )
	}	// for( pillar ... )
}	// function initPumpData()

function initServiceCoverData() {
	// Initialisierung der SpaceCover-Service-Daten
	for( pillar=0; pillar<=maxpillar; pillar++ ) {
		svccoverdta[pillar] = new Array();
		svccoverdta[pillar][0] = new Array();			// Aus Kompatibilitätsgründen muss auch
		svccoverdta[pillar][0][0] = new Array();	// das Cover-Datenarray 3+1-dimensional sein
		svccoverdta[pillar][99] = new Array();
		svccoverdta[pillar][99][99] = new Array();
		svccoverdta[pillar][99][99].serno = null;
		svccoverdta[pillar][99][99].software = null;
		svccoverdta[pillar][99][99].battophrs = null;
		svccoverdta[pillar][99][99].battstat = null;
		svccoverdta[pillar][99][99].battrtm = null;
		svccoverdta[pillar][99][99].battcap = null;
		svccoverdta[pillar][99][99].battcaptgt = null;
		svccoverdta[pillar][99][99].battchrgstat = null;
		svccoverdta[pillar][99][99].battvoltstat = null;
		svccoverdta[pillar][99][99].battmaintrq = null;
		svccoverdta[pillar][99][99].battmaintdt = null;
	}	// for( pillar ... )
}	// function initServiceCoverData()

function initServicePumpData() {
	// Initialisierung der Pumpen-Service-Daten
	for( pillar=0; pillar<=maxpillar; pillar++ ) {
		svcpumpdta[pillar] = new Array();
		for( segment=0; segment<=maxsegment; segment++ ) {
			svcpumpdta[pillar][segment] = new Array();
			for( pump=0; pump<=maxpump; pump++ ) {
				svcpumpdta[pillar][segment][pump] = new Array();
				svcpumpdta[pillar][segment][pump].wardid = null;
				svcpumpdta[pillar][segment][pump].serno = null;
				svcpumpdta[pillar][segment][pump].software = null;
				svcpumpdta[pillar][segment][pump].dtalcklvl = null;
				svcpumpdta[pillar][segment][pump].ophrs = null;
				svcpumpdta[pillar][segment][pump].motorsteps = null;
				svcpumpdta[pillar][segment][pump].totvoldeliv = null;
				svcpumpdta[pillar][segment][pump].dispchgs = null;
				svcpumpdta[pillar][segment][pump].startcnt = null;
				svcpumpdta[pillar][segment][pump].ratemax = null;
				svcpumpdta[pillar][segment][pump].ratemin = null;
				svcpumpdta[pillar][segment][pump].bolratedef = null;
				svcpumpdta[pillar][segment][pump].bolratemax = null;
				svcpumpdta[pillar][segment][pump].bolratemin = null;
				svcpumpdta[pillar][segment][pump].dtalckcode = null;
				svcpumpdta[pillar][segment][pump].battophrs = null;
				svcpumpdta[pillar][segment][pump].battstat = null;
				svcpumpdta[pillar][segment][pump].battrtm = null;
				svcpumpdta[pillar][segment][pump].battcap = null;
				svcpumpdta[pillar][segment][pump].battcaptgt = null;
				svcpumpdta[pillar][segment][pump].battchrgstat = null;
				svcpumpdta[pillar][segment][pump].battvoltstat = null;
				svcpumpdta[pillar][segment][pump].battmaintrq = null;
				svcpumpdta[pillar][segment][pump].battmaintdt = null;
			}	// for( pump ... )
		}	// for( segment ... )
	}	// for( pillar ... )
}	// function initServicePumpData()

function initSystemData() {
	// Initialisierung der Systemdaten
	systemdata.stationid = null;
	systemdata.numpillars = 0;
	systemdata.numsegperpillar = new Array();
	for( pillar=0; pillar<=maxpillar; pillar++ )
		systemdata.numsegperpillar[pillar] = 0;
}	// function initSystemData()

function reloadFeeder() {
// Feeder-Frame neu laden
	if( iv )
		window.clearTimeout( iv );
	p.isAlive=false;
	location.reload();
}

function feedData() {
	// Aktualisierungsprozess in Statuszeile melden
	window.status=window.defaultStatus + ' ' + msg.feedingData;

	// Aktualisierungsflag setzen
	p.feedingIsInProgress = true;

/*** Lokale Variable deklarieren und ggf. initialisieren ***/
var	_DASH_	= '&minus;',	// Kein Wert (Strich)
		_SEP_		= '<br \/>',	// Trennung von Meldungen
		_LI_		= '',					// Ende eines Listeneintrags
		_VAIN_	= '&nbsp;';		// Leeres Feld

		// Zustandsfilter `importieren´
var	alarmStates = p.alarmStates,
		alarmStates2 = p.alarmStates2,
		preAlarmStates = p.preAlarmStates,
		remAlarmStates = p.remAlarmStates,
		workingStates = p.workingStates;

		// SoftLimit-Daten `importieren´
var	softLimit = p.softLimit;

		// CSS-Klassen
var	stateCSSClass,typeCSSClass;

		// Zählvariable
var	n,stat,pillarCount,pumpCount=0,segmentCount=0,segmentsPerPillar=new Array();

		// Flags, Status- und Typkennungen
var	patDtaIsValid,pumpHasAlarm,pumpHasPrealarm,pumpHasRemalarm,pumpIsSelected,
		cvComfortIsSelected,stateVar,stateVar2,selectedSlotEquiped,pumpType,pumpWorkingState=0;

		// Ausgabemeldungen und Label
var	alarmDesc,preAlarmDesc,remAlarmDesc,pumpStateDesc,pumpTypeDesc,pumpText;

		// Ausgabedaten für Status- und Service-Infoseiten (rein alphabetisch)
var	battcap,battcaptgt,battchrgstat,battmaintdt,battmaintrq,battophrs,battrtm,battstat,
		battvoltstat,bolratedef,bolratemax,bolratemin,cvbattcap,cvbattcaptgt,cvbattchrgstat,
		cvbattmaintdt,cvbattmaintrq,cvbattophrs,cvbattrtm,cvbattstat,cvbattvoltstat,cvserno,
		cvsw,dtalckcode,dtalcklvl,dispchgs,doserate,drugconcent,drugname,drugnameshort,infrate,
		infrtm,infrvol,inftm,infvol,motorsteps,ophrs,patbirth,patbday,patbmonth,patbyear,
		patgender,patid,patname,patsurname,patweight,proftype,ratemax,ratemin,serialnumber,
		software,startcnt,stationID,syrname,syrvol,totvoldeliv,tubename,wardID,tmpStr;

	if( typeof pCF.pageType == 'string' ) {	// Prüfen, ob contentFrame bereits geladen ...
		// nicht eingeloggt ?
		if (db2jsAuthOk == "False") {
			//
			var locale=p.locale;			
			//auf login weiterleiten falls nicht authentifiziert 3* empfangen wurde
			// puffer notwendig, da evtl. nicht sofort authentifiziert nach login (async update der db2js Dateien)
			pCF.noAuthCnt = pCF.noAuthCnt + 1;
			if (pCF.noAuthCnt > 3) {
				pCF.location.href='./login.php?target='+pCF.pageType+'&locale='+locale;

			}
		} else {
			pCF.noAuthCnt = 0;
		}
	}
	// Systemdaten ermitteln ...
	stationID = systemdata.stationid;
	pillarCount = parseInt( systemdata.numpillars );
	for( pillar=0; pillar<pillarCount; pillar++ ) {
		segmentsPerPillar[pillar] = parseInt( systemdata.numsegperpillar[pillar] );
		segmentCount += segmentsPerPillar[pillar];
	}

	if( typeof pCF.pageType == 'string' ) {	// Prüfen, ob contentFrame bereits geladen ...
		// ... dann Systemdaten ausgeben
		pCF.pushData( 'out_stationid',stationID );
		pCF.pushData( 'out_stationinfo',stationID );
		pCF.pushData( 'out_numpillars',pillarCount ? pillarCount : _DASH_ );
		pCF.pushData( 'out_numsegments',segmentCount ? segmentCount : _DASH_ );
		pCF.pushData( 'out_numsegsperpillar','$p0 | $p1 | $p2'.replace( /\$p0/,segmentsPerPillar[0] ? segmentsPerPillar[0] : _DASH_ ).replace( /\$p1/,segmentsPerPillar[1] ? segmentsPerPillar[1] : _DASH_ ).replace( /\$p2/,segmentsPerPillar[2] ? segmentsPerPillar[2] : _DASH_ ) );

		// SpaceCovers nicht im System vorhandener Säulen
		// sowie nicht im System vorhandene Segmente verbergen
		if( p.isBrowser.moz ) {	// Gecko aktualisiert nur, wenn Hüllebenen verdeckt sind
			if( pCF.document.getElementById( 'spacecover' ))
				pCF.document.getElementById( 'spacecover' ).style.display = 'none';
			if( pCF.document.getElementById( 'sysstruct' ))
				pCF.document.getElementById( 'sysstruct' ).style.display = 'none';
		}	// if( p.isBrowser.moz )

		for( pillar=0; pillar<=maxpillar; pillar++ ) {
			if( pCF.document.getElementById( 'pi'+pillar+'_sg_cv' ))
				pCF.document.getElementById( 'pi'+pillar+'_sg_cv' ).className = pillar<pillarCount ? 'coversegment' : 'coversegment_void';
			for( segment=0; segment<=maxsegment; segment++ )
				if( pCF.document.getElementById( 'pi'+pillar+'_sg'+segment ))
					pCF.document.getElementById( 'pi'+pillar+'_sg'+segment ).className = segment<segmentsPerPillar[pillar] ? 'segment' : 'segment_void';
		}	// for( pillar ... )

		if( p.isBrowser.moz ) {	// Hüllebenen wieder sichtbar machen
			if( pCF.document.getElementById( 'sysstruct' ))
				pCF.document.getElementById( 'sysstruct' ).style.display = 'block';
			if( p.isBrowser.moz && pCF.document.getElementById( 'spacecover' ))
				pCF.document.getElementById( 'spacecover' ).style.display = 'block';
		}	// if( p.isBrowser.moz )

		if( p.isBrowser.moz  ) {	// Gecko kann dynamisch mit automatisch scrollenden <div>s umgehen
			if( pCF.pageType == 'status' ) {
				if( pCF.document.getElementById( 'pumpselected' )) {
					pCF.document.getElementById( 'pumpselected' ).style.height = '';
					pCF.document.getElementById( 'pumpselected' ).style.overflow = '';
				}
				if( pCF.document.getElementById( 'out_pumpstat' )) {
					pCF.document.getElementById( 'out_pumpstat' ).style.height = '61px';
					pCF.document.getElementById( 'out_pumpstat' ).style.overflow = 'auto';
					pCF.document.getElementById( 'out_pumpstat' ).style.width = '99%';
				}
				if( pCF.document.getElementById( 'out_alarm' )) {
					pCF.document.getElementById( 'out_alarm' ).style.height = '61px';
					pCF.document.getElementById( 'out_alarm' ).style.overflow = 'auto';
					pCF.document.getElementById( 'out_alarm' ).style.width = '99%';
				}
			} else if( pCF.pageType == 'service' ) {
				if( pCF.document.getElementById( 'out_pumpstat' )) {
					pCF.document.getElementById( 'out_pumpstat' ).style.height = '33px';
					pCF.document.getElementById( 'out_pumpstat' ).style.overflow = 'auto';
					pCF.document.getElementById( 'out_pumpstat' ).style.width = '99%';
				}
				if( pCF.document.getElementById( 'out_prealarm' )) {
					pCF.document.getElementById( 'out_prealarm' ).style.height = '33px';
					pCF.document.getElementById( 'out_prealarm' ).style.overflow = 'auto';
					pCF.document.getElementById( 'out_prealarm' ).style.width = '99%';
				}
				if( pCF.document.getElementById( 'out_alarm' )) {
					pCF.document.getElementById( 'out_alarm' ).style.height = '33px';
					pCF.document.getElementById( 'out_alarm' ).style.overflow = 'auto';
					pCF.document.getElementById( 'out_alarm' ).style.width = '99%';
				}
			}	// if( pCF.pageType == 'status' ) ... else ...
		}	// if( p.isBrowser.moz  )

		// Ermitteln, ob selektierter Slot bestückt
		pillar = p.pumpdata.selected[0];
		segment = p.pumpdata.selected[1];
		pump = p.pumpdata.selected[2];
		selectedSlotEquiped = ( pillar >= 0 && segment >= 0 && pump >= 0 ) && ( pumpdata[pillar][segment][pump].status != null );

		// Infofeldgruppe ein-/ausblenden
		if( pCF.document.getElementById( 'nopumpselected' ))
			pCF.document.getElementById( 'nopumpselected' ).style.display = selectedSlotEquiped ? 'none' : 'block';
		if( pCF.document.getElementById( 'pumpselected' ))
			pCF.document.getElementById( 'pumpselected' ).style.display = selectedSlotEquiped ? 'block' : 'none';

		// Infofeldgruppe ausblenden, falls kein oder unbestückter Slot selektiert
		if( !selectedSlotEquiped ) {
			pCF.subPanel( 'btn_infoselpump',null,false );
			pCF.subPanel( 'btn_cfgselpump',null,false );
			pCF.subPanel( 'btn_battselpump',null,false );
		}
	}	// if( typeof pCF.pageType ... )

	for( pillar=0; pillar<pillarCount; pillar++ ) {	// Schleife über Säulen
		// SpaceCover-Daten systematisch ermitteln

		// Cover-Typ ermitteln
		if( svccoverdta[pillar][99][99].software == null ) {
				stateCSSClass = 'cover_void';
				typeCSSClass = 'spacecover_standard';
		} else {
			stateCSSClass = 'cover_plugged';
			switch( svccoverdta[pillar][99][99].software.substr( 1,2 )) {
				case '92':	// SpaceCover Comfort
					typeCSSClass = 'spacecover_comfort';
					break;
				default:	// SpaceCover Standard
					typeCSSClass = 'spacecover_standard';
					break;
			}	// switch( ... )
		}	// if( svccoverdta[pillar][99][99].software ... )

		if( typeof pCF.pageType == 'string' ) {	// Prüfen, ob ContentFrame bereits geladen

			if( pCF.pageType == 'service' )
				if( p.coverdata.selected == pillar )
					if( svccoverdta[p.coverdata.selected][99][99].software )
						switch( svccoverdta[p.coverdata.selected][99][99].software.substr( 1,2 )) {
							case '92':	// SpaceCover Comfort
								cvComfortIsSelected = true;
								stateCSSClass = 'cover_selected';
								break;
							default:
								cvComfortIsSelected = false;
								pCF.subPanel( 'btn_battselcover',null,false );
								break;
						}	// switch

////////////////////////////////////////////////////////////////
//	Laut BBMAG/Paetzold ist SpaceCover Comfort-Funktionalität	//
//	noch nicht verfügbar und wird daher nicht angezeigt				//
//	B2A/Koe, 2006-02-15																				//
		cvComfortIsSelected = false;															//
////////////////////////////////////////////////////////////////

			// SpaceCover visualisieren
			pCF.pushData( 'state_pi'+pillar+'_cv',stateCSSClass,'className' );
			pCF.pushData( 'pi'+pillar+'_cv',typeCSSClass,'className' );

			if( pCF.pageType == 'service' ) {

				// Auf Service-Infoseite Infofeld für SpaceCover Comfort ein-/ausblenden
				if( pCF.document.getElementById( 'covercomfortinfo' ))
					pCF.document.getElementById( 'covercomfortinfo' ).style.display = cvComfortIsSelected ? 'block' : 'none';

				if( cvComfortIsSelected ) {
					// Daten für Service-Informationen aufbereiten
					cvsw = (svccoverdta[pillar][99][99].software != null ? svccoverdta[pillar][99][99].software : _VAIN_);
					cvserno = (svccoverdta[pillar][99][99].serno != null ? svccoverdta[pillar][99][99].serno : _VAIN_);
					cvbattcap = (svccoverdta[pillar][99][99].battcap != null ? svccoverdta[pillar][99][99].battcap : _VAIN_);
					cvbattcaptgt = (svccoverdta[pillar][99][99].battcaptgt != null ? svccoverdta[pillar][99][99].battcaptgt : _VAIN_);
					cvbattchrgstat = (svccoverdta[pillar][99][99].battchrgstat != null ? svccoverdta[pillar][99][99].battchrgstat : _VAIN_);
					cvbattmaintdt = (isNaN( svccoverdta[pillar][99][99].battmaintdt ) ? _DASH_ : p.ixTime2Str( Number( svccoverdta[pillar][99][99].battmaintdt ),'$Y-$0M-$0D $0h:$0m UTC' ));
					cvbattmaintrq = (svccoverdta[pillar][99][99].battmaintrq != null ? svccoverdta[pillar][99][99].battmaintrq : null);
					if( cvbattmaintrq != null )
						cvbattmaintrq = isNaN( cvbattmaintrq ) ? msg.lbl_unknown : cvbattmaintrq ? msg.yes : msg.no;
					else
						cvbattmaintrq = msg.no;
					cvbattvoltstat = (svccoverdta[pillar][99][99].battvoltstat != null ? svccoverdta[pillar][99][99].battvoltstat : _VAIN_);
					cvbattstat = (svccoverdta[pillar][99][99].battstat != null ? parseInt( svccoverdta[pillar][99][99].battstat ) : null);
					if( cvbattstat != null )
						cvbattstat = isNaN( cvbattstat ) ? msg.lbl_unknown : msg.lbl_battstatus[cvbattstat];
					else
						cvbattstat = msg.lbl_cvbattstatus[0];
					cvbattophrs = (svccoverdta[pillar][99][99].battophrs != null ? svccoverdta[pillar][99][99].battophrs : _VAIN_);
					if( cvbattophrs != _VAIN_ )
						cvbattophrs = p.calcTime( Number( cvbattophrs.replace( /sec/,'' ))/3600.0 ) + ' h';
					cvbattrtm = (svccoverdta[pillar][99][99].battrtm != null ? svccoverdta[pillar][99][99].battrtm : _VAIN_);
					if( cvbattrtm != _VAIN_ )
						cvbattrtm = p.calcTime( Number( cvbattrtm.replace( /min/,'' ))/60.0 ) + ' h';

					// Info zur selektierten Pumpe im Content-Frame ausgeben
					pCF.pushData( 'out_cvserno',cvserno );
					pCF.pushData( 'out_cvsw',cvsw );
					pCF.pushData( 'out_cvbattophrs',cvbattophrs );
					pCF.pushData( 'out_cvbattstat',cvbattstat );
					pCF.pushData( 'out_cvbattrtm',cvbattrtm );
					pCF.pushData( 'out_cvbattcap',cvbattcap );
					pCF.pushData( 'out_cvbattcaptgt',cvbattcaptgt );
					pCF.pushData( 'out_cvbattchrgstat',cvbattchrgstat );
					pCF.pushData( 'out_cvbattvoltstat',cvbattvoltstat );
					pCF.pushData( 'out_cvbattmaintrq',cvbattmaintrq );
					pCF.pushData( 'out_cvbattmaintdt',cvbattmaintdt );
				}	// if( cvComfortIsSelected ... )
			}	// if( pCF.pageType == 'service' )
		}	// if( typeof pCF.pageType ... )

		for( segment=0; segment<segmentsPerPillar[pillar]; segment++ ) {	// Schleife über Segmente
			for( pump=0; pump<=maxpump; pump++ ) {	// Schleife über Pumpen-Slots
				// Pumpendaten systematisch ermitteln

				// Beschreibungs- und Klassenfelder
				// leeren, Flags zurücksetzen
				pumpStateDesc = remAlarmDesc = preAlarmDesc = alarmDesc = pumpTypeDesc = stateCSSClass = typeCSSClass = '';
				pumpHasAlarm = pumpHasPrealarm = pumpHasRemalarm = patDtaIsValid = false;

				// Aktuelle Pumpe == selektierte Pumpe?
				pumpIsSelected =	((p.pumpdata.selected[0] == pillar) &&
													 (p.pumpdata.selected[1] == segment) &&
													 (p.pumpdata.selected[2] == pump));

				// Betriebszustand ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].status );
				if( isNaN( stateVar )) {
					pumpWorkingState = 0;
				} else {
					pumpWorkingState = 1;
					pumpStateDesc = msg.stat_OFF;

					// Sukzessive den exakten Betriebsstatus ermitteln
					if( (stateVar & p.workingStates.SYSTEMACTIVE) == p.workingStates.SYSTEMACTIVE ) {
						pumpWorkingState = 2;
						pumpStateDesc = msg.stat_SYSTEMACTIVE;
					}
					if( (stateVar & p.workingStates.STANDBY) == p.workingStates.STANDBY ) {
						pumpWorkingState = 3;
						pumpStateDesc = msg.stat_STANDBY;
					}
					if( (stateVar & p.workingStates.RUN) == p.workingStates.RUN ) {
						pumpWorkingState = 4;
						pumpCount++;
						pumpStateDesc = msg.stat_RUN;
					}
					if( pumpIsSelected )
						pumpWorkingState = 5;

					// Zusätzliche Stati
					if( (stateVar & p.workingStates.MAINS) == p.workingStates.MAINS )
						pumpStateDesc += _SEP_ + msg.stat_MAINS;
					if( (stateVar & p.workingStates.TPYBEGUN) == p.workingStates.TPYBEGUN )
						pumpStateDesc += _SEP_ + msg.stat_TPYBEGUN;
					if( (stateVar & p.workingStates.MANBOL) == p.workingStates.MANBOL )
						pumpStateDesc += _SEP_ + msg.stat_MANBOL;
					if( (stateVar & p.workingStates.VOLBOL) == p.workingStates.VOLBOL )
						pumpStateDesc += _SEP_ + msg.stat_VOLBOL;
					if( (stateVar & p.workingStates.KVOACTIVE) == p.workingStates.KVOACTIVE )
						pumpStateDesc += _SEP_ + msg.stat_KVOACTIVE;
					if( (stateVar & p.workingStates.DATALOCK) == p.workingStates.DATALOCK )
						pumpStateDesc += _SEP_ + msg.stat_DATALOCK;
					if( (stateVar & p.workingStates.DOSIS) == p.workingStates.DOSIS )
						pumpStateDesc += _SEP_ + msg.stat_DOSIS;
					if( (stateVar & p.workingStates.ALARMACTUALQUIT) == p.workingStates.ALARMACTUALQUIT )
						pumpStateDesc += _SEP_ + msg.stat_ALARMACTUALQUIT;
					if( (stateVar & p.workingStates.PREALARMACTUALQUIT) == p.workingStates.PREALARMACTUALQUIT )
						pumpStateDesc += _SEP_ + msg.stat_PREALARMACTUALQUIT;
					if( (stateVar & p.workingStates.AIRSENSOROFF) == p.workingStates.AIRSENSOROFF )
						pumpStateDesc += _SEP_ + msg.stat_AIRSENSOROFF;

					// Gültigkeit der Patientendaten feststellen
					//patDtaIsValid = ((stateVar & p.workingStates.PATIENTDATAVALID) == p.workingStates.PATIENTDATAVALID);
//////////////////////////////////////////////////////////////
// Validitäts-Flag lt. BBMAG/Paetzold fest auf TRUE setzen,	//
// B2A/Koe, 2006-02-16																			//
patDtaIsValid = true;																				//
//////////////////////////////////////////////////////////////

				}	// if( isNaN( stateVar )) else

				// Erinnerungsalarmstatus ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].remalarm );
				if( !isNaN( stateVar )) {
					pumpHasRemalarm = stateVar > 0;
					switch( stateVar ) {
						case remAlarmStates.NOREMALARM:
							remAlarmDesc = msg.RemAlarm_IS_INACTIVE;
							break;
						case remAlarmStates.EDIT:
						case remAlarmStates.CONFIG_MENUE:
						case remAlarmStates.DEFAULT_MENUE:
						case remAlarmStates.DATA_LOCK:
						case remAlarmStates.INCOMPATIBLE_CAN_DEVICE:
						case remAlarmStates.PIGGYBACK:
						case remAlarmStates.TGC:
							remAlarmDesc = msg.RemAlarm_IS_ACTIVE;
							break;
						default:
							remAlarmDesc = msg.RemAlarm_UNKNOWN;
							break;
					}	// switch
				}	// if( !isNaN( stateVar ))

				// Voralarmstatus ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].prealarm );
				if( isNaN( stateVar )) {
					if( pumpWorkingState )
						preAlarmDesc = msg.preAlarm_NOPREALARM;
				} else
					if( stateVar == 0 )
						preAlarmDesc = msg.preAlarm_NOPREALARM;
					else {	// Pumpe im Voralarmstatus
						pumpHasPrealarm = true;
						if( (stateVar & preAlarmStates.DISPOSABLE) == preAlarmStates.DISPOSABLE )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_DISPOSABLE : _LI_ + msg.preAlarm_DISPOSABLE);
						if( (stateVar & preAlarmStates.VTBD) == preAlarmStates.VTBD )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_VTBD : _LI_ + msg.preAlarm_VTBD);
						if( (stateVar & preAlarmStates.TIME) == preAlarmStates.TIME )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_TIME : _LI_ + msg.preAlarm_TIME);
						if( (stateVar & preAlarmStates.ACCU) == preAlarmStates.ACCU )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_ACCU : _LI_ + msg.preAlarm_ACCU);
						if( (stateVar & preAlarmStates.KOR) == preAlarmStates.KOR )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_KOR : _LI_ + msg.preAlarm_KOR);
						
						if( (stateVar & preAlarmStates.DATALOCK) == preAlarmStates.DATALOCK )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_DATALOCK : _LI_ + msg.preAlarm_DATALOCK);
						if( (stateVar & preAlarmStates.INCOMPATIBLE_CAN_DEVICE) == preAlarmStates.INCOMPATIBLE_CAN_DEVICE )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_INCOMPATIBLE_CAN_DEVICE : _LI_ + msg.preAlarm_INCOMPATIBLE_CAN_DEVICE);
						if( (stateVar & preAlarmStates.PIGGYBACK) == preAlarmStates.PIGGYBACK )						
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_PIGGYBACK : _LI_ + msg.preAlarm_PIGGYBACK);
						if( (stateVar & preAlarmStates.TGC) == preAlarmStates.TGC )
							preAlarmDesc += _SEP_ + (preAlarmDesc=='' ? msg.preAlarm_TGC : _LI_ + msg.preAlarm_TGC);
						// Unbekannter Voralarmtyp
						preAlarmDesc += _SEP_ + (preAlarmDesc==''?msg.preAlarm_UNKNOWN:'');

						// Voralarm labeln
						if( pCF.pageType == 'status' )
							preAlarmDesc = msg.preAlarm_Label + preAlarmDesc;
						else
							preAlarmDesc = preAlarmDesc.slice( _SEP_.length );
					}	// if( stateVar == 0 ) else

				// Alarmstatus ermitteln
				stateVar = parseInt( pumpdata[pillar][segment][pump].alarm );
				stateVar2 = parseInt( pumpdata[pillar][segment][pump].alarm2 );
				if( isNaN( stateVar ) && isNaN( stateVar2)) {
					if( pumpWorkingState )
						alarmDesc = msg.Alarm_NOALARM;
				} else
					if( (stateVar == 0 ) && (stateVar2 == 0) )
						alarmDesc = msg.Alarm_NOALARM;
					else {	// Pumpe im Alarmstatus
						pumpHasAlarm = true;
						if( (stateVar & alarmStates.CALDATA) == alarmStates.CALDATA )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_CALDATA : _LI_ + msg.Alarm_CALDATA);
						if( (stateVar & alarmStates.ACCU) == alarmStates.ACCU )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_ACCU : _LI_ + msg.Alarm_ACCU);
						if( (stateVar & alarmStates.TPYDATA) == alarmStates.TPYDATA )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_TPYDATA : _LI_ + msg.Alarm_TPYDATA);
						if( (stateVar & alarmStates.TPYANDPUMPDATA) == alarmStates.TPYANDPUMPDATA )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_TPYANDPUMPDATA : _LI_ + msg.Alarm_TPYANDPUMPDATA);
						if( (stateVar & alarmStates.ACCUVOLTAGE) == alarmStates.ACCUVOLTAGE )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_ACCUVOLTAGE : _LI_ + msg.Alarm_ACCUVOLTAGE);
						if( (stateVar & alarmStates.NOACCU) == alarmStates.NOACCU )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_NOACCU : _LI_ + msg.Alarm_NOACCU);
						if( (stateVar & alarmStates.ACCU_EMPTY) == alarmStates.ACCU_EMPTY )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_ACCU_EMPTY : _LI_ + msg.Alarm_ACCU_EMPTY);
						if( (stateVar & alarmStates.ACCUCOVER) == alarmStates.ACCUCOVER )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_ACCUCOVER : _LI_ + msg.Alarm_ACCUCOVER);
						if( (stateVar & alarmStates.SYREND) == alarmStates.SYREND )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_SYREND : _LI_ + msg.Alarm_SYREND);
						if( (stateVar & alarmStates.PRESSURE) == alarmStates.PRESSURE )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_PRESSURE : _LI_ + msg.Alarm_PRESSURE);
						if( (stateVar & alarmStates.SMBLOCK) == alarmStates.SMBLOCK )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_SMBLOCK : _LI_ + msg.Alarm_SMBLOCK);
						if( (stateVar & alarmStates.STANDBY) == alarmStates.STANDBY )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_STANDBY : _LI_ + msg.Alarm_STANDBY);
						if( (stateVar & alarmStates.VOLEND) == alarmStates.VOLEND )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_VOLEND : _LI_ + msg.Alarm_VOLEND);
						if( (stateVar & alarmStates.TIMEEND) == alarmStates.TIMEEND )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_TIMEEND : _LI_ + msg.Alarm_TIMEEND);
						if( (stateVar & alarmStates.SYRCLAW) == alarmStates.SYRCLAW )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_SYRCLAW : _LI_ + msg.Alarm_SYRCLAW);
						if( (stateVar & alarmStates.KPS) == alarmStates.KPS )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_KPS : _LI_ + msg.Alarm_KPS);
						if( (stateVar & alarmStates.SYRHOLD) == alarmStates.SYRHOLD )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_SYRHOLD : _LI_ + msg.Alarm_SYRHOLD);
						if( (stateVar & alarmStates.SYRAXIAL) == alarmStates.SYRAXIAL )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_SYRAXIAL : _LI_ + msg.Alarm_SYRAXIAL);
						if( (stateVar & alarmStates.KVOEND) == alarmStates.KVOEND )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_KVOEND : _LI_ + msg.Alarm_KVOEND);
						if( (stateVar & alarmStates.BAGEMPTY) == alarmStates.BAGEMPTY )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_BAGEMPTY : _LI_ + msg.Alarm_BAGEMPTY);
						if( (stateVar & alarmStates.TEMPERATURE) == alarmStates.TEMPERATURE )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_TEMPERATURE : _LI_ + msg.Alarm_TEMPERATURE);
						if( (stateVar & alarmStates.DRIP) == alarmStates.DRIP )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_DRIP : _LI_ + msg.Alarm_DRIP);
						if( (stateVar & alarmStates.NODROP) == alarmStates.NODROP )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_NODROP : _LI_ + msg.Alarm_NODROP);
						if( (stateVar & alarmStates.LESSDROPS) == alarmStates.LESSDROPS )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_LESSDROPS : _LI_ + msg.Alarm_LESSDROPS);
						if( (stateVar & alarmStates.MANYDROPS) == alarmStates.MANYDROPS )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_MANYDROPS : _LI_ + msg.Alarm_MANYDROPS);
						if( (stateVar & alarmStates.FREEFLOW) == alarmStates.FREEFLOW )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_FREEFLOW : _LI_ + msg.Alarm_FREEFLOW);
						if( (stateVar & alarmStates.DRIPDISCONNECT) == alarmStates.DRIPDISCONNECT )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_DRIPDISCONNECT : _LI_ + msg.Alarm_DRIPDISCONNECT);
						if( (stateVar & alarmStates.AIR) == alarmStates.AIR )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_AIR : _LI_ + msg.Alarm_AIR);
						if( (stateVar & alarmStates.AIRBUBBLE) == alarmStates.AIRBUBBLE )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_AIRBUBBLE : _LI_ + msg.Alarm_AIRBUBBLE);
						if( (stateVar & alarmStates.AIRRATE) == alarmStates.AIRRATE )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_AIRRATE : _LI_ + msg.Alarm_AIRRATE);
						if( (stateVar & alarmStates.NOAIRTEST) == alarmStates.NOAIRTEST )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_NOAIRTEST : _LI_ + msg.Alarm_NOAIRTEST);
						if( (stateVar & alarmStates.CONTEND) == alarmStates.CONTEND )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_CONTEND : _LI_ + msg.Alarm_CONTEND);

						if ( (stateVar2 & alarmStates2.DATA_LOCK) == alarmStates2.DATA_LOCK )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_DATA_LOCK : _LI_ + msg.Alarm_DATA_LOCK);
						if ( (stateVar2 & alarmStates2.XHLIMIT) == alarmStates2.XHLIMIT )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_XHLIMIT : _LI_ + msg.Alarm_XHLIMIT);
						if ( (stateVar2 & alarmStates2.TGCEND) == alarmStates2.TGCEND )
							alarmDesc += _SEP_ + (alarmDesc=='' ? msg.Alarm_TGCEND : _LI_ + msg.Alarm_TGCEND);
														
						// Unbekannter Alarmtyp
						alarmDesc += _SEP_ + (alarmDesc==''?msg.Alarm_UNKNOWN:'');

						// Alarm labeln
						if( pCF.pageType == 'status' )
							alarmDesc = msg.Alarm_Label + alarmDesc;
						else
							alarmDesc = alarmDesc.slice( _SEP_.length );
					}	// if( stateVar == 0 ) else

				var pumpType = '';
				// Pumpentyp ermitteln
				if(!pumpWorkingState || (pumpdata[pillar][segment][pump].software == null)) {
						stateCSSClass = 'pump_void';
						typeCSSClass = 'space_void';
				} else
					switch( pumpdata[pillar][segment][pump].software.substr( 1,2 )) {
						case '86':	// Infusomat
							typeCSSClass = 'space_infusomat';
							pumpTypeDesc = msg.lbl_LegendPumpInfusomat;
							pumpType = 'I';
							break;
						case '87':	// Infusomat P
							typeCSSClass = 'space_infusomat';
							pumpTypeDesc = msg.lbl_LegendPumpInfusomat + ' P';
							pumpType = 'I';							
							break;
						case '88':	// Perfusor
							typeCSSClass = 'space_perfusor';
							pumpTypeDesc = msg.lbl_LegendPumpPerfusor;
							pumpType = 'P';
							break;
						default:	//Unbekannt oder falsch
							pumpWorkingState = 0;
							typeCSSClass = 'space_void';
							break;
					}	// switch( ... )

				if (pumpIsSelected) {
					if (pCF.document.getElementById('disposable_syringe')) {
						pCF.document.getElementById('disposable_syringe').style.display = (pumpType == 'P' ? '' : 'none');
					}
					if (pCF.document.getElementById('disposable_tube')) {
						pCF.document.getElementById('disposable_tube').style.display = (pumpType == 'I' ? '' : 'none');
					}
				}

				// SoftLimit-Status ermitteln
				softLimit.currstate = 0;	// Soft Limit-Momentandaten
				softLimit.currimg = '';		// zurücksetzen
				softLimit.showshort = (softLimit.notation == 's' && pCF.pageType == 'status');	// Kurzname anzeigen
				stateVar = parseInt( pumpdata[pillar][segment][pump].SLstatus );
				if( (!isNaN( stateVar )) && ( stateVar != 0 ) ) {	
					softLimit.currstate = stateVar;
					softLimit.currimg = softLimit.img.replace( /\$state/,softLimit.currstate );
				}	// if( !isNaN( stateVar ))

				// Medikamenttext für Pumpensymbol zuordnen
				if( softLimit.showshort ) {
					pumpText = (pumpdata[pillar][segment][pump].drugnameshort != null ? pumpdata[pillar][segment][pump].drugnameshort : _VAIN_);	// Kurzname
					pumpText += _SEP_ + (pumpdata[pillar][segment][pump].doserate != null ? pumpdata[pillar][segment][pump].doserate : pumpdata[pillar][segment][pump].infrate != null ? pumpdata[pillar][segment][pump].infrate : _VAIN_);	// mit Dosis- bzw. Förderrate
				} else
					pumpText = (pumpdata[pillar][segment][pump].drugname != null ? pumpdata[pillar][segment][pump].drugname : _VAIN_);	// Langname

				// Je nach Betriebszustand abweichenden Text für Pumpen-`Label´
				// sowie Zustandsbeschreibung und CSS-Klasse zuweisen
				switch( pumpWorkingState ) {
				/******************************************************************
					pumpWorkingState:
								1:	Steckplatz belegt, Pumpe aber abgeschaltet
								2:	Pumpe ist eingeschaltet
								3:	Pumpe ist in Stand-By (Medikamententext ggf. behalten)
								4:	Pumpe arbeitet (Medikamententext ggf. behalten)
								5:	Pumpe ist selektiert
						sonst:	Steckplatz leer (oder Gerätezustandskennung unbekannt)
				******************************************************************/
					case 1:	// Pumpe ist vorhanden, aber abgeschaltet
						stateCSSClass = (pumpHasAlarm ? 'pump_alarm' : pumpHasPrealarm || pumpHasRemalarm ? 'pump_prealarm' : 'pump_off');
						pumpText = templates.pumpLbl.replace( /\$lbl/,pumpHasAlarm ? msg.lbl_Alarm : pumpHasPrealarm ? msg.lbl_Prealarm : pumpHasRemalarm ? msg.lbl_Remalarm : msg.lbl_Off );
						break;
					case 2:	// Pumpe ist eingeschaltet
						stateCSSClass = (pumpHasAlarm ? 'pump_alarm' : pumpHasPrealarm || pumpHasRemalarm ? 'pump_prealarm' : 'pump_on');
						pumpText = templates.pumpLbl.replace( /\$lbl/,pumpHasAlarm ? msg.lbl_Alarm : pumpHasPrealarm ? msg.lbl_Prealarm : pumpHasRemalarm ? msg.lbl_Remalarm : msg.lbl_On );
						break;
					case 3:	// Pumpe ist in Stand-By (Medikamententext ggf. behalten)
						stateCSSClass = (pumpHasAlarm ? 'pump_alarm' : pumpHasPrealarm || pumpHasRemalarm ? 'pump_prealarm' : 'pump_standby');
						if( pumpHasAlarm || pumpHasPrealarm || pumpHasRemalarm )
							pumpText = templates.pumpLbl.replace( /\$lbl/,pumpHasAlarm ? msg.lbl_Alarm : pumpHasPrealarm ? msg.lbl_Prealarm : msg.lbl_Remalarm );
						else {
							pumpText = templates.abbrevPumpText.replace( /\$abbrevPumpText/,(pumpText.length>14?p.cutStr( p.cutStr( pumpText,28 ),14 ) : pumpText)).replace( /\$pumpText/,pumpText );
							if( softLimit.showshort )
								pumpText = templates.shortPumpText.replace( /\$slimg/,softLimit.currimg ).replace( /\$imgsz/,'s' ).replace( /\$pumptxt/,pumpText ).replace( /class\=\"narrow\"/,'class="short"' );
						}
						break;
					case 4:	// Pumpe arbeitet (Medikamententext ggf. behalten)
						stateCSSClass = (pumpHasAlarm ? 'pump_alarm' : pumpHasPrealarm || pumpHasRemalarm ? 'pump_prealarm' : 'pump_running');
						if( pumpHasAlarm || pumpHasPrealarm || pumpHasRemalarm )
							pumpText = templates.pumpLbl.replace( /\$lbl/,pumpHasAlarm ? msg.lbl_Alarm : pumpHasPrealarm ? msg.lbl_Prealarm : msg.lbl_Remalarm );
						else {
							pumpText = templates.abbrevPumpText.replace( /\$abbrevPumpText/,(pumpText.length>14?p.cutStr( p.cutStr( pumpText,28 ),14 ) : pumpText)).replace( /\$pumpText/,pumpText );
							if( softLimit.showshort )
								pumpText = templates.shortPumpText.replace( /\$slimg/,softLimit.currimg ).replace( /\$imgsz/,'s' ).replace( /\$pumptxt/,pumpText ).replace( /class\=\"narrow\"/,'class="short"' );
						}
						break;
					case 5:	// Pumpe ist selektiert
						stateCSSClass = (pumpHasAlarm ? 'pump_alarm' : pumpHasPrealarm || pumpHasRemalarm ? 'pump_prealarm' : 'pump_selected');
						pumpText = templates.pumpLbl.replace( /\$lbl/,msg.lbl_Selected );
						break;
					default:	// Andere (auch fehlerhafte) Zustände sowie "Pumpe nicht vorhanden"
						stateCSSClass = 'pump_void';
						pumpText = _VAIN_;
						break;
				}	// switch( pumpWorkingState )

				if( typeof pCF.pageType == 'string' ) {	// Prüfen, ob ContentFrame bereits geladen

					// Daten für Systemstruktur im Content-Frame ausgeben
					pCF.pushData( 'state_pi'+pillar+'_sg'+segment+'_pu'+pump,stateCSSClass,'className' );
					pCF.pushData( 'pi'+pillar+'_sg'+segment+'_pu'+pump,typeCSSClass,'className' );
					pCF.pushData( 'pi'+pillar+'_sg'+segment+'_pu'+pump,pumpText );

					// Daten für Systeminformation ausgeben
					pCF.pushData( 'out_numactivepumps',pumpCount );

					if( pumpIsSelected ) {
						if( pumpWorkingState ) {
							software = (pumpdata[pillar][segment][pump].software != null ? pumpdata[pillar][segment][pump].software : _VAIN_);
							serialnumber = (pumpdata[pillar][segment][pump].serialnumber != null ? pumpdata[pillar][segment][pump].serialnumber : _VAIN_);
							doserate = (pumpdata[pillar][segment][pump].doserate != null ? pumpdata[pillar][segment][pump].doserate : _VAIN_);
							infrate = (pumpdata[pillar][segment][pump].infrate != null ? pumpdata[pillar][segment][pump].infrate : _VAIN_);
							drugname = (pumpdata[pillar][segment][pump].drugname != null ? pumpdata[pillar][segment][pump].drugname : _VAIN_);

							if( pCF.pageType == 'status' ) {
								drugname = (softLimit.currimg + drugname).replace( /\$imgsz/,'b' );
								infvol = (pumpdata[pillar][segment][pump].infvol != null ? pumpdata[pillar][segment][pump].infvol : _VAIN_);
								infrvol = (pumpdata[pillar][segment][pump].infrvol != null ? pumpdata[pillar][segment][pump].infrvol : _VAIN_);
								inftm = (pumpdata[pillar][segment][pump].inftime != null ? pumpdata[pillar][segment][pump].inftime : _VAIN_);
								infrtm = (pumpdata[pillar][segment][pump].infrtime != null ? pumpdata[pillar][segment][pump].infrtime : _VAIN_);
								drugconcent = (pumpdata[pillar][segment][pump].drugconcent != null ? pumpdata[pillar][segment][pump].drugconcent : _VAIN_);
								syrname = (pumpdata[pillar][segment][pump].syrname != null ? pumpdata[pillar][segment][pump].syrname : _VAIN_);
								syrvol = (pumpdata[pillar][segment][pump].syrvol != null ? pumpdata[pillar][segment][pump].syrvol : _VAIN_);
								tubename = (pumpdata[pillar][segment][pump].tubename != null ? pumpdata[pillar][segment][pump].tubename : _VAIN_);
								proftype = (pumpdata[pillar][segment][pump].profiletype != null ? pumpdata[pillar][segment][pump].profiletype : msg.lbl_defaultProfType);
								patname = (pumpdata[pillar][segment][pump].patname != null ? pumpdata[pillar][segment][pump].patname : _VAIN_);
								patsurname = (pumpdata[pillar][segment][pump].patsurname != null ? pumpdata[pillar][segment][pump].patsurname : _VAIN_);
								patid = (pumpdata[pillar][segment][pump].patid != null ? pumpdata[pillar][segment][pump].patid : _VAIN_);
								patweight = (pumpdata[pillar][segment][pump].patweight != null ? pumpdata[pillar][segment][pump].patweight : _VAIN_);
								patgender = (pumpdata[pillar][segment][pump].patgender != null ? parseInt( pumpdata[pillar][segment][pump].patgender ) : null);
								if( patgender != null )
									patgender = isNaN( patgender ) ? msg.lbl_unknown : patgender == 1 ? msg.lbl_genderMale : patgender == 2 ? msg.lbl_genderFemale : msg.lbl_unknown;
								else
									patgender = msg.lbl_unknown;
								patbyear = (pumpdata[pillar][segment][pump].patbirthyear != null ? pumpdata[pillar][segment][pump].patbirthyear : null);
								patbmonth = (pumpdata[pillar][segment][pump].patbirthmonth != null ? pumpdata[pillar][segment][pump].patbirthmonth : null);
								patbday = (pumpdata[pillar][segment][pump].patbirthday != null ? pumpdata[pillar][segment][pump].patbirthday : null);
								if( patbday != null && patbmonth != null )
									patbirth='$Y-$M-SD'.replace( /\$Y/,p.num2str( 1900+(patbyear != null ? Number( patbyear ) : 0 ))).replace( /\$M/,p.num2str( Number( patbmonth ),0,2 )).replace( /\SD/,p.num2str( Number( patbday ),0,2 ));
								else
									patbirth=_VAIN_;
								if( inftm != _VAIN_ )
									inftm = p.calcTime( Number( inftm.replace( /min/,'' ))/60.0 ) + ' h';
								if( infrtm != _VAIN_ )
									infrtm = p.calcTime( Number( infrtm.replace( /min/,'' ))/60.0 ) + ' h';
							}	// if( pCF.pageType == 'status' )

							if( pCF.pageType == 'service' ) {
								wardID = (svcpumpdta[pillar][segment][pump].wardid != null ? svcpumpdta[pillar][segment][pump].wardid : _VAIN_);
								bolratedef = (svcpumpdta[pillar][segment][pump].bolratedef != null ? svcpumpdta[pillar][segment][pump].bolratedef : _VAIN_);
								dtalcklvl = (svcpumpdta[pillar][segment][pump].dtalcklvl != null ? svcpumpdta[pillar][segment][pump].dtalcklvl : _VAIN_);
								motorsteps = (svcpumpdta[pillar][segment][pump].motorsteps != null ? svcpumpdta[pillar][segment][pump].motorsteps : _VAIN_);
								totvoldeliv = (svcpumpdta[pillar][segment][pump].totvoldeliv != null ? svcpumpdta[pillar][segment][pump].totvoldeliv : _VAIN_);
								dispchgs = (svcpumpdta[pillar][segment][pump].dispchgs != null ? svcpumpdta[pillar][segment][pump].dispchgs : _VAIN_);
								startcnt = (svcpumpdta[pillar][segment][pump].startcnt != null ? svcpumpdta[pillar][segment][pump].startcnt : _VAIN_);
								ratemax = (svcpumpdta[pillar][segment][pump].ratemax != null ? svcpumpdta[pillar][segment][pump].ratemax : _VAIN_);
								ratemin = (svcpumpdta[pillar][segment][pump].ratemin != null ? svcpumpdta[pillar][segment][pump].ratemin : _VAIN_);
								bolratemax = (svcpumpdta[pillar][segment][pump].bolratemax != null ? svcpumpdta[pillar][segment][pump].bolratemax : _VAIN_);
								bolratemin = (svcpumpdta[pillar][segment][pump].bolratemin != null ? svcpumpdta[pillar][segment][pump].bolratemin : _VAIN_);
								dtalckcode = (svcpumpdta[pillar][segment][pump].dtalckcode != null ? svcpumpdta[pillar][segment][pump].dtalckcode : _VAIN_);
								battstat = (svcpumpdta[pillar][segment][pump].battstat != null ? parseInt( svcpumpdta[pillar][segment][pump].battstat ) : null);
								if( battstat != null )
									battstat = isNaN( battstat ) ? msg.lbl_unknown : msg.lbl_battStatus[battstat];
								else
									battstat = msg.lbl_battStatus[0];
								battcap = (svcpumpdta[pillar][segment][pump].battcap != null ? svcpumpdta[pillar][segment][pump].battcap : _VAIN_);
								battcaptgt = (svcpumpdta[pillar][segment][pump].battcaptgt != null ? svcpumpdta[pillar][segment][pump].battcaptgt : _VAIN_);
								battchrgstat = (svcpumpdta[pillar][segment][pump].battchrgstat != null ? svcpumpdta[pillar][segment][pump].battchrgstat : _VAIN_);
								battvoltstat = (svcpumpdta[pillar][segment][pump].battvoltstat != null ? svcpumpdta[pillar][segment][pump].battvoltstat : _VAIN_);
								battmaintdt = (svcpumpdta[pillar][segment][pump].battmaintdt != null ? p.ixTime2Str( Number( svcpumpdta[pillar][segment][pump].battmaintdt ),'$Y-$0M-$0D $0h:$0m UTC' ) : _VAIN_);
								battmaintrq = (svcpumpdta[pillar][segment][pump].battmaintrq != null ? svcpumpdta[pillar][segment][pump].battmaintrq : null);
								if( battmaintrq != null )
									battmaintrq = isNaN( battmaintrq ) ? msg.lbl_unknown : battmaintrq ? msg.yes : msg.no;
								else
									battmaintrq = msg.no;
								ophrs = (svcpumpdta[pillar][segment][pump].ophrs != null ? svcpumpdta[pillar][segment][pump].ophrs : _VAIN_);
								if( ophrs != _VAIN_ )
									ophrs = p.calcTime( Number( ophrs.replace( /sec/,'' ))/3600.0 ) + ' h';
								battophrs = (svcpumpdta[pillar][segment][pump].battophrs != null ? svcpumpdta[pillar][segment][pump].battophrs : _VAIN_);
								if( battophrs != _VAIN_ )
									battophrs = p.calcTime( Number( battophrs.replace( /sec/,'' ))/3600.0 ) + ' h';
								battrtm = (svcpumpdta[pillar][segment][pump].battrtm != null ? svcpumpdta[pillar][segment][pump].battrtm : _VAIN_);
								if( battrtm != _VAIN_ )
									battrtm = p.calcTime( Number( battrtm.replace( /min/,'' ))/60.0 ) + ' h';
							}	// if( pCF.pageType == 'service' )
						}	// if( pumpWorkingState )

						pCF.pushData( 'out_serno',serialnumber );
						pCF.pushData( 'out_software',software );
						pCF.pushData( 'out_drugname',drugname );
						pCF.pushData( 'out_doserate',doserate );
						pCF.pushData( 'out_infrate',infrate );
						pCF.pushData( 'out_pumpstat',pumpStateDesc + _VAIN_ );

						if( pCF.pageType == 'status' ) {
							if( alarmDesc.length && preAlarmDesc.length && remAlarmDesc.length )
								tmpStr = remAlarmDesc + _SEP_ + alarmDesc + _SEP_ + preAlarmDesc;
							else if( alarmDesc.length && remAlarmDesc.length )
								tmpStr = remAlarmDesc + _SEP_ + alarmDesc;
							else if( alarmDesc.length && preAlarmDesc.length )
								tmpStr = alarmDesc + _SEP_ + preAlarmDesc;
							else if( preAlarmDesc.length && remAlarmDesc.length )
								tmpStr = remAlarmDesc + _SEP_ + preAlarmDesc;
							else if( alarmDesc.length )
								tmpStr = alarmDesc;
							else if( preAlarmDesc.length )
								tmpStr = preAlarmDesc;
							else if( remAlarmDesc.length )
								tmpStr = remAlarmDesc;
							else
								tmpStr = _VAIN_;
							pCF.pushData( 'out_alarm',tmpStr );
							pCF.pushData( 'out_infvol',infvol );
							pCF.pushData( 'out_infrvol',infrvol );
							pCF.pushData( 'out_inftm',inftm );
							pCF.pushData( 'out_infrtm',infrtm );
							pCF.pushData( 'out_drugconcent',drugconcent );
							pCF.pushData( 'out_syrname',syrname );
							pCF.pushData( 'out_syrvol',syrvol );
							pCF.pushData( 'out_tubename',tubename );

//////////////////////////////////////////////////////////////
// Profiltyp lt. BBMAG/Paetzold fest auf Defaulttyp setzen,	//
// B2A/Koe, 2006-02-16																			//
proftype = msg.lbl_defaultProfType;													//
//////////////////////////////////////////////////////////////
							pCF.pushData( 'out_profype',proftype );

							pCF.pushData( 'out_patweight',patDtaIsValid ? patweight : _VAIN_ );
							pCF.pushData( 'out_patname',patDtaIsValid ? p.stripSpace( patname )+(patsurname != _VAIN_ ? ' '+p.stripSpace( patsurname ) : _VAIN_) : _VAIN_ );
							pCF.pushData( 'out_patid',patDtaIsValid ? patid : _VAIN_ );
							pCF.pushData( 'out_patgender',patDtaIsValid ? patgender : _VAIN_ );
							pCF.pushData( 'out_patweight',patDtaIsValid ? patweight : _VAIN_ );
							pCF.pushData( 'out_patbirth',patDtaIsValid ? patbirth : _VAIN_ );
						}	// if( pCF.pageType == 'status' )

						if( pCF.pageType == 'service' ) {
							if( preAlarmDesc.length && remAlarmDesc.length )
								tmpStr = preAlarmDesc + _SEP_ + remAlarmDesc;
							else if( preAlarmDesc.length )
								tmpStr = preAlarmDesc;
							else if( remAlarmDesc.length )
								tmpStr = remAlarmDesc;
							else
								tmpStr = _VAIN_;
							pCF.pushData( 'out_prealarm',tmpStr );
							pCF.pushData( 'out_alarm',alarmDesc + _VAIN_ );
							pCF.pushData( 'out_wardid',wardID );
							pCF.pushData( 'out_bolratedef',bolratedef );
							pCF.pushData( 'out_dtalcklvl',dtalcklvl );
							pCF.pushData( 'out_ophrs',ophrs );
							pCF.pushData( 'out_motorsteps',motorsteps );
							pCF.pushData( 'out_totvoldeliv',totvoldeliv );
							pCF.pushData( 'out_dispchgs',dispchgs );
							pCF.pushData( 'out_startcnt',startcnt );
							pCF.pushData( 'out_ratemin',ratemin );
							pCF.pushData( 'out_ratemax',ratemax );
							pCF.pushData( 'out_bolratemin',bolratemin );
							pCF.pushData( 'out_bolratemax',bolratemax );
							pCF.pushData( 'out_dtalckcode',dtalckcode );
							pCF.pushData( 'out_battophrs',battophrs );
							pCF.pushData( 'out_battstat',battstat );
							pCF.pushData( 'out_battrtm',battrtm );
							pCF.pushData( 'out_battcap',battcap );
							pCF.pushData( 'out_battcaptgt',battcaptgt );
							pCF.pushData( 'out_battchrgstat',battchrgstat );
							pCF.pushData( 'out_battvoltstat',battvoltstat );
							pCF.pushData( 'out_battmaintrq',battmaintrq );
							pCF.pushData( 'out_battmaintdt',battmaintdt );
						}	// if( pCF.pageType == 'service' )
					}	// if( pumpIsSelected )
				}	// if( typeof pCF.pageType == 'string' )
			}	// for( pump ... )
		}	// for( segment ... )
	}	// for( pillar ... )

	p.feedingIsInProgress = false;
	window.status = window.defaultStatus;

}	// function feedData()
