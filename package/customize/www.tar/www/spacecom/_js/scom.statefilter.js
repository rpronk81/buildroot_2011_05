﻿/****************************************************************
 * Javascript-Zustandsfilter für Daten-Feeder										*
 * Projekt: SpaceOnline, B. Braun Melsungen AG									*
 * Copyright (c) 2005,2006 by B2A Corporate Marketing						*
 * All rights reserved																					*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03, 2006-07																	*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * Version: -																										*
 * Autor: B2A/koe																								*
 * Letzte Bearbeitung: 2006-07-27 15:47													*
 * durch: Koe																										*
 ****************************************************************/
var n,workingStates=new Array(),
		remAlarmStates=new Array(),
		preAlarmStates=new Array(),
		alarmStates=new Array();
		alarmStates2=new Array();

	// Betriebsstati														Nur kommentierte werden verwendet:
	workingStates.SYSTEMACTIVE				=(n=1);		// Status: Pumpe eingeschaltet
	workingStates.MAINS								=(n*=2);	// Status: Netzbetrieb Pumpe EIN
	workingStates.STANDBY							=(n*=2);	// Status: Pumpe ist in StandBy
	workingStates.MNUSTARTUP					=(n*=2);
	workingStates.PURGE								=(n*=2);
	workingStates.DRIVECLOSE					=(n*=2);
	workingStates.RUNREADY						=(n*=2);
	workingStates.RUN									=(n*=2);	// Status: Pumpe arbeitet (Icon grün)
	workingStates.TPYBEGUN						=(n*=2);	// Status: Therapie hat begonnen
	workingStates.BOLUSREADY					=(n*=2);
	workingStates.MANBOL							=(n*=2);	// Status: man. Bolus aktiv
	workingStates.VOLBOL							=(n*=2);	// Status: Vol.bolus aktiv
	workingStates.KVOREADY						=(n*=2);
	workingStates.KVOACTIVE						=(n*=2);	// Status: KVO aktiv
	workingStates.DATALOCK						=(n*=2);	// Status: DataLock EIN
	workingStates.DOSIS								=(n*=2);	// Status: Dosis EIN
	workingStates.DOSBOLUSEWEIGHT			=(n*=2);
	workingStates.PATIENTDATAVALID		=(n*=2);	// Status: Patientendaten sind gültig
	workingStates.LOCALPUMPCONTROL		=(n*=2);
	workingStates.ALARMACTUALQUIT			=(n*=2);	// Status: akt. Alarm ist quittiert
	workingStates.PREALARMACTUALQUIT	=(n*=2);	// Status: akt. Voralarm ist quittiert
	workingStates.CMCONNECTED					=(n*=2);
	workingStates.AIRSENSOROFF				=(n*=2);	// Status: Luftsensor ist ausgeschaltet

	// Voralarmstati
	preAlarmStates.NOPREALARM					=(n=1);
	preAlarmStates.DISPOSABLE					=(n*=2);
	preAlarmStates.VTBD								=(n*=2);
	preAlarmStates.TIME								=(n*=2);
	preAlarmStates.ACCU								=(n*=2);
	preAlarmStates.KOR								=(n*=2);
	preAlarmStates.DATALOCK							=(n*=2);
	preAlarmStates.INCOMPATIBLE_CAN_DEVICE			=(n*=2);
	preAlarmStates.PIGGYBACK						=(n*=2);
	preAlarmStates.TGC								=(n*=2);

	// Alarmstati
	alarmStates.NOALARM								=(n=1);
	alarmStates.CALDATA								=(n*=2);
	alarmStates.ACCU									=(n*=2);
	alarmStates.TPYDATA								=(n*=2);
	alarmStates.TPYANDPUMPDATA				=(n*=2);
	alarmStates.ACCUVOLTAGE						=(n*=2);
	alarmStates.NOACCU								=(n*=2);
	alarmStates.ACCU_EMPTY						=(n*=2);
	alarmStates.ACCUCOVER							=(n*=2);
	alarmStates.SYREND								=(n*=2);
	alarmStates.PRESSURE							=(n*=2);
	alarmStates.SMBLOCK								=(n*=2);
	alarmStates.STANDBY								=(n*=2);
	alarmStates.VOLEND								=(n*=2);
	alarmStates.TIMEEND								=(n*=2);
	alarmStates.SYRCLAW								=(n*=2);
	alarmStates.KPS										=(n*=2);
	alarmStates.SYRHOLD								=(n*=2);
	alarmStates.SYRAXIAL							=(n*=2);
	alarmStates.KVOEND								=(n*=2);
	alarmStates.BAGEMPTY							=(n*=2);
	alarmStates.TEMPERATURE						=(n*=2);
	alarmStates.DRIP									=(n*=2);
	alarmStates.NODROP								=(n*=2);
	alarmStates.LESSDROPS							=(n*=2);
	alarmStates.MANYDROPS							=(n*=2);
	alarmStates.FREEFLOW							=(n*=2);
	alarmStates.DRIPDISCONNECT				=(n*=2);
	alarmStates.AIR										=(n*=2);
	alarmStates.AIRBUBBLE							=(n*=2);
	alarmStates.AIRRATE								=(n*=2);
	alarmStates.NOAIRTEST							=(n*=2);
	alarmStates.CONTEND								=(n*=2);
	
	alarmStates2.DATA_LOCK							=(n=1);
	alarmStates2.XHLIMIT							=(n*=2);
	alarmStates2.TGCEND								=(n*=2);

	// Erinnerungsalarmstati
	remAlarmStates.NOREMALARM				=0;
	remAlarmStates.EDIT						=1;
	remAlarmStates.CONFIG_MENUE				=2;
	remAlarmStates.DEFAULT_MENUE			=3;
	remAlarmStates.DATA_LOCK				=4;
	remAlarmStates.INCOMPATIBLE_CAN_DEVICE	=5;
	remAlarmStates.PIGGYBACK				=6;
	remAlarmStates.TGC						=7;

	void( delete n );
