﻿/****************************************************************
 * Javascript-Intervalldefinitionen															*
 * in DHTML-Projekt SpaceOnline																	*
 * Copyright (c)2005 by B. Braun Melsungen AG										*
 * Copyright (c)2005 by B2A Corporate Marketing									*
 * All rights reserved																					*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-07																					*
 * by B2A Corporate Marketing, Kassel; mailto:dev-AT-b2a-DOT-de	*
 * Version: -																										*
 * Autor: B2A/koe																								*
 * Letzte Bearbeitung: 2006-09-05 14:16													*
 * durch: Koe																										*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Anmerkung: Das kleinste gemeinsame Vielfache der beiden			*
 * Intervalle sollte möglichst groß sein, damit der durch				*
 * Intervall-Überlagerung zustande kommende Fehlalarm möglichst	*
 * selten eintritt. Für die vorliegenden Intervalle liegt es bei*
 * 7,1 h.																												*
 ****************************************************************/

var	reloadintvl=1994,	// Intervall in ms für den Data Feeder; geändert lt. Syllwasschy/SMA
		chkintvl=5123;		// Intervall in ms für ServerCheck
