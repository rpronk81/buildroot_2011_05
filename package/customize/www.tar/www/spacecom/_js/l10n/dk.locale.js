﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: dk																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:57																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.dk = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-dk",
	lbl_developmentVersion:	"v1.4.0-dk, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Din browser skal være konfigureret til at printe baggrundsfarver samt billeder.\nI det tilfælde du ønsker at bekræfte indstillingen forud for print, tryk venligst på (annuller).\nVed at klikke på (OK) åbnes printdialog.\n\nMht. Microsoft Internet Explorer, kan denne indstilling bekræftes på følgende vis:\n\n  Hovedmenu 'Værktøj'\n    -> 'Internetindstillinger'\n      -> Registrer 'Avanceret'\n        -> Angiv enhed 'Printer'\n          -> Marker indstilling 'Print baggrundsfarver og billeder'.",
	ConfirmQuit:	"Ønsker du virkeligt at afslutte SpaceOnline?",
	ItemFiltered:	"Filtreret menuniveau åbnet.",
	ItemLocked:	"Dette menuniveau er blokeret!",
	NoFilterOnLockedItem:	"Et blokeret menuniveau kan ikke filtreres!",
	OK:	"OK",
	yes:	"ja",
	no:	"nej",
	printPDF:	"Brug venligst printfunktionen i Adobe® Reader.",

// Server & Data Feeder
	feedingData:	"(Indlæser data)",
	ServerDataAge:	"SpaceOnline har ikke været i stand til at indlæse apparatdata\neller systemdata siden den forrige opdatering.\nKontroller venligst apparatet!",
	ServerDataSuspect:	"SpaceOnline har ikke været i stand til at\nindlæse apparatdata eller systemdata siden den forrige opdatering.",
	ServerNumb:	"Bemærk: SpaceOnline WebServer sender tilsyneladende ikke data længere. Kontroller venligst serveren!\n\nI tilfælde af at du ønsker at genstarte bruger-interface efterfølgende, klik venligst her.",
	ServerSuspect:	"Afventer stadig SpaceOnline respons på forrige opdateringsforespørgsel…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Netværksforbindelse \/ SpaceOnline:",
	lbl_Help:	"Hjælp",
	lbl_Language:	"Sprog",
	lbl_loginName:	"Brugernavn: ",
	lbl_noLogin:	"&lt;Ingen log ind&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Vis lægemiddelnavn",
	lbl_in:	"i",
	lbl_Notation:	"tegnsystem.",
	adjLong:	"lang",
	adjShort:	"kort",
// - Legende
	lbl_Legend:	"Billedtekst:",
	lbl_LegendPumpAlarm:	"Alarm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pumpen er slukket \/ tændt",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"For-alarm",
	lbl_LegendPumpRunning:	"Pumpen kører",
	lbl_LegendPumpSelected:	"Pumpen er valgt <br \/>(efter museklik på symbol)",
	lbl_LegendPumpStandBy:	"Pumpe er i stand-by",
// - Fußzeile
	lbl_footerDisclaimer:	"Anvendelsesvilkår",
	lbl_footerImprint:	"Udgiver",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Tryk $verb for information",
	verbClose:	"Luk",
	verbOpen:	"Aaben",
// - Strukturübersicht
	lbl_Alarm:	"Alarm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"kvinde",
	lbl_genderMale:	"mand",
	lbl_Off:	"Sluk",
	lbl_On:	"Tænd",
	lbl_Prealarm:	"For-alarm!",
	lbl_Remalarm:	"Reminder",
	lbl_Selected:	"valgt",
	lbl_unknown:	"n\/a",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Luftsensor er deaktiveret",
	stat_ALARMACTUALQUIT:	"Aktuel alarm er afbrudt",
	stat_DATALOCK:	"DataLås er aktiveret",
	stat_DOSIS:	"Dosisratekalkulation",
	stat_KVOACTIVE:	"KVO aktiv",
	stat_MAINS:	"Strømforsyning",
	stat_MANBOL:	"Manuel bolus kører",
	stat_OFF:	"Apparatet er slukket",
	stat_PREALARMACTUALQUIT:	"Aktuel pre-alarm er afbrudt",
	stat_RUN:	"Apparatet kører ",
	stat_RUNREADY:	"Apparatet er tændt",
	stat_STANDBY:	"Apparatet står i stand-by",
	stat_SYSTEMACTIVE:	"Apparatet er tændt",
	stat_TPYBEGUN:	"Behandlingen er startet",
	stat_VOLBOL:	"Volumen bolus kører",
// - Voralarme
	preAlarm_Label:	"<strong>For-alarm(er):<\/strong>",
	preAlarm_ACCU:	"Batteriet er næsten tomt",
	preAlarm_DISPOSABLE:	"Sprøjten er næsten tom",
	preAlarm_KOR:	"KVO er aktiveret",
	preAlarm_NOPREALARM:	"<strong>Ingen for-alarm tilsluttet<\/strong>",
	preAlarm_TIME:	"Tiden er ved at udløbe",
	preAlarm_UNKNOWN:	"Ukendt",
	preAlarm_VTBD:	"VTBI er snart færdig",
	preAlarm_DATALOCK: "Forkert kode",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Kommunikationsfejl!",
	preAlarm_PIGGYBACK: "Piggyback infunderet",
	preAlarm_TGC: "Blodsukkermåling",
// - Alarme
	Alarm_Label:	"<strong>Alarm(er):<\/strong>",
	Alarm_ACCU:	"Batteriet er tomt",
	Alarm_ACCU_EMPTY:	"Batteriet er tomt",
	Alarm_ACCUCOVER:	"Batteridæksel er fjernet",
	Alarm_ACCUVOLTAGE:	"Batteristyrke for lav",
	Alarm_AIR:	"Luft i slangen",
	Alarm_AIRBUBBLE:	"Luftboble",
	Alarm_AIRRATE:	"Luftrate",
	Alarm_BAGEMPTY:	"Pose\/Flaske er tom",
	Alarm_CALDATA:	"Kalibrer apparatet",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Kontroller indløb",
	Alarm_DRIPDISCONNECT:	"Dråbesensor er ikke tilsluttet",
	Alarm_FREEFLOW:	"Free Flow",
	Alarm_KPS:	"Pumpestempelplade er ikke fikseret korrekt",
	Alarm_KVOEND:	"KVO færdig",
	Alarm_LESSDROPS:	"For få dråber",
	Alarm_MANYDROPS:	"For mange dråber",
	Alarm_NOACCU:	"Intet batteri er indsat",
	Alarm_NOAIRTEST:	"Luftsensor test mislykkedes",
	Alarm_NOALARM:	"<strong>Ingen alarm<\/strong>",
	Alarm_NODROP:	"Ingen dråber",
	Alarm_PRESSURE:	"Trykalarm",
	Alarm_SMBLOCK:	"Drev er blokeret",
	Alarm_STANDBY:	"Stand-by tid er udløbet",
	Alarm_SYRAXIAL:	"Sprøjten er ikke indsat korrekt",
	Alarm_SYRCLAW:	"Defekt gribearm",
	Alarm_SYREND:	"Sprøjten er tom",
	Alarm_SYRHOLD:	"Sprøjteholder",
	Alarm_TEMPERATURE:	"Temperaturalarm",
	Alarm_TIMEEND:	"Tiden er udløbet",
	Alarm_TPYANDPUMPDATA:	"Behandlingsdata blev genindstillet",
	Alarm_TPYDATA:	"Data blev genindstillet",
	Alarm_UNKNOWN:	"Ukendt",
	Alarm_VOLEND:	"VTBI infunderet",
	Alarm_DATA_LOCK:"Datalås",
	Alarm_XHLIMIT:"PCA-grænse nået",
	Alarm_TGCEND:"SGC slut",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Påmindelses-alarm",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Softlimit low is undergone",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Softlimit high is overgone",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Advarsel! Ingen Softlimits er indstillet"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.dk = {
	m1:		"Status",
	m2:		"Serviceinformation",
	m3:		"Konfiguration",
	m4:		"Status",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Afbryd handling"
};

// Benutzername
userdata.usrname = msg.dk.lbl_noLogin;
