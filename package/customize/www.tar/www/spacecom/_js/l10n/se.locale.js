﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: se																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:52																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.se = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-se",
	lbl_developmentVersion:	"v1.4.0-se, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Din webläsare måste konfigureras för att kunna skriva ut bakgrundsfärg och bilder.\nIfall du önskar bekräfta inställningar före utskrift, vänligen klicka på [Annullera].\nÖppna meny för utskrift genom att klicka på [OK].\n\nBekräfta inställningar i Microsoft Internet Explorer enligt följande:\n\n  Huvudmeny `Verktyg´\n    -> `Internet-alternativ´\n      -> Välj `Avancerat´\n        -> Skrolla till inställning för `Utskrift´\n          -> Markera inställning för `Skriv ut bakgrundsfärger och bilder´.",
	ConfirmQuit:	"Vill du verkligen stänga Hjälp om SpaceOnline?",
	ItemFiltered:	"Filtrerad menynivå är öppen.",
	ItemLocked:	"Denna menynivå är blockerad!",
	NoFilterOnLockedItem:	"Blockerad menynivå kan inte filtreras!",
	OK:	"OK",
	yes:	"ja",
	no:	"nej",
	printPDF:	"Vänligen använd funktion för\nutskrift i inbäddat Adobe® Reader.",

// Server & Data Feeder
	feedingData:	"[Datainmatning pågår]",
	ServerDataAge:	"Inmatning av data till SpaceOnline misslyckades\nbåde från system och pump efter senaste uppdatering.\nVänligen kontrollera utrustningen!",
	ServerDataSuspect:	"Inmatning av data från endera utrustning\neller system misslyckades sedan senaste uppdatering.",
	ServerNumb:	"Obs: Information från SpaceOnline webserver saknas. Vänligen kontrollera servern!\n\nKlicka här för att omstarta användargränssnitt.",
	ServerSuspect:	"Väntar på att SpaceOnline Webserver skall svara på senaste förfrågan…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Nätverksanslutning \/ SpaceOnline:",
	lbl_Help:	"Hjälp",
	lbl_Language:	"Språk",
	lbl_loginName:	"Inloggning namn: ",
	lbl_noLogin:	"&lt;No login&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Visa",
	lbl_in:	'',
	lbl_Notation:	"läkemedelsnamn.",
	adjLong:	"långt",
	adjShort:	"kort",
// - Legende
	lbl_Legend:	"Bildtext:",
	lbl_LegendPumpAlarm:	"Larm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pumpen är avstängd \/ på",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Förlarm \/ Aktiveringslarm",
	lbl_LegendPumpRunning:	"Pumpen är i drift",
	lbl_LegendPumpSelected:	"Vald pump <br \/>(efter klick på symbol)",
	lbl_LegendPumpStandBy:	"Pump i standby",
// - Fußzeile
	lbl_footerDisclaimer:	"Användarvillkor",
	lbl_footerImprint:	"Tillverkare",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Vänligen klicka på $verb informationsundermenyn",
	verbClose:	"stäng",
	verbOpen:	"öppna",
// - Strukturübersicht
	lbl_Alarm:	"Larm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"kvinna",
	lbl_genderMale:	"man",
	lbl_Off:	"Av",
	lbl_On:	"På",
	lbl_Prealarm:	"Förlarm!",
	lbl_Remalarm:	"Aktivering",
	lbl_Selected:	"vald",
	lbl_unknown:	"accepteras ej",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Luftsensorn är avaktiverad",
	stat_ALARMACTUALQUIT:	"Aktuellt larm tystat",
	stat_DATALOCK:	"Datalås är aktivt",
	stat_DOSIS:	"Doskalkylering",
	stat_KVOACTIVE:	"KVO aktivt",
	stat_MAINS:	"Nätanslutning",
	stat_MANBOL:	"Manuell bolus pågår",
	stat_OFF:	"Pumpen är avstängd",
	stat_PREALARMACTUALQUIT:	"Aktuellt förlarm tystat",
	stat_RUN:	"Pumpen är i drift",
	stat_RUNREADY:	"Pumpen är på",
	stat_STANDBY:	"Pumpen är i standby",
	stat_SYSTEMACTIVE:	"Pumpen är på",
	stat_TPYBEGUN:	"Terapin påbörjad",
	stat_VOLBOL:	"Bolus med förinställd volym pågår",
// - Voralarme
	preAlarm_Label:	"<strong>Förlarm(er):<\/strong>",
	preAlarm_ACCU:	"Nästan tomt batteri",
	preAlarm_DISPOSABLE:	"Nästan tom spruta",
	preAlarm_KOR:	"KVO aktivt",
	preAlarm_NOPREALARM:	"<strong>Ej förlarm<\/strong>",
	preAlarm_TIME:	"Tid nästan slut",
	preAlarm_UNKNOWN:	"Okänt",
	preAlarm_VTBD:	"VSSI nästan klar",
	preAlarm_DATALOCK: "Felaktig kod",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Kommunikationsfel!",
	preAlarm_PIGGYBACK: "PIGGY infunderad",
	preAlarm_TGC: "Blodglukos mätning",	
// - Alarme
	Alarm_Label:	"<strong>Larm(er):<\/strong>",
	Alarm_ACCU:	"Tomt batteri",
	Alarm_ACCU_EMPTY:	"Tomt batteri",
	Alarm_ACCUCOVER:	"Batterihöljet borttaget",
	Alarm_ACCUVOLTAGE:	"Batterispänning för låg",
	Alarm_AIR:	"Luft i aggregatet",
	Alarm_AIRBUBBLE:	"Luftlarm",
	Alarm_AIRRATE:	"Ackumulerad luftlarm",
	Alarm_BAGEMPTY:	"Flödeslarm! Inget flöde",
	Alarm_CALDATA:	"Kalibrering nödvändig",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Kontrollera anslutning",
	Alarm_DRIPDISCONNECT:	"Anslutning till droppsensor",
	Alarm_FREEFLOW:	"Fritt flöde",
	Alarm_KPS:	"Kolvplatta felaktigt ansluten",
	Alarm_KVOEND:	"KVO avslutad",
	Alarm_LESSDROPS:	"Flödeslarm! För få droppar",
	Alarm_MANYDROPS:	"Flödeslarm! För många droppar",
	Alarm_NOACCU:	"Batteri saknas",
	Alarm_NOAIRTEST:	"Test av luftsensor misslyckades",
	Alarm_NOALARM:	"<strong>Inget larm<\/strong>",
	Alarm_NODROP:	"Flödeslarm",
	Alarm_PRESSURE:	"Högt mottryck",
	Alarm_SMBLOCK:	"Drivning blockerad",
	Alarm_STANDBY:	"Standby slut",
	Alarm_SYRAXIAL:	"Sprutvingen felaktigt placerad",
	Alarm_SYRCLAW:	"Funktionsfel i gripklon",
	Alarm_SYREND:	"Tom spruta",
	Alarm_SYRHOLD:	"Sprutklämma",
	Alarm_TEMPERATURE:	"Temperaturlarm",
	Alarm_TIMEEND:	"Tid upphör",
	Alarm_TPYANDPUMPDATA:	"Terapidata återställd",
	Alarm_TPYDATA:	"Värden ändras till förv. inst.",
	Alarm_UNKNOWN:	"Okänt",
	Alarm_VOLEND:	"VSSI infunderad",
	Alarm_DATA_LOCK:"Datalås är aktivt",
	Alarm_XHLIMIT:"PCA gräns uppnådd",
	Alarm_TGCEND:"SGC slut",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Aktiveringslarm",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Softlimit min. är underskriden",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Softlimit max. är överskriden",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Varning! Softlimit har inte angivits"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.se = {
	m1:		"Status",
	m2:		"Serviceinformation",
	m3:		"Konfiguration",
	m4:		"Status",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Avsluta applikation"
};

// Benutzername
userdata.usrname = msg.se.lbl_noLogin;
