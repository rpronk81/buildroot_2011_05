﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: de																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:52																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.de = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-de",
	lbl_developmentVersion:	"v1.4.0-de, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Ihr Browser sollte so eingestellt sein, dass auch Hintergrundfarben und -bilder ausgedruckt werden.\nWenn Sie diese Einstellung zuerst prüfen möchten, so klicken Sie bitte auf [Abbrechen].\nEin Klick auf [OK] öffnet den Druckdialog.\n\nIm Microsoft Internet Explorer können Sie die Einstellung so überprüfen:\n\n  Hauptmenü `Extras´\n    -> `Internetoptionen´\n      -> Register `Erweitert´\n        -> Listenpunkt `Drucken´\n          -> Häkchen setzen für Einstellung `Hintergrundfarben und -bilder drucken´.",
	ConfirmQuit:	"SpaceOnline wirklich beenden?",
	ItemFiltered:	"Gefilterte Menüebene geöffnet.",
	ItemLocked:	"Diese Menüebene ist gesperrt!",
	NoFilterOnLockedItem:	"Gesperrte Menüebene kann nicht gefiltert werden!",
	OK:	"OK",
	yes:	"ja",
	no:	"nein",
	printPDF:	"Bitte benutzen Sie die Druckfunktion\ndes eingebetteten Adobe® Readers.",

	// Monats- und Tagesnamen
	ml:	['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],
	ms:	['Jan.','Feb.','Mrz.','Apr.','Mai','Juni','Juli','Aug.','Sep.','Okt.','Nov.','Dez.'],
	wl:	['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
	ws:	['So','Mo','Di','Mi','Do','Fr','Sa'],

// Server & Data Feeder
	feedingData:	"[Daten werden aktualisiert]",
	ServerDataAge:	"Achtung: SpaceOnline hat seit dem letzten Aktualisierungszyklus weder Geräte- noch Systemdaten geliefert.\nBitte überprüfen Sie das Gerät!",
	ServerDataSuspect:	"SpaceOnline hat seit dem letzten Aktualisierungszyklus Geräte- oder Systemdaten nicht geliefert.",
	ServerNumb:	"Achtung: Es scheint, als schicke der SpaceOnline-WebServer keine Daten mehr. Bitte überprüfen Sie den Server!\n\nWenn Sie die Benutzeroberfläche neu laden möchten, klicken Sie bitte anschließend genau hier.",
	ServerSuspect:	"Die Antwort auf die letzte Aktualisierungsanfrage an den SpaceOnline-Webserver steht noch aus …",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Netzwerkverbindung \/ SpaceOnline:",
	lbl_Help:	"Hilfe",
	lbl_Language:	"Sprache",
	lbl_loginName:	"Login-Name: ",
	lbl_noLogin:	"&lt;Kein Login&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Medikamentennamen",
	lbl_in:	"in",
	lbl_Notation:	"Schreibweise anzeigen.",
	adjLong:	"langer",
	adjShort:	"kurzer",
// - Legende
	lbl_Legend:	"Legende:",
	lbl_LegendPumpAlarm:	"Alarm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pumpe ist aus-\/eingeschaltet",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Vor- oder Erinnerungsalarm",
	lbl_LegendPumpRunning:	"Pumpe läuft",
	lbl_LegendPumpSelected:	"Pumpe ist selektiert (nach Mausklick auf Symbol)",
	lbl_LegendPumpStandBy:	"Pumpe ist in Stand-By",
// - Fußzeile
	lbl_footerDisclaimer:	"Nutzungsbedingungen",
	lbl_footerImprint:	"Impressum",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Bitte klicken, um Informationsfeld zu $verb.",
	verbClose:	"schließen",
	verbOpen:	"öffnen",
// - Strukturübersicht
	lbl_Alarm:	"Alarm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"weiblich",
	lbl_genderMale:	"männlich",
	lbl_Off:	"Aus",
	lbl_On:	"Ein",
	lbl_Prealarm:	"Voralarm!",
	lbl_Remalarm:	"Erinnerung!",
	lbl_Selected:	"selektiert",
	lbl_unknown:	"n. b.",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Luftsensor ist ausgeschaltet",
	stat_ALARMACTUALQUIT:	"Aktueller Alarm ist quittiert",
	stat_DATALOCK:	"DataLock aktiv",
	stat_DOSIS:	"Dosiskalkulation aktiv",
	stat_KVOACTIVE:	"KVO aktiv",
	stat_MAINS:	"Netzbetrieb",
	stat_MANBOL:	"Manueller Bolus aktiv",
	stat_OFF:	"Gerät ist ausgeschaltet",
	stat_PREALARMACTUALQUIT:	"Aktueller Voralarm ist quittiert",
	stat_RUN:	"Pumpe läuft",
	stat_RUNREADY:	"Gerät ist eingeschaltet",
	stat_STANDBY:	"Gerät ist in Bereitschaft",
	stat_SYSTEMACTIVE:	"Gerät ist eingeschaltet",
	stat_TPYBEGUN:	"Therapie hat begonnen",
	stat_VOLBOL:	"Volumen-Bolus aktiv",
// - Voralarme
	preAlarm_Label:	"Voralarm(e):",
	preAlarm_ACCU:	"Akku fast leer",
	preAlarm_DISPOSABLE:	"Spritze fast leer",
	preAlarm_KOR:	"KVO aktiv",
	preAlarm_NOPREALARM:	"<strong>Kein Voralarm<\/strong>",
	preAlarm_TIME:	"Zeit fast erreicht",
	preAlarm_UNKNOWN:	"Unbekannt",
	preAlarm_VTBD:	"Vol. fast erreicht",
	preAlarm_DATALOCK: "Ungültiger Code",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Kommunikationsfehler!",
	preAlarm_PIGGYBACK: "Piggyback infundiert",
	preAlarm_TGC: "Blutglukosemessung",
// - Alarme
	Alarm_Label:	"Alarm(e):",
	Alarm_ACCU:	"Akku leer",
	Alarm_ACCU_EMPTY:	"Akku leer",
	Alarm_ACCUCOVER:	"Akkudeckel offen",
	Alarm_ACCUVOLTAGE:	"Akkuspannung zu gering",
	Alarm_AIR:	"Kumulierte Luft",
	Alarm_AIRBUBBLE:	"Luftblase",
	Alarm_AIRRATE:	"Luftratenalarm",
	Alarm_BAGEMPTY:	"Infusionsbehälter leer",
	Alarm_CALDATA:	"Gerät kalibrieren",
	Alarm_CONTEND:	"Beutelende",
	Alarm_DRIP:	"Zulauf prüfen",
	Alarm_DRIPDISCONNECT:	"Tropfensensor Verbindung",
	Alarm_FREEFLOW:	"Durchfluss",
	Alarm_KPS:	"Kolbenplatte ohne Kontakt",
	Alarm_KVOEND:	"KVO beendet",
	Alarm_LESSDROPS:	"Zu wenige Tropfen",
	Alarm_MANYDROPS:	"Zu viele Tropfen",
	Alarm_NOACCU:	"Kein Akku im Gerät",
	Alarm_NOAIRTEST:	"kein Lufttest durch KuP",
	Alarm_NOALARM:	"<strong>Kein Alarm<\/strong>",
	Alarm_NODROP:	"Keine Tropfen",
	Alarm_PRESSURE:	"Druck zu hoch",
	Alarm_SMBLOCK:	"Antrieb blockiert",
	Alarm_STANDBY:	"Standbyzeit abgelaufen",
	Alarm_SYRAXIAL:	"Spritzenlage inkorrekt",
	Alarm_SYRCLAW:	"Krallenfehlfunktion",
	Alarm_SYREND:	"Spritze leer",
	Alarm_SYRHOLD:	"Spritzenbügel",
	Alarm_TEMPERATURE:	"Temperaturalarm",
	Alarm_TIMEEND:	"Zeit erreicht",
	Alarm_TPYANDPUMPDATA:	"Therapiedaten zurückgesetzt",
	Alarm_TPYDATA:	"Daten wurden zurückgesetzt",
	Alarm_UNKNOWN:	"Unbekannt",
	Alarm_VOLEND:	"Volumen infundiert",
	Alarm_DATA_LOCK:"Data Lock",
	Alarm_XHLIMIT:"PCA Limit wurde erreicht",
	Alarm_TGCEND:"SGC Ende",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Erinnerungsalarm",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unbekannter Erinnerungsalarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Softlimit ist unterschritten",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Oberes Softlimit ist überschritten",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Achtung: Keine Softlimits gesetzt!"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.de = {
	m1:		"Status",
	m2:		"Service Information",
	m3:		"Konfiguration",
	m4:		"Status",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Programm beenden"
};

// Benutzername
userdata.usrname = msg.de.lbl_noLogin;
