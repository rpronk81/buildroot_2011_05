﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: fr																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:53																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

// Versionsbezeichnungen
msg.fr = {
	lbl_officialVersion: "v1.4.0-fr",
	lbl_developmentVersion:	"v1.4.0-fr, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Votre Browser devrait être configuré pour imprimer les couleurs de fond ainsi que les images.\nSi vous souhaitiez vérifier les paramètres avant impression, sélectionnez [Annuler].\nLa sélection de [OK] ouvre la boîte de dialogue impression.\n\nComme pour l'Internet Explorer de Microsoft, ce paramétrage peut être validé comme suit :\n\n  Menu principal `Outils´\n    -> `Option Internet´\n      -> Registre `Avancé´\n        -> Liste item `Impression´\n          -> Mettre une croix pour paramétrer `Impression couleurs de fond et images´.",
	ConfirmQuit:	"Voulez vous réellement quitter SpaceOnline ?",
	ItemFiltered:	"Le niveau menu filtré est accessible",
	ItemLocked:	"Ce niveau du menu est verrouillé !",
	NoFilterOnLockedItem:	"Un niveau verrouillé du menu ne peut être filtré !",
	OK:	"OK",
	yes:	"Oui",
	no:	"Non",
	printPDF:	"Veuillez utiliser la fonction\nimpression de l'application.",

// Server & Data Feeder
	feedingData:	"[Chargement des données]",
	ServerDataAge:	"Malgré le rafraîchissement, l'application SpaceOnline\na échoué dans le chargement des données de l'appareil et du système.\nVeuillez vérifier l'appareil.",
	ServerDataSuspect:	"Malgré le rafraîchissement, l'application SpaceOnline a échoué\ndans le chargement des données de l'appareil ou du système.",
	ServerNumb:	"Attention : L'application Web Server SpaceOnline ne semble plus assurer l'envoi des données. Vérifier le serveur.\n\nDans le cas ou vous souhaiteriez redémarrer votre interface par la suite, cliquez ici.",
	ServerSuspect:	"En attente du Web Server SpaceOnline pour répondre à votre précédente requête…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Connexion réseau \/ SpaceOnline :",
	lbl_Help:	"Aide",
	lbl_Language:	"Langue",
	lbl_loginName:	"Nom utilisateur : ",
	lbl_noLogin:	"&lt;Absence de login&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Afficher nom médicaments",
	lbl_in:	'',
	lbl_Notation:	'',
	adjLong:	"complet",
	adjShort:	"abrégé",
// - Legende
	lbl_Legend:	"Légende :",
	lbl_LegendPumpAlarm:	"Alarme",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pompe OFF \/ ON",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Préalarme \/ Alarme de rappel",
	lbl_LegendPumpRunning:	"Pompe en fonction",
	lbl_LegendPumpSelected:	"Pompe sélectionnée (après sélection du symbole à l'aide de la souris)",
	lbl_LegendPumpStandBy:	"Pompe en pause",
// - Fußzeile
	lbl_footerDisclaimer:	"Termes de l'utilisation",
	lbl_footerImprint:	"Empreinte",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Sélectionner $verb onglet information",
	verbClose:	"fermer",
	verbOpen:	"ouvrir",
// - Strukturübersicht
	lbl_Alarm:	"Alarme !",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"F",
	lbl_genderMale:	"M",
	lbl_Off:	"OFF",
	lbl_On:	"ON",
	lbl_Prealarm:	"Préalarme !",
	lbl_Remalarm:	"Al. de rappel",
	lbl_Selected:	"Sélection.",
	lbl_unknown:	"Non disponible",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Capteur d'air désactivé",
	stat_ALARMACTUALQUIT:	"Alarme acquittée",
	stat_DATALOCK:	"Mode DataLock activé",
	stat_DOSIS:	"Mode calcul de dose",
	stat_KVOACTIVE:	"Mode MVO activé",
	stat_MAINS:	"Opération principale",
	stat_MANBOL:	"Bolus manuel en cours",
	stat_OFF:	"Appareil éteint",
	stat_PREALARMACTUALQUIT:	"Préalarme acquittée",
	stat_RUN:	"Perfusion en cours",
	stat_RUNREADY:	"Appareil allumé",
	stat_STANDBY:	"Appareil en pause",
	stat_SYSTEMACTIVE:	"Appareil allumé",
	stat_TPYBEGUN:	"Démarrage thérapie",
	stat_VOLBOL:	"Bolus avec présélection de volume en cours",
// - Voralarme
	preAlarm_Label:	"<strong>Préalarme(s) :<\/strong>",
	preAlarm_ACCU:	"Batterie presque vide",
	preAlarm_DISPOSABLE:	"Seringue presque vide",
	preAlarm_KOR:	"Mode MVO activé",
	preAlarm_NOPREALARM:	"<strong>Pas de préalarme<\/strong>",
	preAlarm_TIME:	"Temps presque dépassé",
	preAlarm_UNKNOWN:	"Inconnu",
	preAlarm_VTBD:	"VAP presque terminé",
	preAlarm_DATALOCK: "Code erroné",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "Erreur communication",
	preAlarm_PIGGYBACK: "Perfusion Piggyback 2",
	preAlarm_TGC: "Mesure tx glucose Sg.",
// - Alarme
	Alarm_Label:	"<strong>Alarme(s) :<\/strong>",
	Alarm_ACCU:	"Batterie vide",
	Alarm_ACCU_EMPTY:	"Batterie vide",
	Alarm_ACCUCOVER:	"Couvercle batterie retiré",
	Alarm_ACCUVOLTAGE:	"Voltage batterie trop faible",
	Alarm_AIR:	"Air tubulure",
	Alarm_AIRBUBBLE:	"Bulle d'air",
	Alarm_AIRRATE:	"Débit d'air",
	Alarm_BAGEMPTY:	"Poche vide",
	Alarm_CALDATA:	"Calibrer appareil",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Vérifier l'admission",
	Alarm_DRIPDISCONNECT:	"Capteur gouttes déconnecté",
	Alarm_FREEFLOW:	"Ecoulement libre",
	Alarm_KPS:	"Les ailettes ne sont pas correctement fixées",
	Alarm_KVOEND:	"Mode MVO terminé",
	Alarm_LESSDROPS:	"Pas assez de gouttes",
	Alarm_MANYDROPS:	"Trop de gouttes",
	Alarm_NOACCU:	"Absence de batterie",
	Alarm_NOAIRTEST:	"Echec au test capteur d'air",
	Alarm_NOALARM:	"<strong>Absence d'alarme<\/strong>",
	Alarm_NODROP:	"Absence de gouttes",
	Alarm_PRESSURE:	"Alarme de pression",
	Alarm_SMBLOCK:	"Bras bloqué",
	Alarm_STANDBY:	"Temps de pause expiré",
	Alarm_SYRAXIAL:	"Seringue mal insérée",
	Alarm_SYRCLAW:	"Dysfonction des griffes de la tête",
	Alarm_SYREND:	"Seringue vide",
	Alarm_SYRHOLD:	"Verrou de seringue",
	Alarm_TEMPERATURE:	"Alarme de température",
	Alarm_TIMEEND:	"Temps expiré",
	Alarm_TPYANDPUMPDATA:	"Données thérapie remises à zéro",
	Alarm_TPYDATA:	"Données remises à zéro",
	Alarm_UNKNOWN:	"Inconnu",
	Alarm_VOLEND:	"VAP perfusé",
	Alarm_DATA_LOCK:"Verrouillage clavier",
	Alarm_XHLIMIT:"Limite PCA atteinte",
	Alarm_TGCEND:"Fin SGC",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Alarme de rappel",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	'',
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Limite inférieure dépassée",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Limite supérieure dépassée",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Attention : Aucune valeurs limites programmées"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.fr = {
	m1:		"Etat",
	m2:		"Service Information",
	m3:		"Configuration",
	m4:		"Etat",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Quitter l'application"
};

// Benutzername
userdata.usrname = msg.fr.lbl_noLogin;
