﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: fi																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:53																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.fi = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-fi",
	lbl_developmentVersion:	"v1.4.0-fi, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Selailimesi on oltava konfiguroitu tulostamaan taustavärejä ja kuvia.\nJos haluat varmistaa tulostusasetukset, paina peruuta [Cancel].\nAvaa tulostusyhteys painamalla [OK].\n\nMicrosoftin Internet selailimessa voit vahvistaa asetukset seuraavalla tavalla:\n\n  Päävalikko -> `Työkalut´\n    -> `Internet-asetukset´\n      -> `Lisäasetukset´\n        ->   Hae listalta `Tulostaminen´\n          ->   Merkitse asetus `Tulosta taustavärit ja kuvat´.",
	ConfirmQuit:	"Haluatko lopettaa SpaceOnline ohjelman käytön?",
	ItemFiltered:	"Suodatettu valikkotaso avattu.",
	ItemLocked:	"Tämä valikkotaso on lukittu!",
	NoFilterOnLockedItem:	"Lukittua valikkotasoa ei voi suodattaa!",
	OK:	"OK",
	yes:	"kyllä",
	no:	"ei",
	printPDF:	"Käytä Adobe® Readeriin\nsisäistä tulostustoimitoa",

// Server & Data Feeder
	feedingData:	"[Tiedonsiirto käynnissä]",
	ServerDataAge:	"SpaceOnline ei ole onnistunut lähettämään laitetietoja\neikä järjestelmätietoja edellisen virkistyskierron jälkeen.\nTarkista laite!",
	ServerDataSuspect:	"SpaceOnline on epäonnistunut lähettämään joko laitetiedot\ntai järjestelmätiedot edellisen virkistyskierron jälkeen.",
	ServerNumb:	"Huom: SpaceOnline verkkopalvelin ei enää lähetä tietoa. Tarkista palvelin!\n\nJos haluat että käyttöliittymä käynnistyy myöhemmin uudelleen, paina tästä.",
	ServerSuspect:	"Odottaa edelleen SpaceOnline WebServerin vastausta edelliseen virkistyspyyntöön…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Verkkoyhteys \/ SpaceOnline:",
	lbl_Help:	"Auttaa",
	lbl_Language:	"Kieli",
	lbl_loginName:	"Kirjautumisnimi: ",
	lbl_noLogin:	"&lt;No login&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Näytä lääkenimet",
	lbl_in:	'',
	lbl_Notation:	"esitysmuodossa.",
	adjLong:	"pitkä",
	adjShort:	"lyhyt",
// - Legende
	lbl_Legend:	"Selitys:",
	lbl_LegendPumpAlarm:	"Hälytys",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pumpun virta off \/ on",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Ennakko- \/ Muistutushälytys",
	lbl_LegendPumpRunning:	"Pumppu on käynnissä",
	lbl_LegendPumpSelected:	"Pumppu on valittu (kun symbolia on painettu hiirellä)",
	lbl_LegendPumpStandBy:	"Pumppu on taukotilassa",
// - Fußzeile
	lbl_footerDisclaimer:	"Käyttöehdot",
	lbl_footerImprint:	"Painopaikka",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Paina $verb info-ikkuna",
	verbClose:	"sulje",
	verbOpen:	"avaa",
// - Strukturübersicht
	lbl_Alarm:	"Hälytys!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"nainen",
	lbl_genderMale:	"mies",
	lbl_Off:	"Off",
	lbl_On:	"On",
	lbl_Prealarm:	"Ennakkohälytys!",
	lbl_Remalarm:	"Muistutus!",
	lbl_Selected:	"valittu",
	lbl_unknown:	"tuntematon",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Ilmatunnistin ei ole käytössä",
	stat_ALARMACTUALQUIT:	"Hälytys on kuitattu",
	stat_DATALOCK:	"Datalukitus on käytössä",
	stat_DOSIS:	"Annoslaskenta",
	stat_KVOACTIVE:	"Aukipito käynnissä",
	stat_MAINS:	"Käyttö verkkovirralla",
	stat_MANBOL:	"Manuaalibolus käynnissä",
	stat_OFF:	"Laitteen virta on katkaistuna",
	stat_PREALARMACTUALQUIT:	"Ennakkohälytys on kuitattu",
	stat_RUN:	"Laite on käynnissä",
	stat_RUNREADY:	"Laitteen virta on kytkettynä",
	stat_STANDBY:	"Laite on Tauko-tilassa",
	stat_SYSTEMACTIVE:	"Laitteen virta on kytkettynä",
	stat_TPYBEGUN:	"Infuusio on alkanut",
	stat_VOLBOL:	"Bolus* käynnissä (*volyymi esivalittu)",
// - Voralarme
	preAlarm_Label:	"<strong>Ennakkohälytys\/-hälytykset:<\/strong>",
	preAlarm_ACCU:	"Akku lähes tyhjä",
	preAlarm_DISPOSABLE:	"Ruisku lähes tyhjä",
	preAlarm_KOR:	"Aukipito käynnissä",
	preAlarm_NOPREALARM:	"<strong>Ei ennakkohälytystä<\/strong>",
	preAlarm_TIME:	"Aikarajan ennakkohälytys",
	preAlarm_UNKNOWN:	"Tuntematon",
	preAlarm_VTBD:	"Volyymirajan ennakkohälytys",
	preAlarm_DATALOCK: "Väärä koodi",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Virhe tiedonsiirrossa!",
	preAlarm_PIGGYBACK: "Piggyback 2 annettu",
	preAlarm_TGC: "Verensokerin  mittaus",
// - Alarme
	Alarm_Label:	"<strong>Hälytys\/hälytykset:<\/strong>",
	Alarm_ACCU:	"Akku tyhjä",
	Alarm_ACCU_EMPTY:	"Akku tyhjä",
	Alarm_ACCUCOVER:	"Akkukotelon kansi puuttuu",
	Alarm_ACCUVOLTAGE:	"Akkukapasiteetti liian alhainen",
	Alarm_AIR:	"Ilmaa letkustossa",
	Alarm_AIRBUBBLE:	"Ilmakupla",
	Alarm_AIRRATE:	"Ilmahälytysrajat",
	Alarm_BAGEMPTY:	"Pussi \/ pullo tyhjä",
	Alarm_CALDATA:	"Laite kalibroitava",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Virtauseste pumpun yläpuolella",
	Alarm_DRIPDISCONNECT:	"Tippatunnistin ei kytkettynä",
	Alarm_FREEFLOW:	"Vapaavirtaus",
	Alarm_KPS:	"Ruiskun kanta ei kunnolla kiinnitetty",
	Alarm_KVOEND:	"Aukipito päättynyt",
	Alarm_LESSDROPS:	"Liian vähän tippoja",
	Alarm_MANYDROPS:	"Liikaa tippoja",
	Alarm_NOACCU:	"Akku puuttuu",
	Alarm_NOAIRTEST:	"Ilmatunnistimen testi ei läpäisty",
	Alarm_NOALARM:	"<strong>Ei hälytystä<\/strong>",
	Alarm_NODROP:	"Ei tippoja",
	Alarm_PRESSURE:	"Painehälytys",
	Alarm_SMBLOCK:	"Työntömekanismi juuttunut",
	Alarm_STANDBY:	"Tauko päättynyt",
	Alarm_SYRAXIAL:	"Väärä ruiskun kiinnitys",
	Alarm_SYRCLAW:	"Vika työntömekanismin kynsissä",
	Alarm_SYREND:	"Ruisku tyhjä",
	Alarm_SYRHOLD:	"Ruiskun salpa",
	Alarm_TEMPERATURE:	"Lämpötilahälytys",
	Alarm_TIMEEND:	"Aika kulunut loppuun",
	Alarm_TPYANDPUMPDATA:	"Infuusioarvot poistettu",
	Alarm_TPYDATA:	"Tiedot poistettu",
	Alarm_UNKNOWN:	"Tuntematon",
	Alarm_VOLEND:	"Volyymiraja saavutettu",
	Alarm_DATA_LOCK:"Datalukitus",
	Alarm_XHLIMIT:"PCA raja saavutettu",
	Alarm_TGCEND:"SGC lopetettu",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Muistutushälytys",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Suositusraja (minimi) on alitettu",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Suositusraja (maksimi) on ylitetty",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Varoitus! Suositusrajoja ei ole asetettu"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.fi = {
	m1:		"Tiedot",
	m2:		"Huoltoinformaatio",
	m3:		"Konfiguraatio",
	m4:		"Tiedot",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Lopeta sovellus"
};

// Benutzername
userdata.usrname = msg.fi.lbl_noLogin;
