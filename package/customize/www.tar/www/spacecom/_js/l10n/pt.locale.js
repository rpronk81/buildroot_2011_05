﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: pt																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:53																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

// Versionsbezeichnungen
msg.pt = {
	lbl_officialVersion: "v1.4.0-pt",
	lbl_developmentVersion:	"v1.4.0-pt, Rel. 3",


// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"O browser deve ser configurado para impressão de cores de fundo e imagens.\nSe desejar verificar as definições antes da impressão, por favor clique em [Cancel].\nClicar em [OK] abre a Janela de Impressão.\n\nPara o Microsoft Internet Explorer as definições podem ser verificadas através de:\n\n  Menu Principal `Tools´\n    -> `Internet options´\n      -> Aceder `Advanced´\n        -> List item `Printing´\n          -> Seleccionar `Print background colors and images´.",
	ConfirmQuit:	"Quer sair do SpaceOnline?",
	ItemFiltered:	"Aberto o nível de menu `filtrado´.",
	ItemLocked:	"Este nível de menu está bloqueado!",
	NoFilterOnLockedItem:	"Um nível de menu bloqueado não pode ser filtrado!",
	OK:	"OK",
	yes:	"Sim",
	no:	"Não",
	printPDF:	"Por favor use a função de\nimpressão do Adobe® Reader.",

// Server & Data Feeder
	feedingData:	"[A receber dados]",
	ServerDataAge:	"O SpaceOnline falhou por problemas com o Device e com o Sistema.\nPor favor verfifique o Device!",
	ServerDataSuspect:	"O SpaceOnline falhou por\nproblemas com o Device ou com o Sistema.",
	ServerNumb:	"Atenção: o Servidor do SpaceOnline não está a enviar dados. Por favor, verifique o Servidor!\n\nApós a verificação, se quiser reiniciar o user interface, clique aqui.",
	ServerSuspect:	"A aguardar resposta do Servidor do SpaceOnline…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Ligação de Rede \/ SpaceOnline:",
	lbl_Help:	"Ajuda",
	lbl_Language:	"Idioma",
	lbl_loginName:	"ID Login: ",
	lbl_noLogin:	"&lt;Sem Login&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Mostrar Nome do Fármaco com:",
	lbl_in:	'',
	lbl_Notation:	'',
	adjLong:	"Completo",
	adjShort:	"Abreviatura",
// - Legende
	lbl_Legend:	"Legenda:",
	lbl_LegendPumpAlarm:	"Alarme",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Equipamento off \/ on",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Pré-Alarme \/ Al. Repetitivo",
	lbl_LegendPumpRunning:	"Equip. em funcionamento",
	lbl_LegendPumpSelected:	"Seleccionar Equipamento <br \/>(após clicar com o rato)",
	lbl_LegendPumpStandBy:	"Equipamento em stand-by",
// - Fußzeile
	lbl_footerDisclaimer:	"Disposições de Utilização",
	lbl_footerImprint:	"Imprimir",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Por favor clique para aceder a informações do sub-painel $verb",
	verbClose:	"Fechado",
	verbOpen:	"Aberto",
// - Strukturübersicht
	lbl_Alarm:	"Alarme!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"Feminino",
	lbl_genderMale:	"Masculino",
	lbl_Off:	"Off",
	lbl_On:	"On",
	lbl_Prealarm:	"Pré-Alarme!",
	lbl_Remalarm:	"Al. Repetit.",
	lbl_Selected:	"seleccion.",
	lbl_unknown:	"n.d.",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Sensor de Ar desactivado",
	stat_ALARMACTUALQUIT:	"Alarme actual aceite",
	stat_DATALOCK:	"Bloqueio de Dados activado",
	stat_DOSIS:	"Cálculo de Dose",
	stat_KVOACTIVE:	"KVO activado",
	stat_MAINS:	"Alimentação de corrente",
	stat_MANBOL:	"Bolus Manual em administração",
	stat_OFF:	"Equipamento desligado",
	stat_PREALARMACTUALQUIT:	"Pré-Alarme actual aceite",
	stat_RUN:	"Equipamento em funcionamento",
	stat_RUNREADY:	"Equipamento ligado",
	stat_STANDBY:	"Equipamento em stand-by",
	stat_SYSTEMACTIVE:	"Equipamento ligado",
	stat_TPYBEGUN:	"Iniciou-se a Terapêutica",
	stat_VOLBOL:	"Volume de Bolus em administração",
// - Voralarme
	preAlarm_Label:	"<strong>Pré-Alarme(s):<\/strong>",
	preAlarm_ACCU:	"Alarme de Bateria",
	preAlarm_DISPOSABLE:	"Seringa quase vazia",
	preAlarm_KOR:	"KVO Activo",
	preAlarm_NOPREALARM:	"<strong>Sem Pré-Alarme<\/strong>",
	preAlarm_TIME:	"Tempo próximo do final",
	preAlarm_UNKNOWN:	"Desconhecido",
	preAlarm_VTBD:	"VTBI próximo do final",
	preAlarm_DATALOCK: "Código errado",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Erro de Comunicação!",
	preAlarm_PIGGYBACK: "Piggyback 2 infundido",
	preAlarm_TGC: "Medição Glucose sang.",
// - Alarme
	Alarm_Label:	"<strong>Alarme(s):<\/strong>",
	Alarm_ACCU:	"Bateria descarregada",
	Alarm_ACCU_EMPTY:	"Bateria descarregada",
	Alarm_ACCUCOVER:	"Tampa da bateria removida",
	Alarm_ACCUVOLTAGE:	"Voltagem da bateria muito baixa",
	Alarm_AIR:	"Ar na linha",
	Alarm_AIRBUBBLE:	"Bolhas de ar",
	Alarm_AIRRATE:	"Volume de ar por hora",
	Alarm_BAGEMPTY:	"Verifique a linha a montante (frasco)",
	Alarm_CALDATA:	"Calibrar equipamento",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Gota",
	Alarm_DRIPDISCONNECT:	"Conexão Sensor de Gota perdida",
	Alarm_FREEFLOW:	"Fluxo Livre",
	Alarm_KPS:	"Placa do piston destrancada",
	Alarm_KVOEND:	"KVO finalizado",
	Alarm_LESSDROPS:	"Muito poucas gotas",
	Alarm_MANYDROPS:	"Demasiadas gotas",
	Alarm_NOACCU:	"Nenhuma bateria inserida",
	Alarm_NOAIRTEST:	"Falhou o teste do Sensor de Ar",
	Alarm_NOALARM:	"<strong>Sem Alarme<\/strong>",
	Alarm_NODROP:	"Sem gotas",
	Alarm_PRESSURE:	"Pressão elevada",
	Alarm_SMBLOCK:	"Drive bloqueada",
	Alarm_STANDBY:	"Tempo de stand-by expirado",
	Alarm_SYRAXIAL:	"Seringa inserida incorrectamente",
	Alarm_SYRCLAW:	"Disfunção da garra",
	Alarm_SYREND:	"Seringa vazia",
	Alarm_SYRHOLD:	"Suporte seringa",
	Alarm_TEMPERATURE:	"Temperatura demasiado baixa",
	Alarm_TIMEEND:	"Tempo concluído",
	Alarm_TPYANDPUMPDATA:	"Dados de Terap. repostos",
	Alarm_TPYDATA:	"Dados foram repostos",
	Alarm_UNKNOWN:	"Desconhecido",
	Alarm_VOLEND:	"VTBI finalizado",
	Alarm_DATA_LOCK:"Protecção de Dados",
	Alarm_XHLIMIT:"Atingido Limite PCA",
	Alarm_TGCEND:"Finalizado SGC",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Alarme Repetitivo",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	'',
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"O Softlimit inferior é mais baixo que o limite estabelecido",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"O Softlimit superior é mais alto que o limite estabelecido",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Atenção! Não foram definidos Softlimits"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.pt = {
	m1:		"Estado",
	m2:		"Informação de Serviço",
	m3:		"Configuração",
	m4:		"Estado",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Sair da Aplicação"
};

// Benutzername
userdata.usrname = msg.pt.lbl_noLogin;
