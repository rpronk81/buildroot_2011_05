﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: en																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:54																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.en = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-en",
	lbl_developmentVersion:	"v1.4.0-en, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Your browser should be configured to print background colors and images as well.\nIn case you'd like to verify the setting prior to printing, please click on [Cancel].\nClicking on [OK] opens the printing dialog.\n\nAs for Microsoft Internet Explorer this setting may be verified as follows:\n\n  Main menu `Tools´\n    -> `Internet options´\n      -> Register `Advanced´\n        -> List item `Printing´\n          -> Put checkmark for setting `Print background colors and images´.",
	ConfirmQuit:	"Do you really want to end SpaceOnline?",
	ItemFiltered:	"Filtered menu level opened.",
	ItemLocked:	"This menu level is blocked!",
	NoFilterOnLockedItem:	"Locked menu level must not be filtered!",
	OK:	"OK",
	yes:	"yes",
	no:	"no",
	printPDF:	"Please use the print function\nof the embedded Adobe® Reader.",

	// Monats- und Tagesnamen
	ml:	['January','February','March','April','May','June','July','August','September','October','November','December'],
	ms:	['Jan.','Feb.','Mar.','Apr.','May','June','July','Aug.','Sep.','Oct.','Nov.','Dec.'],
	wl:	['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
	ws:	['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],

// Server & Data Feeder
	feedingData:	"[Data feeding in progress]",
	ServerDataAge:	"SpaceOnline has failed to feed both the\ndevice data and the system data since the previous refresh cycle.\nPlease check device!",
	ServerDataSuspect:	"SpaceOnline has failed to feed either the\ndevice data or the system data since the previous refresh cycle.",
	ServerNumb:	"Attention: SpaceOnline WebServer doesn't seem to send data any longer. Please check the server!\n\nIn case you want the user interface to be restarted afterwards, just click right here.",
	ServerSuspect:	"Still waiting for SpaceOnline WebServer to respond the previous refresh inquiry…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Network connection \/ SpaceOnline:",
	lbl_Help:	"Help",
	lbl_Language:	"Language",
	lbl_loginName:	"Login name: ",
	lbl_noLogin:	"&lt;No login&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Show drug names",
	lbl_in:	"in",
	lbl_Notation:	"notation.",
	adjLong:	"long",
	adjShort:	"short",
// - Legende
	lbl_Legend:	"Legend:",
	lbl_LegendPumpAlarm:	"Alarm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pump is switched off \/ on",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Pre- or reminder alarm",
	lbl_LegendPumpRunning:	"Pump is running",
	lbl_LegendPumpSelected:	"Pump is selected (after mouse click on symbol)",
	lbl_LegendPumpStandBy:	"Pump is in stand-by",
// - Fußzeile
	lbl_footerDisclaimer:	"Terms of Use",
	lbl_footerImprint:	"Imprint",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Please click to $verb information sub-panel",
	verbClose:	"close",
	verbOpen:	"open",
// - Strukturübersicht
	lbl_Alarm:	"Alarm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"female",
	lbl_genderMale:	"male",
	lbl_Off:	"Off",
	lbl_On:	"On",
	lbl_Prealarm:	"Pre-alarm!",
	lbl_Remalarm:	"Reminder",
	lbl_Selected:	"selected",
	lbl_unknown:	"n\/a",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Air sensor ist deactivated",
	stat_ALARMACTUALQUIT:	"Actual alarm is quit",
	stat_DATALOCK:	"DataLock is active",
	stat_DOSIS:	"Dose rate calculation",
	stat_KVOACTIVE:	"KVO active",
	stat_MAINS:	"Mains operation",
	stat_MANBOL:	"Manual bolus running",
	stat_OFF:	"Device is switched off",
	stat_PREALARMACTUALQUIT:	"Actual pre-alarm is quit",
	stat_RUN:	"Device is running",
	stat_RUNREADY:	"Device is switched on",
	stat_STANDBY:	"Device is in stand-by",
	stat_SYSTEMACTIVE:	"Device is switched on",
	stat_TPYBEGUN:	"Therapy has begun",
	stat_VOLBOL:	"Volume bolus running",
// - Voralarme
	preAlarm_Label:	"<strong>Pre-alarm(s):<\/strong>",
	preAlarm_ACCU:	"Battery near empty",
	preAlarm_DISPOSABLE:	"Syringe near empty",
	preAlarm_KOR:	"KVO active",
	preAlarm_NOPREALARM:	"<strong>No pre-alarm<\/strong>",
	preAlarm_TIME:	"Time near end",
	preAlarm_UNKNOWN:	"Unknown",
	preAlarm_VTBD:	"VTBI near end",
	preAlarm_DATALOCK: "Wrong code",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Communication Error!",
	preAlarm_PIGGYBACK: "Piggyback infused",
	preAlarm_TGC: "Blood glucose measure",	
// - Alarme
	Alarm_Label:	"<strong>Alarm(s):<\/strong>",
	Alarm_ACCU:	"Battery empty",
	Alarm_ACCU_EMPTY:	"Battery empty",
	Alarm_ACCUCOVER:	"Battery cover removed",
	Alarm_ACCUVOLTAGE:	"Battery voltage too low",
	Alarm_AIR:	"Air in line",
	Alarm_AIRBUBBLE:	"Air bubble",
	Alarm_AIRRATE:	"Air rate",
	Alarm_BAGEMPTY:	"Bag\/Bottle empty",
	Alarm_CALDATA:	"Calibrate device",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Check inlet",
	Alarm_DRIPDISCONNECT:	"Drop sensor disconnected",
	Alarm_FREEFLOW:	"Free Flow",
	Alarm_KPS:	"Plunger plate not prop. fixed",
	Alarm_KVOEND:	"KVO finished",
	Alarm_LESSDROPS:	"Too few drops",
	Alarm_MANYDROPS:	"Too many drops",
	Alarm_NOACCU:	"No battery inserted",
	Alarm_NOAIRTEST:	"Air sensor test failed",
	Alarm_NOALARM:	"<strong>No alarm<\/strong>",
	Alarm_NODROP:	"No drops",
	Alarm_PRESSURE:	"Pressure alarm",
	Alarm_SMBLOCK:	"Drive blocked",
	Alarm_STANDBY:	"Standby time expired",
	Alarm_SYRAXIAL:	"Syringe not correctly inserted",
	Alarm_SYRCLAW:	"Claw malfunction",
	Alarm_SYREND:	"Syringe empty",
	Alarm_SYRHOLD:	"Syringe holder",
	Alarm_TEMPERATURE:	"Temperature alarm",
	Alarm_TIMEEND:	"Time expired",
	Alarm_TPYANDPUMPDATA:	"Therapy data were reset",
	Alarm_TPYDATA:	"Data were reset",
	Alarm_UNKNOWN:	"Unknown",
	Alarm_VOLEND:	"VTBI infused",
	Alarm_DATA_LOCK:"Data Lock",
	Alarm_XHLIMIT:"PCA max dose limit reached",
	Alarm_TGCEND:"SGC end",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Reminder alarm",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Softlimit low is undergone",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Softlimit high is overgone",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Caution! No Softlimits are set"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.en = {
	m1:		"Status",
	m2:		"Service Information",
	m3:		"Configuration",
	m4:		"StatusView",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Quit application"
};

// Benutzername
userdata.usrname = msg.en.lbl_noLogin;
