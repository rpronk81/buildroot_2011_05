﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: cz																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:52																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.cz = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-cz",
	lbl_developmentVersion:	"v1.4.0-cz, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Váš prohlížeč by měl být zkonfigurován pro správný tisk barev pozadí a obrázků.\nV případě, že si před tiskem chcete ověřit nastavení, klikněte na [Zrušit].\nKliknutím na [OK] otevřete dialog pro tisk.\n\nPři použití Microsoft Internet Explorer se nastavení ověří následovně:\n\n  Hlavní menu 'Nástroje'\n    -> 'Možnosti sitě internet'\n      -> 'Upřesnění'\n        -> 'Tisk'\n          -> zaškrtněte nastavení 'Tisknout barvy pozadí a obrázky'.",
	ConfirmQuit:	"Skutečně chcete skrýt pomocníka?",
	ItemFiltered:	"Otevřená úroveň filtrovaného menu.",
	ItemLocked:	"Tato úroveň menu je blokována!",
	NoFilterOnLockedItem:	"Blokovaná úroveň menu nemůže být blokovaná!",
	OK:	"OK",
	yes:	"ano",
	no:	"ne",
	printPDF:	"Prosím, použijte funkci tisku\nvloženého programu Adobe® Reader.",

// Server & Data Feeder
	feedingData:	"[Probíhá zadávání dat]",
	ServerDataAge:	"SpaceOnline se od posledního obnovovacího\ncyklu nepodařilo načíst ani data přístroje ani data systému.\nProsím, zkontrolujte přístroj!",
	ServerDataSuspect:	"SpaceOnline se od posledního obnovovacího\ncyklu nepodařilo načíst buď data přístroje nebo data systému.",
	ServerNumb:	"Výstraha: WebServer SpaceOnline již delší dobu neposílá data. Prosím, zkontrolujte server!\n\nV případě, že požadujete restart uživatelského rozhraní, klikněte právě sem.",
	ServerSuspect:	"Stále se čeká na odezvu WebServeru SpaceOnline na předchozí požadavek obnovení…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Síťové spojení \/ SpaceOnline:",
	lbl_Help:	"Nápověda",
	lbl_Language:	"Jazyk",
	lbl_loginName:	"Přihlašovací jméno: ",
	lbl_noLogin:	"&lt;Nepřihlášeno do systému&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Zobrazit názvy léčiv",
	lbl_in:	"v",
	lbl_Notation:	"formátu.",
	adjLong:	"dlouhém",
	adjShort:	"krátkém",
// - Legende
	lbl_Legend:	"Legenda:",
	lbl_LegendPumpAlarm:	"Alarm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pumpa je vypnutá \/ zapnutá",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Předalarm \/ Alarm z prodlení",
	lbl_LegendPumpRunning:	"Pumpa běží",
	lbl_LegendPumpSelected:	"Pumpa je zvolena <br \/>(po kliknutí myší na symbol)",
	lbl_LegendPumpStandBy:	"Pumpa je v režimu Standby",
// - Fußzeile
	lbl_footerDisclaimer:	"Podmínky použití",
	lbl_footerImprint:	"Tisk",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Prosím, klikněte na $verb informační pod-panel",
	verbClose:	"zavřít",
	verbOpen:	"otevřít",
// - Strukturübersicht
	lbl_Alarm:	"Alarm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"žena",
	lbl_genderMale:	"muž",
	lbl_Off:	"VYP",
	lbl_On:	"ZAP",
	lbl_Prealarm:	"Předalarm!",
	lbl_Remalarm:	"Prodlení !",
	lbl_Selected:	"zvoleno",
	lbl_unknown:	"není k dispozici",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Vzduchový senzor je deaktivován",
	stat_ALARMACTUALQUIT:	"Zrušen aktuální alarm",
	stat_DATALOCK:	"DataLock je aktivní",
	stat_DOSIS:	"Výpočet rychlosti dávky",
	stat_KVOACTIVE:	"Režim KOR je aktivní",
	stat_MAINS:	"Ovládání hlavního přívodu",
	stat_MANBOL:	"Manuální bolus běží",
	stat_OFF:	"Přístroj je vypnut",
	stat_PREALARMACTUALQUIT:	"Zrušen aktuální předalarm",
	stat_RUN:	"Přístroj běží",
	stat_RUNREADY:	"Přístroj je zapnut",
	stat_STANDBY:	"Přístroj je v režimu Standby",
	stat_SYSTEMACTIVE:	"Přístroj je zapnut",
	stat_TPYBEGUN:	"Ošetření začalo",
	stat_VOLBOL:	"Objemový bolus běží",
// - Voralarme
	preAlarm_Label:	"<strong>Předalarm(y):<\/strong>",
	preAlarm_ACCU:	"Baterie je téměř vybitá",
	preAlarm_DISPOSABLE:	"Stříkačka je téměř prázdná",
	preAlarm_KOR:	"Režim KOR je aktivní",
	preAlarm_NOPREALARM:	"<strong>Žádný předalarm<\/strong>",
	preAlarm_TIME:	"Čas brzy vyprší",
	preAlarm_UNKNOWN:	"Neznámý",
	preAlarm_VTBD:	"Požadovaný objem téměř podán",
	preAlarm_DATALOCK: "Chybný kód !",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "! Chyba komunikace !",
	preAlarm_PIGGYBACK: "Podán Piggyback",
	preAlarm_TGC: "Změřit glykemii",
// - Alarme
	Alarm_Label:	"<strong>Alarm(y):<\/strong>",
	Alarm_ACCU:	"Baterie je vybitá",
	Alarm_ACCU_EMPTY:	"Baterie je vybitá",
	Alarm_ACCUCOVER:	"Odstraněn kryt baterie",
	Alarm_ACCUVOLTAGE:	"Příliš nízké napětí baterie",
	Alarm_AIR:	"Vzduch v setu",
	Alarm_AIRBUBBLE:	"Vzduchová bublina",
	Alarm_AIRRATE:	"Míra vzduchu",
	Alarm_BAGEMPTY:	"Prázdný vak (lahev)",
	Alarm_CALDATA:	"Zkalibrujte přístroj",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Zkontrolujte přívod",
	Alarm_DRIPDISCONNECT:	"Odpojen kapkový senzor",
	Alarm_FREEFLOW:	"Samovolný tok",
	Alarm_KPS:	"Destička pístu není pevně uchycena",
	Alarm_KVOEND:	"Režim KOR ukončen",
	Alarm_LESSDROPS:	"Příliš málo kapek",
	Alarm_MANYDROPS:	"Příliš mnoho kapek",
	Alarm_NOACCU:	"Není vložena baterie",
	Alarm_NOAIRTEST:	"Neúspěšný test vzduchového senzoru",
	Alarm_NOALARM:	"<strong>Žádný alarm<\/strong>",
	Alarm_NODROP:	"Žádné kapky",
	Alarm_PRESSURE:	"Alarm tlaku",
	Alarm_SMBLOCK:	"Pohon zablokován",
	Alarm_STANDBY:	"Čas režimu Standby vypršel",
	Alarm_SYRAXIAL:	"Stříkačka není správně vložena",
	Alarm_SYRCLAW:	"Závada čelistí",
	Alarm_SYREND:	"Stříkačka je prázdná",
	Alarm_SYRHOLD:	"Držák stříkačky",
	Alarm_TEMPERATURE:	"Alarm teploty",
	Alarm_TIMEEND:	"Čas vypršel",
	Alarm_TPYANDPUMPDATA:	"Data ošetření byla resetována",
	Alarm_TPYDATA:	"Data byla resetována",
	Alarm_UNKNOWN:	"Neznámý",
	Alarm_VOLEND:	"Podán požadovaný objem (VTBI)",
	Alarm_DATA_LOCK:"Data lock !",
	Alarm_XHLIMIT:"Dosaženo limitu PCA",
	Alarm_TGCEND:"Konec SGC",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Alarm z prodlení !",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Softlimit min. je podkročen.",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Softlimit max. je překročen",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Výstraha! Nejsou nastaveny softlimity!"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.cz = {
	m1:		"Stav",
	m2:		"Servisní informace",
	m3:		"Konfigurace",
	m4:		"Stav",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Ukončit aplikaci"
};

// Benutzername
userdata.usrname = msg.cz.lbl_noLogin;
