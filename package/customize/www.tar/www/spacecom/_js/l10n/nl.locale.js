﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: nl																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:53																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.nl = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-nl",
	lbl_developmentVersion:	"v1.4.0-nl, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Uw browser moet worden geconfigureerd zodat deze ook achtergrondkleuren en beelden kan afdrukken.\nAls u voor het afdrukken de instelling wilt controleren, klik dan op [Annuleren].\nAls u op [OK] klikt, verschijnt het printerdialoogvenster.\n\nIn Microsoft Internet Explorer kunt u deze instelling als volgt controleren:\n\n  Hoofdmenu `Extra´\n    -> `Internetopties´\n      -> Register `Geavanceerd´\n        -> Item weergeven `Bezig met afdrukken´\n          -> Plaats vinkje voor instelling `Achtergrondkleuren en beelden afdrukken´.",
	ConfirmQuit:	"Weet u zeker dat u SpaceOnline wilt afsluiten?",
	ItemFiltered:	"Gefilterd menuniveau geopend.",
	ItemLocked:	"Dit menuniveau is geblokkeerd!",
	NoFilterOnLockedItem:	"Een geblokkeerd menuniveau kan niet worden gefilterd!",
	OK:	"OK",
	yes:	"ja",
	no:	"nee",
	printPDF:	"Gebruik de afdrukfunctie\nvan de ingebedde Adobe® Reader.",

// Server & Data Feeder
	feedingData:	"[Gegevens worden aangevoerd]",
	ServerDataAge:	"SpaceOnline is er sinds de vorige ververscyclus niet in geslaagd\nom zowel de apparaatgegevens als de systeemgegevens aan te voeren.\nControleer het apparaat!",
	ServerDataSuspect:	"SpaceOnline is er sinds de vorige ververscyclus niet in geslaagd\nom ofwel de apparaatgegevens of de systeemgegevens aan te voeren.",
	ServerNumb:	"Let op: SpaceOnline WebServer lijkt geen gegevens meer te zenden. Controleer de server!\n\nAls u de gebruikersinterface daarna opnieuw wilt starten, klik dan hier.",
	ServerSuspect:	"Wacht nog steeds op SpaceOnline WebServer om te reageren op vorig verzoek tot verversen…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Netwerkverbinding \/ SpaceOnline:",
	lbl_Help:	"Help",
	lbl_Language:	"Taal",
	lbl_loginName:	"Inlognaam: ",
	lbl_noLogin:	"&lt;Geen inlog&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Laat geneesmiddelen namen zien",
	lbl_in:	"in",
	lbl_Notation:	"notitie.",
	adjLong:	"lang",
	adjShort:	"kort",
// - Legende
	lbl_Legend:	"Legenda:",
	lbl_LegendPumpAlarm:	"Alarm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pomp staat uit \/ aan",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Voor- \/ Herinneringsalarm",
	lbl_LegendPumpRunning:	"Pomp loopt",
	lbl_LegendPumpSelected:	"Pomp is gekozen <br \/>(na muisklik op symbool)",
	lbl_LegendPumpStandBy:	"Pomp staat standby",
// - Fußzeile
	lbl_footerDisclaimer:	"Gebruiksvoorwaarden",
	lbl_footerImprint:	"Impressum",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Klik svp op $verb informatie sub-panel",
	verbClose:	"dicht",
	verbOpen:	"open",
// - Strukturübersicht
	lbl_Alarm:	"Alarm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"vrouwelijk",
	lbl_genderMale:	"mannelijk",
	lbl_Off:	"Uit",
	lbl_On:	"Aan",
	lbl_Prealarm:	"Vooralarm!",
	lbl_Remalarm:	"Herinnering",
	lbl_Selected:	"gekozen",
	lbl_unknown:	"n.v.t.",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Luchtsensor is uitgeschakeld",
	stat_ALARMACTUALQUIT:	"Feitelijk alarm wordt uitgeschakeld",
	stat_DATALOCK:	"DataLock is actief",
	stat_DOSIS:	"Dosiscalculatie",
	stat_KVOACTIVE:	"KVO actief",
	stat_MAINS:	"Werking op netstroom",
	stat_MANBOL:	"Handmatige bolus actief",
	stat_OFF:	"Apparaat staat uit",
	stat_PREALARMACTUALQUIT:	"Feitelijk vooralarm wordt uitgeschakeld",
	stat_RUN:	"Apparaat loopt",
	stat_RUNREADY:	"Apparaat staat aan",
	stat_STANDBY:	"Apparaat staat standby",
	stat_SYSTEMACTIVE:	"Apparaat staat aan",
	stat_TPYBEGUN:	"Therapie is begonnen",
	stat_VOLBOL:	"Volumebolus loopt",
// - Voralarme
	preAlarm_Label:	"<strong>Vooralarm(en):<\/strong>",
	preAlarm_ACCU:	"Accu bijna leeg",
	preAlarm_DISPOSABLE:	"Spuit bijna leeg",
	preAlarm_KOR:	"KVO actief",
	preAlarm_NOPREALARM:	"<strong>Geen vooralarm<\/strong>",
	preAlarm_TIME:	"Tijd bijna afgelopen",
	preAlarm_UNKNOWN:	"Onbekend",
	preAlarm_VTBD:	"VTBI bijna afgelopen",
	preAlarm_DATALOCK: "Foutieve code",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Communicatiefout!",
	preAlarm_PIGGYBACK: "Piggyb 2 toegediend",
	preAlarm_TGC: "Bloedsuiker meting",
// - Alarme
	Alarm_Label:	"<strong>Alarm(en):<\/strong>",
	Alarm_ACCU:	"Accu leeg",
	Alarm_ACCU_EMPTY:	"Accu leeg",
	Alarm_ACCUCOVER:	"Afedekplaatjs accu verwijderd",
	Alarm_ACCUVOLTAGE:	"Accuspanning te laag",
	Alarm_AIR:	"Lucht in systeem",
	Alarm_AIRBUBBLE:	"Luchtbel",
	Alarm_AIRRATE:	"Luchtsnelheid",
	Alarm_BAGEMPTY:	"Zak\/Fles leeg",
	Alarm_CALDATA:	"Kalibreer apparaat",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Controleer inlaat",
	Alarm_DRIPDISCONNECT:	"Druppelsensor losgekoppeld",
	Alarm_FREEFLOW:	"Free Flow",
	Alarm_KPS:	"Zuigerplaat niet goed vastgemaakt",
	Alarm_KVOEND:	"KVO afgelopen",
	Alarm_LESSDROPS:	"Te weinig druppels",
	Alarm_MANYDROPS:	"Te veel druppels",
	Alarm_NOACCU:	"Geen accu geplaatst",
	Alarm_NOAIRTEST:	"Luchtsensortest mislukt",
	Alarm_NOALARM:	"<strong>Geen alarm<\/strong>",
	Alarm_NODROP:	"Geen druppels",
	Alarm_PRESSURE:	"Drukalarm",
	Alarm_SMBLOCK:	"Aandrijving geblokkeerd",
	Alarm_STANDBY:	"Standby-tijd verstreken",
	Alarm_SYRAXIAL:	"Spuit niet goed ingebracht",
	Alarm_SYRCLAW:	"Fout in bekjes",
	Alarm_SYREND:	"Spuit leeg",
	Alarm_SYRHOLD:	"Spuithouder",
	Alarm_TEMPERATURE:	"Temperatuuralarm",
	Alarm_TIMEEND:	"Tijd verstreken",
	Alarm_TPYANDPUMPDATA:	"Therapiegegevens zijn gereset",
	Alarm_TPYDATA:	"Gegevens zijn gereset",
	Alarm_UNKNOWN:	"Onbekend",
	Alarm_VOLEND:	"VTBI geïnfuseerd",
	Alarm_DATA_LOCK:"Data lock",
	Alarm_XHLIMIT:"PCA limiet is bereikt",
	Alarm_TGCEND:"SGC beëindigd",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Herinnerings alarm",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Soft limit is onderschreden",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Soft limit is overschreden",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Let op! Er zijn geen softlimits ingesteld"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.nl = {
	m1:		"Status",
	m2:		"Service Information",
	m3:		"Configuratie",
	m4:		"Status",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Toepassing afsluiten"
};

// Benutzername
userdata.usrname = msg.nl.lbl_noLogin;
