﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: it																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:53																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.it = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-it",
	lbl_developmentVersion:	"v1.4.0-it, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Il browser deve essere configurato per stampare sia i colori di sfondo sia le immagini.\nPer verificare le impostazioni prima di procedere con la stampa, cliccare su [Cancella].\nCliccando su [OK] si apre la sezione di stampa.\n\nPer Microsoft Internet Explorer devono essere verificate le seguenti impostazioni:\n\n  Menu Principale 'Pannello di controllo'\n    -> Selezionare 'Opzioni Internet'\n      -> Selezionare la cartella 'Avanzate'\n        -> Considera la voce 'Stampa'\n          -> Selezionare la casella associata a 'Stampa colori e immagini di sfondo'.",
	ConfirmQuit:	"Terminare SpaceOnline?",
	ItemFiltered:	"Aperto livello del menu filtrato .",
	ItemLocked:	"Questo livello del menu è bloccato !",
	NoFilterOnLockedItem:	"Un livello del menu bloccato non può essere filtrato!",
	OK:	"OK",
	yes:	"Si",
	no:	"No",
	printPDF:	"Utilizzare la funzione di stampa\nintegrata in Adobe&reg; Readerr",

// Server & Data Feeder
	feedingData:	"[Caricamento dati in corso]",
	ServerDataAge:	"SpaceOnline non ha caricato né i dati della pompa,\nné i dati del sistema rispetto al precedente ciclo di aggiornamento.\nVerificare il server!",
	ServerDataSuspect:	"SpaceOnLine non ha caricato o i dati della pompa,\no i dati del sistema rispetto al precedente ciclo di aggiornamento.",
	ServerNumb:	"Attenzione: è possibile che SpaceOnline WebServer non stia più trasmettendo dati. Verificare il server!\n\nNel caso in cui si desideri riattivare in seguito l'interfaccia utente, cliccare qui a destra.",
	ServerSuspect:	"In attesa che SpaceOnLine WebServer risponda alla precedente richiesta di refresh…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Connesione alla rete \/ SpaceOnline:",
	lbl_Help:	"Aiuto",
	lbl_Language:	"Lingua",
	lbl_loginName:	"Login: ",
	lbl_noLogin:	"&lt;Nessun Login&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Mostra il nome",
	lbl_in:	'',
	lbl_Notation:	"del farmaco.",
	adjLong:	"per esteso",
	adjShort:	"breve",
// - Legende
	lbl_Legend:	"Legenda:",
	lbl_LegendPumpAlarm:	"Allarme",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pompa spenta \/ accesa",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Pre- \/ Allarme di richiamo",
	lbl_LegendPumpRunning:	"Pompa in infusione",
	lbl_LegendPumpSelected:	"Pompa selezionata (dopo la selezione con un click del mouse)",
	lbl_LegendPumpStandBy:	"Pompa in pausa",
// - Fußzeile
	lbl_footerDisclaimer:	"Condizioni di utilizzo",
	lbl_footerImprint:	"Stampa",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Cliccare per $verb il pannello delle sottoinformazioni",
	verbClose:	"chiudere",
	verbOpen:	"aprire",
// - Strukturübersicht
	lbl_Alarm:	"Allarme!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"Donna",
	lbl_genderMale:	"Uomo",
	lbl_Off:	"Spenta",
	lbl_On:	"Accesa",
	lbl_Prealarm:	"Pre-Allarme!",
	lbl_Remalarm:	"Richiamo",
	lbl_Selected:	"Selezionata",
	lbl_unknown:	"Non disponibile",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Sensore aria disattivato",
	stat_ALARMACTUALQUIT:	"Allarme sospeso",
	stat_DATALOCK:	"Blocco dati attivato",
	stat_DOSIS:	"Calcolo della dose",
	stat_KVOACTIVE:	"KVO attivo",
	stat_MAINS:	"Funzionamento a rete",
	stat_MANBOL:	"Bolo manuale in corso",
	stat_OFF:	"Pompa spenta",
	stat_PREALARMACTUALQUIT:	"Pre-allarme sospeso",
	stat_RUN:	"Pompa in infusione",
	stat_RUNREADY:	"Pompa accesa",
	stat_STANDBY:	"Pompa in pausa",
	stat_SYSTEMACTIVE:	"Pompa accesa",
	stat_TPYBEGUN:	"La terapia è iniziata",
	stat_VOLBOL:	"Bolo in volume in corso",
// - Voralarme
	preAlarm_Label:	"<strong>Pre-allarme(i):<\/strong>",
	preAlarm_ACCU:	"Batteria quasi scarica",
	preAlarm_DISPOSABLE:	"Siringa quasi vuota",
	preAlarm_KOR:	"KVO attivo",
	preAlarm_NOPREALARM:	"<strong>Nessun pre-allarme<\/strong>",
	preAlarm_TIME:	"Durata quasi al termine",
	preAlarm_UNKNOWN:	"Sconosciuto",
	preAlarm_VTBD:	"VTBI quasi al termine",
	preAlarm_DATALOCK: "Codice Errato",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Errore Comunicazione!",
	preAlarm_PIGGYBACK: "Piggyback 2 infuso",
	preAlarm_TGC: "Misurazione Glucosio",
// - Alarme
	Alarm_Label:	"<strong>Allarme(i):<\/strong>",
	Alarm_ACCU:	"Batteria scarica",
	Alarm_ACCU_EMPTY:	"Batteria scarica",
	Alarm_ACCUCOVER:	"Rimosso il coperchio del vano batteria",
	Alarm_ACCUVOLTAGE:	"Voltaggio batteria troppo basso",
	Alarm_AIR:	"Aria nella linea",
	Alarm_AIRBUBBLE:	"Bolla d'aria",
	Alarm_AIRRATE:	"Volume aria",
	Alarm_BAGEMPTY:	"Contenitore vuoto",
	Alarm_CALDATA:	"Calibrare la pompa",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Verificare il gocciolatore",
	Alarm_DRIPDISCONNECT:	"Sensore gocce scollegato",
	Alarm_FREEFLOW:	"Flusso Libero",
	Alarm_KPS:	"Piatto di spinta siringa non fissato correttamente",
	Alarm_KVOEND:	"KVO terminato",
	Alarm_LESSDROPS:	"Scarso gocciolamento",
	Alarm_MANYDROPS:	"Eccessivo gocciolamento",
	Alarm_NOACCU:	"Nessuna betteria inserita",
	Alarm_NOAIRTEST:	"Test sensore aria fallito",
	Alarm_NOALARM:	"<strong>Nessun allarme<\/strong>",
	Alarm_NODROP:	"Assenza di gocciolamento",
	Alarm_PRESSURE:	"Allarme di pressione",
	Alarm_SMBLOCK:	"Braccio di spinta bloccato",
	Alarm_STANDBY:	"Pausa terminata",
	Alarm_SYRAXIAL:	"Siringa non correttamente inserita",
	Alarm_SYRCLAW:	"Aggancio piatto siringa guasto",
	Alarm_SYREND:	"Siringa vuota",
	Alarm_SYRHOLD:	"Gancio siringa",
	Alarm_TEMPERATURE:	"Allarme di temperatura",
	Alarm_TIMEEND:	"Durata terminata",
	Alarm_TPYANDPUMPDATA:	"I dati della terapia sono stati azzerati",
	Alarm_TPYDATA:	"I dati sono stati azzerati",
	Alarm_UNKNOWN:	"Sconosciuto",
	Alarm_VOLEND:	"VTBI infuso",
	Alarm_DATA_LOCK:"Blocco Dati",
	Alarm_XHLIMIT:"Limite PCA raggiunto",
	Alarm_TGCEND:"Modalità SGC terminata",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Allarme di richiamo",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Il Softlimit inferiore è stato superato",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Il Softlimit superiore è stato superato",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Attenzione! Nessun Softlimit impostato"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.it = {
	m1:		"Stato",
	m2:		"Informazioni di servizio",
	m3:		"Configurazione",
	m4:		"Stato",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Chiudi"
};

// Benutzername
userdata.usrname = msg.it.lbl_noLogin;
