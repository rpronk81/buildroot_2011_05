﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: sk																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:52																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.sk = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-sk",
	lbl_developmentVersion:	"v1.4.0-sk, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Váš prehliadač by mal byť nakonfigurovaný pre tlač farieb pozadia a obrázkov.\nV prípade, že si pred tlačou chcete overiť nastavenie, kliknite na [Zrušiť].\nKliknutie na [OK] otvorí dialóg pre tlač.\n\nPri použití Microsoft Internet Explorera sa nastavenie overí nasledovne:\n\n  Hlavné menu 'Nástroje'\n    -> 'Možnosti siete internet'\n      -> 'Spresnenie'\n        -> 'Tlač'\n          -> Zaškrtnite nastavenie 'Tlačiť farby a obrázky pozadia'",
	ConfirmQuit:	"Chcete skutočne ukončiť SpaceOnline?",
	ItemFiltered:	"Otvorená úroveň filtrovaného menu.",
	ItemLocked:	"Táto úroveň menu je blokovaná!",
	NoFilterOnLockedItem:	"Blokovaná úroveň menu nemôže byť filtrovaná!",
	OK:	"OK",
	yes:	"áno",
	no:	"nie",
	printPDF:	"Použite funkciu pre tlač\nvloženého programu Adobe® Reader.",

// Server & Data Feeder
	feedingData:	"[Prebieha vkladanie údajov]",
	ServerDataAge:	"SpaceOnline sa nepodarilo od obnovenia\nposledného cyklu vložiť údaje prístroja ani údaje systému.\nSkontrolujte prístroj!",
	ServerDataSuspect:	"SpaceOnline sa nepodarilo od obnovenia\nposledného cyklu vložiť  buď údaje prístroja alebo údaje systému.",
	ServerNumb:	"Upozornenie: SpaceOnline WebServer pravdepodobne neposiela ďalšie údaje. Skontrolujte server!\n\nV prípade, že chcete použiť rozhranie, ktoré vyžaduje reštartovanie, kliknite práve sem.",
	ServerSuspect:	"Stále sa čaká na odozvu SpaceOnline WebServer na predošlú požiadavku obnovenia…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Sieťové spojenie \/ SpaceOnline:",
	lbl_Help:	"Nápoveda",
	lbl_Language:	"Jazyk",
	lbl_loginName:	"Prihlasovacie meno: ",
	lbl_noLogin:	"&lt;Neprihlásené do systému&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Zobraz názvy liekov",
	lbl_in:	"v",
	lbl_Notation:	"zápise.",
	adjLong:	"dlhom",
	adjShort:	"krátkom",
// - Legende
	lbl_Legend:	"Legenda:",
	lbl_LegendPumpAlarm:	"Alarm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pumpa je vypnutá \/ zapnutá",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Pred- \/ Pripomínací alarm",
	lbl_LegendPumpRunning:	"Pumpa je v činnosti",
	lbl_LegendPumpSelected:	"Pumpa je zvolená <br \/>(po kliknutí myšou na symbol)",
	lbl_LegendPumpStandBy:	"Pumpa je v pohotovosnom stave",
// - Fußzeile
	lbl_footerDisclaimer:	"Podmienky použitia",
	lbl_footerImprint:	"Tlač",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Prosím, kliknite na $verb informačný sub-panel",
	verbClose:	"zavrieť",
	verbOpen:	"otvoriť",
// - Strukturübersicht
	lbl_Alarm:	"Alarm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"žena",
	lbl_genderMale:	"muž",
	lbl_Off:	"VYP",
	lbl_On:	"ZAP",
	lbl_Prealarm:	"Predalarm!",
	lbl_Remalarm:	"Pripomínací",
	lbl_Selected:	"zvolené",
	lbl_unknown:	"neznámy",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Vzduchový senzor je vypnutý",
	stat_ALARMACTUALQUIT:	"Aktuálny alarm je zrušený",
	stat_DATALOCK:	"DataLock je aktívny",
	stat_DOSIS:	"Výpočet rýchlosti dávky",
	stat_KVOACTIVE:	"Režim KOR je aktivny",
	stat_MAINS:	"Činnosť hlavného prívodu",
	stat_MANBOL:	"Manuálny bolus prebieha",
	stat_OFF:	"Prístroj je vypnutý",
	stat_PREALARMACTUALQUIT:	"Zrušený aktuálny predalarm",
	stat_RUN:	"Prístroj je v prevádzke",
	stat_RUNREADY:	"Prístroj je zapnutý",
	stat_STANDBY:	"Prístroj je v pohotovosnom stave",
	stat_SYSTEMACTIVE:	"Prístroj je zapnutý",
	stat_TPYBEGUN:	"Terapia začala",
	stat_VOLBOL:	"Objemový bolus prebieha",
// - Voralarme
	preAlarm_Label:	"<strong>Predalarm(y):<\/strong>",
	preAlarm_ACCU:	"Batéria je takmer vybitá",
	preAlarm_DISPOSABLE:	"Striekačka je takmer prázdna",
	preAlarm_KOR:	"Režim KOR je aktívny",
	preAlarm_NOPREALARM:	"<strong>Žiadny predalarm<\/strong>",
	preAlarm_TIME:	"Čas tesne pred vypršaním",
	preAlarm_UNKNOWN:	"Neznámy",
	preAlarm_VTBD:	"Požadovaný objem takmer podaný",
	preAlarm_DATALOCK: "Napačna koda",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Napaka v komunikaciji!",
	preAlarm_PIGGYBACK: "Sek. inf. iztekla",
	preAlarm_TGC: "Meritev glukoze v krvi",
// - Alarme
	Alarm_Label:	"<strong>Alarm(y):<\/strong>",
	Alarm_ACCU:	"Batéria je vybitá",
	Alarm_ACCU_EMPTY:	"Batéria je vybitá",
	Alarm_ACCUCOVER:	"Odstránený kryt batérie",
	Alarm_ACCUVOLTAGE:	"Veľmi nízke napätie batérie",
	Alarm_AIR:	"Vzduch v hadičke",
	Alarm_AIRBUBBLE:	"Vzduchová bublina",
	Alarm_AIRRATE:	"Miera vzduchu",
	Alarm_BAGEMPTY:	"Prázdny vak (fľaša)",
	Alarm_CALDATA:	"Nakalibrujte prístroj",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Skontrolujte prívod",
	Alarm_DRIPDISCONNECT:	"Kvapkový senzor odpojený",
	Alarm_FREEFLOW:	"Samovoľný tok",
	Alarm_KPS:	"Doštička piestu nesprávne uchytená",
	Alarm_KVOEND:	"Režim KOR ukončený",
	Alarm_LESSDROPS:	"Príliš málo kvapiek",
	Alarm_MANYDROPS:	"Príliš veľa kvapiek",
	Alarm_NOACCU:	"Nie je vložená batéria",
	Alarm_NOAIRTEST:	"Neúspešný test vzduchového senzora",
	Alarm_NOALARM:	"<strong>Žiadny alarm<\/strong>",
	Alarm_NODROP:	"Žiadne kvapky",
	Alarm_PRESSURE:	"Tlakový alarm",
	Alarm_SMBLOCK:	"Zablokovaný pohon",
	Alarm_STANDBY:	"Čas pohotovostného režimu vypršal",
	Alarm_SYRAXIAL:	"Nesprávne vložená striekačka",
	Alarm_SYRCLAW:	"Zlyhanie čelustí",
	Alarm_SYREND:	"Striekačka je prázdna",
	Alarm_SYRHOLD:	"Držiak striekačky",
	Alarm_TEMPERATURE:	"Alarm teploty",
	Alarm_TIMEEND:	"Čas vypršal",
	Alarm_TPYANDPUMPDATA:	"Údaje o terapii boli resetované",
	Alarm_TPYDATA:	"Údaje boli resetované",
	Alarm_UNKNOWN:	"Neznámy",
	Alarm_VOLEND:	"Požadovaný objem podaný (VTBI)",
	Alarm_DATA_LOCK:"Zaklepanje podatkov",
	Alarm_XHLIMIT:"PCA limit dosežen",
	Alarm_TGCEND:"SGC končan",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Pripomínací alarm",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Spodný Softlimit je prekročený",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Horný Softlimit je prekročený",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Varovanie! Nie sú zadané hodnoty Softlimitov"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.sk = {
	m1:		"Stav",
	m2:		"Servisné informácie",
	m3:		"Konfigurácia",
	m4:		"Stav",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Ukončiť aplikáciu"
};

// Benutzername
userdata.usrname = msg.sk.lbl_noLogin;
