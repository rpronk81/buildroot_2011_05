﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: no																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:53																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.no = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-no",
	lbl_developmentVersion:	"v1.4.0-no, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"Din nettleser må konfigureres til å skrive ut bakgrunnsfarger og bilder.\nKlikk [Avbryt] hvis du vil kontrollere innstillinger før utskriften.\nKlikk [OK] for å åpne utskriftsmenyen.\n\nKontroller at innstillinger for Microsoft Internet Explorer er slik:\n\n  Hovedmenyen `Kontrollpanel´\n    -> `Alternativer for Internett´\n      -> Velg `Avansert´\n        -> Rull ned til `Utskrift´\n          -> Kryss av for `Skriv ut bakgrunnsfarger og bilder´",
	ConfirmQuit:	"Vil du virkelig lukke Hjelp for SpaceOnline?",
	ItemFiltered:	"Filtrert menynivå åpent.",
	ItemLocked:	"Dette menynivået er blokkert!",
	NoFilterOnLockedItem:	"Et blokkert menynivå kan ikke filtreres!",
	OK:	"OK",
	yes:	"ja",
	no:	"nei",
	printPDF:	"Bruk utskriftsfunksjonen i medfølgende Adobe Reader",

// Server & Data Feeder
	feedingData:	"[Datalasting pågår]",
	ServerDataAge:	"SpaceOnline har mislyktes i å laste inn data\nfra pumpen og system etter forrige oppdatering.\nKontroller utstyret!",
	ServerDataSuspect:	"SpaceOnline har mislyktes i å laste inn data\nfra pumpen eller system etter forrige oppdatering.",
	ServerNumb:	"OBS! Data fra SpaceOnline WebServer mangler. Kontroller servereren!\n\nKlikk her hvis du vil starte programmet på nytt.",
	ServerSuspect:	"Venter på at SpaceOnline WebServer skal svare på siste forespørsel…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Nettverkstilkobling \/ SpaceOnline:",
	lbl_Help:	"Hjelp",
	lbl_Language:	"Språk",
	lbl_loginName:	"Påloggingsnavn: ",
	lbl_noLogin:	"&lt;Ikke pålogget&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Vis medikamentnavn",
	lbl_in:	"som",
	lbl_Notation:	"kommentar.",
	adjLong:	"lang",
	adjShort:	"kort",
// - Legende
	lbl_Legend:	"Bildetekst:",
	lbl_LegendPumpAlarm:	"Alarm",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Pumpen er slått av \/ på",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Forhånds- / Påminnelsesalm.",
	lbl_LegendPumpRunning:	"Pumpen er i drift",
	lbl_LegendPumpSelected:	"Valgt pumpe (etter et klikk på symbolet)",
	lbl_LegendPumpStandBy:	"Pumpe i standby",
// - Fußzeile
	lbl_footerDisclaimer:	"Vilkår for bruk",
	lbl_footerImprint:	"Produsent",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Klikk for å $verb informasjonsvinduet",
	verbClose:	"lukke",
	verbOpen:	"åpne",
// - Strukturübersicht
	lbl_Alarm:	"Alarm!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"kvinne",
	lbl_genderMale:	"mann",
	lbl_Off:	"Av",
	lbl_On:	"På",
	lbl_Prealarm:	"Forhåndsalarm!",
	lbl_Remalarm:	"Påminnelse!",
	lbl_Selected:	"valgt",
	lbl_unknown:	"n\/a",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Luftsensor er deaktivert",
	stat_ALARMACTUALQUIT:	"Aktuell alarm er slått av",
	stat_DATALOCK:	"Datalås er aktiv",
	stat_DOSIS:	"Doseringskalkulasjon",
	stat_KVOACTIVE:	"KVO aktiv",
	stat_MAINS:	"Strømtilkobling",
	stat_MANBOL:	"Manuell bolus pågår",
	stat_OFF:	"Pumpen er slått av",
	stat_PREALARMACTUALQUIT:	"Aktuell forhåndsalarm er slått av",
	stat_RUN:	"Pumpen er i drift",
	stat_RUNREADY:	"Pumpen er slått på",
	stat_STANDBY:	"Pumpen er i standby",
	stat_SYSTEMACTIVE:	"Pumpen er slått på",
	stat_TPYBEGUN:	"Behandling har startet",
	stat_VOLBOL:	"Bolus med forhåndsvalgt volum pågår",
// - Voralarme
	preAlarm_Label:	"<strong>Forhåndsalarm(er):<\/strong>",
	preAlarm_ACCU:	"Batteri nesten tomt",
	preAlarm_DISPOSABLE:	"Sprøyte nesten tom",
	preAlarm_KOR:	"KVO aktiv",
	preAlarm_NOPREALARM:	"<strong>Ingen forhåndsalarm<\/strong>",
	preAlarm_TIME:	"Tid nær ute",
	preAlarm_UNKNOWN:	"Ukjent",
	preAlarm_VTBD:	"Totalvolum nær slutt",
	preAlarm_DATALOCK: "Feil kode",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Kommunikasjonsfeil!",
	preAlarm_PIGGYBACK: "Piggyback 2 infundert",
	preAlarm_TGC: "Blodsukkermåling",
// - Alarme
	Alarm_Label:	"<strong>Alarm(er):<\/strong>",
	Alarm_ACCU:	"Batteriet er tomt",
	Alarm_ACCU_EMPTY:	"Batteriet er tomt",
	Alarm_ACCUCOVER:	"Batterideksel fjernet",
	Alarm_ACCUVOLTAGE:	"Batterispenning for lav",
	Alarm_AIR:	"Luft i slangen",
	Alarm_AIRBUBBLE:	"Luftboble",
	Alarm_AIRRATE:	"Akkumulert luftalarm",
	Alarm_BAGEMPTY:	"Pose\/flaske tom",
	Alarm_CALDATA:	"Kalibrer apparatet",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Kontroller strømtilkobling",
	Alarm_DRIPDISCONNECT:	"Dråpesensor frakoblet",
	Alarm_FREEFLOW:	"Fri flow",
	Alarm_KPS:	"Stempelplaten er ikke riktig festet",
	Alarm_KVOEND:	"KVO over",
	Alarm_LESSDROPS:	"For få dråper",
	Alarm_MANYDROPS:	"For mange dråper",
	Alarm_NOACCU:	"Batteri ikke innsatt",
	Alarm_NOAIRTEST:	"Test av luftsensor mislyktes",
	Alarm_NOALARM:	"<strong>Ingen alarm<\/strong>",
	Alarm_NODROP:	"Ingen dråper",
	Alarm_PRESSURE:	"Trykkalarm",
	Alarm_SMBLOCK:	"Driver blokkert",
	Alarm_STANDBY:	"Standby-tid utgått",
	Alarm_SYRAXIAL:	"Sprøyte ikke satt riktig inn",
	Alarm_SYRCLAW:	"Teknisk feil i sprøyteholderen",
	Alarm_SYREND:	"Tom sprøyte",
	Alarm_SYRHOLD:	"Sprøyteholder",
	Alarm_TEMPERATURE:	"Temperaturalarm",
	Alarm_TIMEEND:	"Tiden ute",
	Alarm_TPYANDPUMPDATA:	"Siste behandling nullstilt",
	Alarm_TPYDATA:	"Data nullstilt",
	Alarm_UNKNOWN:	"Ukjent",
	Alarm_VOLEND:	"Totalvolum infundert",
	Alarm_DATA_LOCK:"Datalås",
	Alarm_XHLIMIT:"PCA-grense nådd",
	Alarm_TGCEND:"SGC avsluttet",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Påminnelsesalarm",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Nedre softlimit er overskredet",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Øvre softlimit er overskredet",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"OBS! Softlimits er ikke innstilt"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.no = {
	m1:		"Status",
	m2:		"Service",
	m3:		"Konfigurasjon",
	m4:		"Status",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Avslutt"
};

// Benutzername
userdata.usrname = msg.no.lbl_noLogin;
