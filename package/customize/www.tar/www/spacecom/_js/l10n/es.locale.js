﻿/**********************************************************************
 * Javascript/CSS/XHTML-Objektmodell 'Vertikalmenü'										*
 * locale-Daten: es																										*
 * Copyright (c) 2003,2006 des Menü-Layouts by B. Braun Melsungen AG	*
 * Copyright (c) 2006 des Objektmodells by B2A Corporate Marketing		*
 * All rights reserved																								*
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Development 2005-03..07,2006-08																		*
 * by B2A Corporate Marketing,Kassel; mailto:dev-AT-b2a-DOT-de				*
 * *** Jede Verwendung nur mit ausdrücklicher Genehmigung! ***				*
 * Version: 1.3.0																											*
 * Autor: B2A/koe																											*
 * Letzte Bearbeitung: 2008-01-09 10:51																*
 * durch: Koe																													*
 **********************************************************************/

// Standardmeldung in Statuszeile
window.defaultStatus = "SpaceOnline – B. Braun Melsungen AG";

msg.es = {
// Versionsbezeichnungen
	lbl_officialVersion: "v1.4.0-es",
	lbl_developmentVersion:	"v1.4.0-es, Rel. 3",

// Meldungen und sonstige
// sprachspezifische Texte
	CheckForPrintSetting:	"El servidor debe configurase el fondo de colores y imágenes.\nEn caso de querer priorizar los ajustes de impresió, por favor pulsar en [cancelar].\nPulsar en [OK] para abrir el cuadro de dialogo de impresión.\n\nRespecto al ajuste de Microsoft Internet Explorer debe ser verificado como sigue:\n\n  Menú principal `Herramientas´\n    -> `Opciones internet´\n      -> Rogistro `Avanzado´\n        ->  Listar item `Imprimir´\n          -> Poner una marca de revisión en el ajuste `Imprimir fondo colores e imágenes´.",
	ConfirmQuit:	"Desea salir de SpaceOnline?",
	ItemFiltered:	"Nivel de menú flitrado abierto!",
	ItemLocked:	"Este nivel de emnú está bloqueado!",
	NoFilterOnLockedItem:	"Un nivel de menú bloqueado no puede ser filtrado!",
	OK:	"OK",
	yes:	"si",
	no:	"no",
	printPDF:	"Utilizar la opción\nimprimir de Adobe® Reader.",

// Server & Data Feeder
	feedingData:	"[Introducción de datos en proceso]",
	ServerDataAge:	"Fallo al introducir los datos del equipo\ny del sistema en SpaceOnline desde el reinicio previo.\nPor favor revise el equipo!",
	ServerDataSuspect:	"Fallo al introducir los datos del equipo\no en el sistema en SpaceOnline desde el reinicio previo.",
	ServerNumb:	"Atención: El servidor Web de SpaceOnline no envia datos. Por favor revise el servidor!\n\nEn caso que quiera reiniciar el interface de usuario, pulsar aquí.\n\nEsperando respuesta de la petición previa de reinicio del servidor web SpaceOnline…",
	ServerSuspect:	"Esperando respuesta de SpaceOnline a la petición de reinicio…",

// Informations-Label für TopFrame:
	lbl_ConnectAndDataAge:	"Conexión de red \/ SpaceOnline:",
	lbl_Help:	"Ayuda",
	lbl_Language:	"Idioma",
	lbl_loginName:	"Nombre de usuario: ",
	lbl_noLogin:	"&lt;Sin usuario&gt;",

// Informations-Label für MenuFrame:
// - Umschaltung Medikamentname
	lbl_Drugname:	"Mostrar nombre fármaco",
	lbl_in:	"en",
	lbl_Notation:	"anotacion.",
	adjLong:	"largo",
	adjShort:	"corto",
// - Legende
	lbl_Legend:	"Leyenda:",
	lbl_LegendPumpAlarm:	"Alarma",
	lbl_LegendPumpInfusomat:	"Infusomat&reg; Space",
	lbl_LegendPumpOnOff:	"Bomba conectada off \/ on",
	lbl_LegendPumpPerfusor:	"Perfusor&reg; Space",
	lbl_LegendPumpPrealarm:	"Pre-alarma",
	lbl_LegendPumpRunning:	"Bomba en funcionamiento",
	lbl_LegendPumpSelected:	"Bomba seleccionada (después selccionar con el mouse)",
	lbl_LegendPumpStandBy:	"Bomba en stand-by",
// - Fußzeile
	lbl_footerDisclaimer:	"Terminos de uso",
	lbl_footerImprint:	"Imprimir",

// Informations-Label für ContentFrame:
// - Informations-Subpanels
	subPanel:	"Por favor pulsar en $verb sub-menu de información!",
	verbClose:	"cerrar",
	verbOpen:	"abrir",
// - Strukturübersicht
	lbl_Alarm:	"Alarma!",
	lbl_defaultProfType:	"Standard",
	lbl_genderFemale:	"Mujer",
	lbl_genderMale:	"Hombre",
	lbl_Off:	"Off",
	lbl_On:	"On",
	lbl_Prealarm:	"Pre-alarma!",
	lbl_Remalarm:	"Reminder",
	lbl_Selected:	"seleccionado",
	lbl_unknown:	"n\/a",
	lbl_battStatus:	new Array(
		'&minus;',
		'&lt; 10%',
		'&gt; 10%',
		'&gt; 50%',
		'&gt; 88%',
		null,
		'0%' ),
// - Statusinformation
	stat_AIRSENSOROFF:	"Sensor de aire desactivado",
	stat_ALARMACTUALQUIT:	"Alarma actual anulada",
	stat_DATALOCK:	"DataLock activo",
	stat_DOSIS:	"Cálculo de dosis",
	stat_KVOACTIVE:	"KVO activo",
	stat_MAINS:	"Operación principal",
	stat_MANBOL:	"Entragando bolo manual",
	stat_OFF:	"Equipo desconectado",
	stat_PREALARMACTUALQUIT:	"Pre-alarma actual anulada",
	stat_RUN:	"Equipo en funcionamiento",
	stat_RUNREADY:	"Equipo conectado",
	stat_STANDBY:	"Equipo en standby",
	stat_SYSTEMACTIVE:	"Equipo conectado",
	stat_TPYBEGUN:	"Terapia iniciada",
	stat_VOLBOL:	"Entregando bolo por volumen",
// - Voralarme
	preAlarm_Label:	"<strong>Pre-alarma(s):<\/strong>",
	preAlarm_ACCU:	"Batería casi vacia",
	preAlarm_DISPOSABLE:	"Jeriga casi vacia",
	preAlarm_KOR:	"KVO activo",
	preAlarm_NOPREALARM:	"<strong>Sin pre-alarma<\/strong>",
	preAlarm_TIME:	"Tiempo cercano al final",
	preAlarm_UNKNOWN:	"Desconocido",
	preAlarm_VTBD:	"VTBI casi entregado",
	preAlarm_DATALOCK: "Código erróneo",
	preAlarm_INCOMPATIBLE_CAN_DEVICE: "!Error de comunicación!",
	preAlarm_PIGGYBACK: "Pigyback 2 infundido",
	preAlarm_TGC: "Medición glucosa",
// - Alarme
	Alarm_Label:	"<strong>Alarma(s):<\/strong>",
	Alarm_ACCU:	"Batería casi vacia",
	Alarm_ACCU_EMPTY:	"Batería casi vacia",
	Alarm_ACCUCOVER:	"Batería del cover quitada",
	Alarm_ACCUVOLTAGE:	"Tensión bateria muy baja",
	Alarm_AIR:	"Aire en la línea",
	Alarm_AIRBUBBLE:	"Burbuja de aire",
	Alarm_AIRRATE:	"Flujo de aire",
	Alarm_BAGEMPTY:	"Contenedro\/botella vacia",
	Alarm_CALDATA:	"Calibre el equipo",
	Alarm_CONTEND:	"Lorem ipsum",
	Alarm_DRIP:	"Revisar entrada",
	Alarm_DRIPDISCONNECT:	"Sensor gotas desconectado",
	Alarm_FREEFLOW:	"Flujo libre",
	Alarm_KPS:	"Regleta enchufes mal fijada",
	Alarm_KVOEND:	"KVO finalizado",
	Alarm_LESSDROPS:	"Goteo insuficiente",
	Alarm_MANYDROPS:	"Demasiadas gotas",
	Alarm_NOACCU:	"Batería no montada",
	Alarm_NOAIRTEST:	"Test sensor aire fallido",
	Alarm_NOALARM:	"<strong>Sin alarma<\/strong>",
	Alarm_NODROP:	"No gotas",
	Alarm_PRESSURE:	"Alarma de presión",
	Alarm_SMBLOCK:	"Mecanismo bloqueado",
	Alarm_STANDBY:	"Tiempo standby terminado",
	Alarm_SYRAXIAL:	"Jeringa mal colocada",
	Alarm_SYRCLAW:	"Garra mal colocada",
	Alarm_SYREND:	"Jeringa vacia",
	Alarm_SYRHOLD:	"Soporte jeringa",
	Alarm_TEMPERATURE:	"Alarma temperatura",
	Alarm_TIMEEND:	"Tiempo finalizado",
	Alarm_TPYANDPUMPDATA:	"Datos terapia borrados",
	Alarm_TPYDATA:	"Los datos fueron borrados",
	Alarm_UNKNOWN:	"Desconocido",
	Alarm_VOLEND:	"VTBI infundido",
	Alarm_DATA_LOCK:"Bloqueo de teclado",
	Alarm_XHLIMIT:"Límite PCA alcanzado",
	Alarm_TGCEND:"Fin SGC",
// - Reminder Alarm
	RemAlarm_IS_ACTIVE:	"Alarma recordatoria",
	RemAlarm_IS_INACTIVE:	'',
	RemAlarm_UNKNOWN:	"Unknown reminder alarm",
// - Soft Limit Stati
	SL_NONE:	'',
	SL_UNDER_LIMIT:	"Softlimit bajo sobrepasado",
	SL_UNDER_HIGH_LIMIT:	'',
	SL_OVER_LIMIT:	"Softlimit alto sobrepasado",
	SL_OVER_LOW_LIMIT:	'',
	SL_IN_RANGE:	'',
	SL_NONE_DANGER:	"Precacución! Sin ajustes Softlimits"
};

// Menüstruktur
// Stand: 2006-01
mnutxt.es = {
	m1:		"Estado",
	m2:		"Service Information",
	m3:		"Configuración",
	m4:		"Estado",

// "Beenden" sollte der letzte Menüpunkt sein
	m99:	"Salir aplicación"
};

// Benutzername
userdata.usrname = msg.es.lbl_noLogin;
