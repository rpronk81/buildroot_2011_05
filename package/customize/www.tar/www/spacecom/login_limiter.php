<?php
/**
 * File Format: 
 * <LoginTries>
 *     <try timestamp="2209078800" />
 * </LoginTries>
 **/
function loginTryAllowed()
{
	$loginTriesFile = "/tmp/php_loginTries.xml";
	$loginTriesFileLock = "/tmp/.php_loginTries.lock";
	$lockGained=False;
	$fp = False;	
	do {
		if ($fp == False) {
			$fp = fopen($loginTriesFileLock, "w+");
		}
		//try to lock login lock file
		if ($fp) {
			$lockGained = flock($fp, LOCK_EX);
		}
		if (! $lockGained) usleep(200); //sleep a bit to allow other processes to release file & lock		
	} while (! $lockGained);
	$loginTriesSource = new DomDocument;
	if (file_exists($loginTriesFile)) {
		$loginTriesSource->load($loginTriesFile);
		$loginTriesXpath = new DOMXPath($loginTriesSource);
		$LoginTriesElement = $loginTriesXpath->query("/LoginTries")->item(0);
	} else {
		//create stub document
		$LoginTriesElement = $loginTriesSource->createElement("LoginTries");
		$loginTriesSource->appendChild($LoginTriesElement);
		$loginTriesXpath = new DOMXPath($loginTriesSource);
	}
	
	$tries = $loginTriesXpath->query("/LoginTries/try");

	$now = time();
	$old_limit = $now - 60;
	
	$cnt = 0;
	foreach ($tries as $try) {
		if ($try->getAttribute("timestamp") > $old_limit) {
			$cnt = $cnt + 1;
		} else {
			$LoginTriesElement->removeChild($try);
		}
	}
	$result = ($cnt < 10);

	//remove all but the 10 newest elements to prevent
	// memory flooding of ramfs
	for ($i = $cnt; $i > 10; $i--) {
		//use the ordering to make sure, oldest entry is removed
		$LoginTriesElement->removeChild($LoginTriesElement->firstChild);
	}

	//add current timestamp to tries
	$currentTry = $loginTriesSource->createElement("try");
	$currentTry->setAttribute("timestamp", $now);
	$LoginTriesElement->appendChild($currentTry);

	//save tries file, no need for paranoid, since lock is in place and 
	// powerfail would delete the file anyway (RAMFS)
	// however in case the cgi is killed, 
	// use save -> sync -> rename -> sync to be sure
	do {
		$tmpFileName = $loginTriesFile . "." . rand();
		$saved = $loginTriesSource->save($tmpFileName);
		exec("sync");		
		if ($saved) {
			$saved = rename($tmpFileName, $loginTriesFile);
			exec("sync");
		}			
	} while (! $saved);

	//release Lock
	flock($fp, LOCK_UN);
	//close file
	fclose($fp);
	
	return $result;
}
?>
