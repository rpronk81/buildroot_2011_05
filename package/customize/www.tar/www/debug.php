<?php
include 'common.inc.php';

VerifyConfigAuth();
StyleTitle("Debug Options Panel");
?>
<p>PLEASE NOTE THAT THESE SETTINGS SHOULD NOT BE ENABLED IN A PRODUCTION ENVIRONMENT.</p>
<?php
if (isset($_POST['submit'])) {
	if ($_POST['BCC2Log'] == "Yes") {
		$handle = fopen("/etc/spacecom/bcc_DebugMode", "wb"); 
		fwrite($handle, "Enabled");
		fclose($handle);
	} else {
		unlink("/etc/spacecom/bcc_DebugMode");
	}
	clearstatcache();
}
?>
<form action='debug.php' method='POST'>
  <p>
<?php
if (file_exists("/etc/spacecom/bcc_DebugMode")) {
	print "<input type=\"Checkbox\" name=\"BCC2Log\" value=\"Yes\"  checked />";
} else {
	print "<input type=\"Checkbox\" name=\"BCC2Log\" value=\"Yes\" />";
}
?>
Write BCC communication to Log
  </p>
<p><input type="Submit" name="submit" value="Accept" /></p>
Note: You might have to reboot the device to apply these settings.
</form>
</body>
</html>
