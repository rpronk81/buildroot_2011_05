#!/bin/sh

## Free as much memory as possible without killing the web server.
{
rm /var/watchdog/*
killall -9 autoRestarter
killall -9 canfileio
killall -9 accudrv
killall -9 autoprogramming
killall -9 sgc
killall -9 descread
killall -9 db2js
killall -9 bcc
killall -9 pcs
killall -9 data_updater
killall -9 barcode
killall -9 canon
killall -9 omniNames
killall -9 metalog
killall -9 logger
killall -9 slcand
killall -9 sshd
killall -9 udevd
killall -9 ntpd
killall -9 wlanstate
killall -9 cat
killall -9 proftpd

rm -r /var/log /var/omninames /var/proftpd.* /var/watchdog/*

#kill all php-cgi instances but the one responsible for the update
for phpProcessId in $(ps | grep /sbin/php-cgi | grep -v "/sbin/php-cgi /www/updater.php" | grep -v "grep" | sed -e 's/^ *\([0-9]*\) .*$/\1/'); do
	kill -9 ${phpProcessId}
done

for mp in /www/diag /media /etc/spacecom/SGC; do
	umount $mp 2>/dev/console
	ret=$?
	tries=0
	while mount | grep -q " on $mp " 2>/dev/console ; do		
		if [ $ret -ne 0 ] ; then
			sleep 1
			echo "retrying..." >/dev/console
		fi
		#kill all php-cgi instances but the one responsible for the update again
		# in case another browser created a new one
		for phpProcessId in $(ps | grep /sbin/php-cgi | grep -v "/sbin/php-cgi /www/updater.php" | grep -v "grep" | sed -e 's/^ *\([0-9]*\) .*$/\1/'); do
			kill -9 ${phpProcessId}
		done
		umount $mp 2>/dev/console
		ret=$?
		let "tries += 1"
		if [ "$tries" -ge "3" ]; then
			echo "forcing umount ..." > /dev/console		
			umount -l $mp 2>/dev/console
		fi
	done
done

} 2>&1 | \
	grep -v "no process killed" | \
	grep -v "No such process" | \
	grep -v "No such file or directory" | \
	grep -v "Invalid argument"

# This needs to be done so that do_update.sh can unmount /updater
cp /updater/do_update_wr /updater/do_update.sh /

exit 0

