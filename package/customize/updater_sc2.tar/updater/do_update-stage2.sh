#!/dash

# Periodically trigger watchdog.
echo "$0: starting periodically triggering watchdog" >/dev/console
(
while true ; do
	echo 'Sit!' > /dev/watchdog
	/busybox sleep 30
done
)&

BOARD=`/busybox hostname`

# Locking facilities.
LOCKFILE="/tmp/.fl_lock"
trylock() {
	if ! /busybox mkdir "$LOCKFILE" ; then
		return 9;
	fi
}
unlock() {
	/busybox rmdir "$LOCKFILE"
}

# Function for signaling an error condition.
die() {
	if [ "$BOARD" != "spacecomlite" ] ; then
		led_blink_hz 5 # Blink red LED at 5 Hz for signaling error condition.
	fi
	if [ -n "$*" ] ; then
		echo "$*" >/dev/console
	fi
	echo 'Update failed!' >/dev/console
	/busybox reboot # FIXME: What action should be taken in this case?
}

# If we're not on SpaceCom-lite, let the red LED blink (SpaceCom-lite has no
# LEDs we can blink with).
if [ "$BOARD" != "spacecomlite" ] ; then
	# Source and initialize LED utils
	. /ledutils
	export LED="red"
	led_tinit

	# Blink red LED at 1Hz for signaling update in progress.
	echo "$0: blinking" >/dev/console
	led_blink_hz 1
fi

# Try "locking" the flash storage.
echo "$0: locking the flash storage" >/dev/console
trylock
if [ $? -eq 9 ] ; then
	die 'Error: Lock failed, some flashing maybe in progress'
fi

# Mount the configuration partition and store the checksum of the new image.
echo "$0: storing image checksum" >/dev/console
/busybox mount -t jffs2 /dev/mtdblock3 /mnt 2>/dev/console || \
	die 'Error: Could not mount persistent configuration storage!'
/busybox head -1 /tmp/new_image > /mnt/check 2>/dev/console || \
	die 'Error: Storing image checksum failed!'

echo "$0: checking magic file for factory defaults with keeping network settings" >/dev/console
if [ -f /mnt/FactoryDefaultsKeepNetworkSettings ] ; then
	echo "$0: found matic file, do restore" >/dev/console
	/busybox cp /mnt/protected/system-connections /tmp/ -r
	/busybox cp /mnt/check /tmp/check
	/busybox cp /mnt/httpkey/lighthttpd.pem /tmp/
	/busybox cp /mnt/httpkey/ssl.cert.pem /tmp/
	/busybox cp /mnt/httpkey/ssl.key.pem /tmp/

	/busybox rm -fr -- /mnt/*
	/busybox mv /tmp/check /mnt/check
	/busybox mkdir /mnt/protected/
	/busybox mv /tmp/system-connections /mnt/protected/
	/busybox mkdir /mnt/httpkey
	/busybox mv /tmp/lighthttpd.pem /mnt/httpkey
	/busybox mv /tmp/ssl.cert.pem /mnt/httpkey
	/busybox mv /tmp/ssl.key.pem /mnt/httpkey
fi

/busybox umount /mnt

# Clear the flash and write the new image.
echo "$0: flashing" >/dev/console
#flash_eraseall has been replaced by flash_erase <mtddev> 0 0
/flash_erase /dev/mtd2 0 0 >/dev/null 2>/dev/console || \
	die 'Error: Erasing flash storage failed!'
/busybox tail -n +2 /tmp/new_image | \
	/busybox dd of=/dev/mtd2 bs=1M >/dev/null 2>/dev/console || \
		die 'Error: Flashing new image failed!'
echo "$0: done" >/dev/console

unlock
echo "$0: rebooting" >/dev/console
/busybox reboot
