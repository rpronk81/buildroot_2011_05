#!/bin/sh

# Check if image is available and valid.
if ! [ -f /tmp/new_image ] ; then
	echo 'Error: No image found!'
	exit 1
fi

image_checksum=`tail -n +2 /tmp/new_image|md5sum|sed 's/ .*//'`
header_checksum=`head -n 1 /tmp/new_image|sed 's/ .*//'`
if [ "$image_checksum" != "$header_checksum" ] ; then
	echo 'Error: Image corrupted!'
	rm /tmp/new_image
	exit 2
fi

exit 0
