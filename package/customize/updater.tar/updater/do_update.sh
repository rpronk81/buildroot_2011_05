#!/busybox sh

BOARD=`cat /etc/hostname`

# Change cwd from /www to /, so /www can be unmounted.
cd /

# For the rare occasions where update.html takes more time to load...
sleep 3

# Kill remaining processes, started from flash storage.
echo "$0: killing remaining processes" >/dev/console
{
killall -9 lighttpd
killall -9 networksupervisor.sh
killall -9 NetworkManager
killall -9 wpa_cli
killall -9 wpa_supplicant
killall -9 dhclient
killall -9 rc.start
killall -9 dbus-daemon
killall -9 sleep
killall -9 json-dbus-bridge
killall -9 php-cgi
killall -9 sh
killall -9 watchdogd
killall -9 arping
killall -9 fixWlan
} 2>&1 | grep -v "no process killed" | grep -v "No such process" >/dev/console

# Manually trigger watchdog.
# This needs to be done at least once each 60 seconds. In stage 2, which will
# be run using bash again, it will be done in an endless loop in the background,
# but busybox's msh doesn't provide this feature.
echo 'Sit!' > /dev/watchdog 2>/dev/console

# Save all programs and libs, required after unmounting the flash storage.
progs="/sbin/flash_erase /sbin/ledutils /bin/dash /updater/do_update-stage2.sh"
libs="/lib/libgcc_s.so.1 /lib/libc.so.6 /lib/ld-linux.so.3 /lib/libdl.so.2"
echo "$0: saving required progs and libs" >/dev/console
cp $progs $libs / 2>/dev/console
# Symlink busybox to /sbin/[ because [ is in /usr/bin and /usr will be unmounted
/busybox ln -s /busybox /sbin/[ 

# Unmount flash storage including remaining bind-mounts and unmount remaining
# RAM filesystems, not required for update.
# This is done in a loop, do circumvent problems like repeatedly mounted
# directories (like /var) and mountpoints which are temporarily busy (like /bin
# sometimes is).
echo "$0: unmounting flash filesystem" >/dev/console
if [ "$BOARD" = "spacecom1" ]; then
	/busybox umount /lib/firmware 2>/dev/console
	ret=$?
	while ( $ret -ne 0 ) ; do
		/busybox sleep 1
		/busybox echo "retrying..." >/dev/console
		/busybox umount /lib/firmware 2>/dev/console
		ret=$?
	done
fi
for mp in /bin /etc/spacecom /etc /lib /mnt /root /sbin /updater /usr /var /www /.flash ; do
	/busybox umount $mp 2>/dev/console
	ret=$?
	tries=0
	while /busybox mount | /busybox grep -q " on $mp " 2>/dev/console ; do
		/busybox echo 'Sit!' > /dev/watchdog 2>/dev/console
		if [ $ret -ne 0 ] ; then
			/busybox sleep 1
			/busybox echo "retrying..." >/dev/console
		fi
		/busybox umount $mp 2>/dev/console
		ret=$?
		let "tries += 1"
		if [ "$tries" -ge "3" ]; then
			echo "forcing umount ..." > /dev/console		
			/busybox umount -l $mp 2>/dev/console
		fi
	done
done

# Manually trigger watchdog.
/busybox echo 'Sit!' > /dev/watchdog 2>/dev/console

# Symlink busybox to /bin/sh, because `command` or $(command) calls /bin/sh :/
/busybox echo "$0: installing required progs and libs" >/dev/console
/busybox ln -s /busybox /bin/sh 2>/dev/console
# Install required libs.
for lib in $libs ; do
	/busybox mv `/busybox basename $lib` /lib 2>/dev/console
done

# Manually trigger watchdog.
/busybox echo 'Sit!' > /dev/watchdog 2>/dev/console

# Run the remaining update in bash, because busybox's msh can't run jobs in the
# background and can not handle the shell functions in /sbin/ledutils.
/busybox echo "$0: executing stage 2" >/dev/console
exec /dash /do_update-stage2.sh 2>/dev/console
