#!/bin/sh
# Script for restarting the WLAN network interface
stopwlan.sh
startwlan.sh
