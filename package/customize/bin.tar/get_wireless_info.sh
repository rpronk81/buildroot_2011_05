#!/bin/sh
# Script for getting Signal Strength.

WIRELESS_DATA_FILE=/tmp/wireless_data

# Counter for updating wireless data file.
COUNTER=0

while true; do

    COUNTER=$(( $COUNTER + 1 ))
    if [ $COUNTER -eq 30 ]; then
        # Get wireless data every 30 seconds.
        iwconfig wlan0 | grep level: >/tmp/wireless_data.tmp

        # Atomic move
        mv /tmp/wireless_data.tmp "$WIRELESS_DATA_FILE"
        COUNTER=0
    fi

    sleep 1
done
