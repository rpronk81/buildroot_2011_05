#!/bin/sh
# Script for starting the WLAN network interface
# no need to reboot just restart wifi

WLAN_STATUS_FILE=/tmp/wlan0_current_status

COUNTER=0

while [ $COUNTER -le 20 ]; do

   # if stopwlan has been called, status should be Unavailable
   grep -q -s "Unavailable" $WLAN_STATUS_FILE > /dev/null 2>&1

   if [ $? = 1 ]; then
      COUNTER=$(( $COUNTER + 1 ))
      cat $WLAN_STATUS_FILE
      # if status is Activated then no need to turn wifi on it is on already
      grep -q -s "Activated" $WLAN_STATUS_FILE > /dev/null 2>&1
      if [ $? = 0 ]; then 
         echo "in startwlan found Activated"
         COUNTER=30
      fi
      sleep 2      
    else
      echo "In startwlan.sh calling nmcli nm wifi on"
      cat $WLAN_STATUS_FILE
      nmcli nm wifi on
      COUNTER=30
    fi
done
