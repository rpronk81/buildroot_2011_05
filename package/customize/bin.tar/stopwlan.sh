#!/bin/sh
# Script for stopping the WLAN network interface

set -e

if [ -e /proc/wlan0 ]; then
	nmcli nm wifi off
fi
