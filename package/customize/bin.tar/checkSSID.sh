#!/bin/sh
# Script for starting retrieving SSID information.

nmcli -t -f UUID con status >/tmp/ssid.txt

