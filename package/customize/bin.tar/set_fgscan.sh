#!/bin/sh

CONFIGDIR=/etc/spacecom/protected/system-connections

# set the forward scan in the radio driver so that it knows
# the ssid of the network to which it will attach.

total=`ls -l $CONFIGDIR/*.nm | sed -n '$='`
logger -p INFO -t FGSCAN "Total number of .nm files = " $total

if [ "$total" -eq "1" ]; then

    grep "mode=adhoc" $CONFIGDIR/*.nm

    if [ $? -ne 0 ]; then
        int_chars=`cat $CONFIGDIR/*.nm | grep 'ssid=' | sed -e 's/.*ssid=//' -e 's/;/\n/g'`
        ssid=`for c in $int_chars; do printf "\x$(printf %x $c)"; done`
        logger -p INFO -t FGSCAN "Setting fgscan_ssid \"${ssid}\""

        iwpriv wlan0 set_fgscan_ssid "${ssid}"
        iwpriv wlan0 reset_adapter 0
    fi
else
    logger -p INFO -t FGSCAN "Resetting SSID"
    iwpriv wlan0 set_fgscan_ssid 
    iwpriv wlan0 reset_adapter 0
fi
