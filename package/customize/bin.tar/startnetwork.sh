#!/bin/sh
# Script for starting wpa_supplicant and managing networks.

# Read network configuration.
. /etc/networkconfig

RESTART_MODE="${1:-restart}"
if [ "$RESTART_MODE" = "reload" ]; then
	touch "$RELOADFILE"
else
	touch "$RESTARTFILE"
fi
